
import React, { useState } from 'react';
import { ArrowLeft, Save, Sparkles, Sliders, Thermometer, Zap, MessageSquare, Play } from 'lucide-react';
import { User, CustomModel } from './types';

const StudioApp = ({ user, setUser, updateCredits, onBack }: { user: User, setUser: any, updateCredits: any, onBack: () => void }) => {
    const [view, setView] = useState<'home' | 'create'>('home');
    const [formData, setFormData] = useState<CustomModel>({ id: '', name: '', description: '', systemInstruction: '', webSearch: false, temperature: 0.7, responseSpeed: 1, maxLength: 2048, author: user.username, isPublic: false, isActive: false });

    const handleCreate = () => {
        setFormData({ id: Date.now().toString(), name: "Untitled Model", description: "", systemInstruction: "", webSearch: false, temperature: 0.7, responseSpeed: 1, maxLength: 2048, author: user.username, isPublic: false, isActive: false });
        setView('create');
    };

    const handleSave = () => {
        const idx = user.createdModels.findIndex(m => m.id === formData.id);
        const list = [...user.createdModels];
        if (idx !== -1) list[idx] = formData; else list.push(formData);
        setUser({ ...user, createdModels: list });
        setView('home');
    };

    if (view === 'create') {
        return (
            <div className="h-full bg-gray-50 flex flex-col font-sans">
                {/* Dashboard Header */}
                <div className="bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center">
                    <div className="flex items-center gap-4">
                        <button onClick={() => setView('home')} className="p-2 hover:bg-gray-100 rounded-full transition"><ArrowLeft size={20}/></button>
                        <h1 className="font-bold text-xl">Model Configuration</h1>
                    </div>
                    <div className="flex gap-3">
                         <button className="px-4 py-2 text-sm font-bold text-gray-500 hover:bg-gray-100 rounded-lg">Discard</button>
                         <button onClick={handleSave} className="px-4 py-2 text-sm font-bold bg-blue-600 text-white rounded-lg hover:bg-blue-700 shadow-sm flex items-center gap-2">
                            <Save size={16}/> Save Model
                         </button>
                    </div>
                </div>

                <div className="flex-1 flex overflow-hidden">
                    {/* Left Panel: Configuration */}
                    <div className="w-80 bg-white border-r border-gray-200 overflow-y-auto p-6 space-y-8">
                        <div>
                            <label className="text-xs font-bold text-gray-500 uppercase mb-2 block">Identity</label>
                            <input 
                                value={formData.name} 
                                onChange={e => setFormData({...formData, name: e.target.value})} 
                                className="w-full p-2 border border-gray-300 rounded-md text-sm font-medium mb-3 focus:ring-2 focus:ring-blue-500 outline-none" 
                                placeholder="Model Name"
                            />
                            <textarea 
                                value={formData.description} 
                                onChange={e => setFormData({...formData, description: e.target.value})} 
                                className="w-full p-2 border border-gray-300 rounded-md text-sm text-gray-600 h-20 resize-none focus:ring-2 focus:ring-blue-500 outline-none" 
                                placeholder="Description..."
                            />
                        </div>

                        <div>
                            <label className="text-xs font-bold text-gray-500 uppercase mb-4 block">Parameters</label>
                            
                            <div className="mb-6">
                                <div className="flex justify-between text-sm mb-2">
                                    <span className="flex items-center gap-2"><Thermometer size={14}/> Temperature</span>
                                    <span className="font-mono text-gray-500">{formData.temperature}</span>
                                </div>
                                <input 
                                    type="range" min="0" max="1" step="0.1" 
                                    value={formData.temperature} 
                                    onChange={e => setFormData({...formData, temperature: parseFloat(e.target.value)})}
                                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                                />
                            </div>

                            <div className="mb-6">
                                <div className="flex justify-between text-sm mb-2">
                                    <span className="flex items-center gap-2"><Zap size={14}/> Max Tokens</span>
                                    <span className="font-mono text-gray-500">{formData.maxLength}</span>
                                </div>
                                <input 
                                    type="range" min="256" max="8192" step="256" 
                                    value={formData.maxLength} 
                                    onChange={e => setFormData({...formData, maxLength: parseInt(e.target.value)})}
                                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="text-xs font-bold text-gray-500 uppercase mb-2 block">Capabilities</label>
                            <label className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50">
                                <input type="checkbox" checked={formData.webSearch} onChange={e => setFormData({...formData, webSearch: e.target.checked})} className="w-4 h-4 accent-blue-600"/>
                                <span className="text-sm">Web Search</span>
                            </label>
                        </div>
                    </div>

                    {/* Middle Panel: System Prompt */}
                    <div className="flex-1 bg-gray-50 p-8 flex flex-col">
                        <label className="text-xs font-bold text-gray-500 uppercase mb-4 flex items-center gap-2">
                            <Sliders size={14}/> System Instructions
                        </label>
                        <div className="flex-1 bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden flex flex-col">
                            <textarea 
                                value={formData.systemInstruction} 
                                onChange={e => setFormData({...formData, systemInstruction: e.target.value})} 
                                className="flex-1 w-full p-6 outline-none resize-none font-mono text-sm leading-relaxed" 
                                placeholder="You are a helpful assistant..."
                            />
                        </div>
                    </div>

                    {/* Right Panel: Test Playground (Static Preview) */}
                    <div className="w-96 bg-white border-l border-gray-200 flex flex-col">
                         <div className="p-4 border-b border-gray-200 bg-gray-50">
                             <div className="text-xs font-bold text-gray-500 uppercase flex items-center gap-2"><MessageSquare size={14}/> Test Playground</div>
                         </div>
                         <div className="flex-1 p-4 flex flex-col items-center justify-center text-gray-400">
                             <Play size={48} className="mb-4 opacity-20"/>
                             <p className="text-sm text-center">Save model to test in Chat.</p>
                         </div>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <div className="h-full bg-white p-8 font-sans overflow-y-auto">
            <div className="max-w-6xl mx-auto">
                <div className="flex justify-between items-center mb-12">
                    <div className="flex items-center gap-4">
                        <button onClick={onBack} className="text-gray-400 hover:text-black transition"><ArrowLeft/></button>
                        <h1 className="text-3xl font-extrabold tracking-tight">VibhavGPT <span className="text-blue-600">Studio</span></h1>
                    </div>
                    <button onClick={handleCreate} className="bg-black text-white px-6 py-2.5 rounded-lg text-sm font-bold hover:bg-gray-800 transition shadow-lg">
                        + New Model
                    </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {user.createdModels.map(m => (
                        <div key={m.id} className="border border-gray-200 bg-white p-6 rounded-xl cursor-pointer hover:border-blue-500 hover:shadow-lg transition group" onClick={() => { setFormData(m); setView('create'); }}>
                            <div className="flex items-center justify-between mb-4">
                                <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center"><Sparkles size={20}/></div>
                                <div className="text-xs font-mono bg-gray-100 px-2 py-1 rounded text-gray-600">v1.0</div>
                            </div>
                            <h3 className="font-bold text-lg text-gray-900 mb-2">{m.name}</h3>
                            <p className="text-sm text-gray-500 line-clamp-2">{m.systemInstruction || "No instructions set."}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default StudioApp;
