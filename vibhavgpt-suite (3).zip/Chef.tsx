
import React, { useState } from 'react';
import { ArrowLeft, Loader2, Utensils, ChefHat, Flame, Clock, Users, List, AlignLeft } from 'lucide-react';
import { User, Recipe, ModelType } from './types';
import { generateAIResponse } from './services/geminiService';
import MarkdownRenderer from './components/MarkdownRenderer';
import { Type } from "@google/genai";

const ChefApp = ({ user, setUser, updateCredits, onBack }: { user: User, setUser: any, updateCredits: any, onBack: () => void }) => {
    const [view, setView] = useState<'home' | 'create' | 'recipe'>('home');
    const [activeRecipe, setActiveRecipe] = useState<Recipe | null>(null);
    const [prompt, setPrompt] = useState("");
    const [loading, setLoading] = useState(false);

    const generate = async () => {
        if (!updateCredits(1)) return;
        setLoading(true);
        try {
            const schema = { type: Type.OBJECT, properties: { title: {type: Type.STRING}, ingredients: {type: Type.ARRAY, items:{type:Type.STRING}}, instructions: {type:Type.STRING}, nutrition: {type: Type.OBJECT, properties: {calories:{type:Type.NUMBER}, protein:{type:Type.STRING}, carbs:{type:Type.STRING}, fat:{type:Type.STRING}}} } };
            const res = await generateAIResponse({ modelName: ModelType.PLUS, prompt: `Create a detailed recipe for: ${prompt}`, responseSchema: schema, responseMimeType: "application/json" });
            const data = JSON.parse(res.text);
            const newRecipe = { id: Date.now().toString(), title: data.title, cuisine: 'General', mealType: 'Meal', content: data.instructions, nutrition: data.nutrition, ingredients: data.ingredients, author: user.username, isPublic: false };
            setUser({...user, savedRecipes: [newRecipe, ...user.savedRecipes]});
            setActiveRecipe(newRecipe);
            setView('recipe');
        } catch(e) { alert("Error generating recipe."); } finally { setLoading(false); }
    };

    if (view === 'recipe' && activeRecipe) {
        return (
            <div className="h-full bg-[#faf9f6] font-serif overflow-y-auto">
                <div className="relative h-64 bg-stone-900 text-white flex items-end p-8">
                    <button onClick={() => setView('home')} className="absolute top-8 left-8 bg-white/10 hover:bg-white/20 p-2 rounded-full backdrop-blur-md transition"><ArrowLeft/></button>
                    <div className="max-w-4xl mx-auto w-full">
                        <span className="text-orange-400 font-sans text-xs font-bold uppercase tracking-widest mb-2 block">Recipe</span>
                        <h1 className="text-5xl font-bold font-serif mb-6">{activeRecipe.title}</h1>
                        <div className="flex gap-6 font-sans text-sm font-medium">
                            <div className="flex items-center gap-2"><Clock size={16}/> 30 mins</div>
                            <div className="flex items-center gap-2"><Users size={16}/> 2 servings</div>
                            <div className="flex items-center gap-2 text-orange-300"><Flame size={16}/> {activeRecipe.nutrition.calories} kcal</div>
                        </div>
                    </div>
                </div>

                <div className="max-w-5xl mx-auto p-8 grid grid-cols-1 md:grid-cols-3 gap-12">
                    {/* Sidebar Ingredients */}
                    <div className="md:col-span-1">
                        <h3 className="font-sans font-bold text-lg uppercase tracking-wider mb-6 pb-2 border-b border-gray-200">Ingredients</h3>
                        <ul className="space-y-4 font-sans text-stone-600">
                            {(activeRecipe as any).ingredients?.map((ing: string, i: number) => (
                                <li key={i} className="flex items-start gap-3">
                                    <div className="w-1.5 h-1.5 rounded-full bg-orange-400 mt-2 shrink-0"></div>
                                    <span className="leading-relaxed">{ing}</span>
                                </li>
                            )) || <li className="text-gray-400 italic">No ingredients listed (Legacy format)</li>}
                        </ul>

                        <div className="mt-12 bg-white p-6 rounded-xl border border-stone-200 shadow-sm">
                            <h3 className="font-sans font-bold text-sm uppercase tracking-wider mb-4 text-stone-400">Nutrition per serving</h3>
                            <div className="space-y-3 font-sans text-sm">
                                <div className="flex justify-between"><span>Protein</span><span className="font-bold">{activeRecipe.nutrition.protein}</span></div>
                                <div className="flex justify-between"><span>Carbs</span><span className="font-bold">{activeRecipe.nutrition.carbs}</span></div>
                                <div className="flex justify-between"><span>Fat</span><span className="font-bold">{activeRecipe.nutrition.fat}</span></div>
                            </div>
                        </div>
                    </div>

                    {/* Main Instructions */}
                    <div className="md:col-span-2">
                        <h3 className="font-sans font-bold text-lg uppercase tracking-wider mb-6 pb-2 border-b border-gray-200">Preparation</h3>
                        <div className="prose prose-stone prose-lg max-w-none font-serif">
                            <MarkdownRenderer content={activeRecipe.content}/>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    if (view === 'create') {
        return (
            <div className="h-full bg-[#faf9f6] flex items-center justify-center p-6">
                <button onClick={() => setView('home')} className="absolute top-8 left-8 p-2 hover:bg-gray-200 rounded-full transition"><ArrowLeft size={24}/></button>
                <div className="max-w-xl w-full">
                    <div className="text-center mb-10">
                        <ChefHat size={64} className="mx-auto text-orange-500 mb-6"/>
                        <h1 className="text-4xl font-serif font-bold text-stone-800 mb-2">The Kitchen</h1>
                        <p className="text-stone-500 font-sans">What are we cooking today?</p>
                    </div>
                    
                    <div className="bg-white p-2 rounded-2xl shadow-xl border border-stone-100">
                        <textarea 
                            value={prompt} 
                            onChange={e => setPrompt(e.target.value)} 
                            placeholder="e.g., 'Spicy Thai Basil Chicken', 'Vegan Chocolate Cake', 'High protein breakfast'..." 
                            className="w-full p-6 rounded-xl outline-none resize-none text-lg min-h-[150px] font-serif placeholder:font-sans placeholder:text-stone-300"
                        />
                        <div className="px-2 pb-2">
                             <button 
                                onClick={generate} 
                                disabled={loading || !prompt.trim()} 
                                className="w-full bg-orange-600 text-white py-4 rounded-xl font-sans font-bold hover:bg-orange-700 transition flex items-center justify-center gap-2"
                            >
                                {loading ? <Loader2 className="animate-spin"/> : <Utensils size={18}/>}
                                {loading ? 'Developing Recipe...' : 'Create Recipe'}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <div className="h-full bg-[#faf9f6] p-8 overflow-y-auto font-sans">
            <div className="max-w-6xl mx-auto">
                <div className="flex justify-between items-center mb-12">
                    <div className="flex items-center gap-4">
                        <button onClick={onBack} className="text-gray-400 hover:text-black transition"><ArrowLeft/></button>
                        <h1 className="text-3xl font-bold font-serif text-stone-800">My Cookbook</h1>
                    </div>
                    <button onClick={() => setView('create')} className="bg-orange-600 text-white px-6 py-2.5 rounded-full text-sm font-bold hover:bg-orange-700 transition shadow-lg shadow-orange-500/20">
                        + New Recipe
                    </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {user.savedRecipes.map(r => (
                        <div key={r.id} onClick={() => { setActiveRecipe(r); setView('recipe'); }} className="group bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1 transition duration-300 cursor-pointer border border-stone-100 flex flex-col">
                            <div className="h-48 bg-stone-200 relative overflow-hidden">
                                <div className="absolute inset-0 flex items-center justify-center text-stone-400 group-hover:scale-105 transition duration-500">
                                    <Utensils size={48} className="opacity-20"/>
                                </div>
                                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-orange-600 flex items-center gap-1">
                                    <Flame size={12}/> {r.nutrition.calories}
                                </div>
                            </div>
                            <div className="p-6 flex-1 flex flex-col">
                                <h3 className="font-serif font-bold text-xl text-stone-800 mb-2 leading-tight group-hover:text-orange-600 transition">{r.title}</h3>
                                <div className="mt-auto pt-4 border-t border-stone-100 flex justify-between text-xs text-stone-500 font-bold uppercase tracking-wider">
                                    <span>{r.cuisine}</span>
                                    <span>{r.mealType}</span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ChefApp;
