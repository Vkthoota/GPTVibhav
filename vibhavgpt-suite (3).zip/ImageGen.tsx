
import React, { useState } from 'react';
import { ArrowLeft, Loader2, Sparkles, Image as ImageIcon, Download, Palette, Ratio, Sliders, Eraser, Edit, Key, History, Plus } from 'lucide-react';
import { User, Tier } from './types';
import { generateNanoImage } from './services/geminiService';
import { PaymentModal } from './Modals';

const ImageGenApp = ({ user, updateCredits, onBack }: { user: User, updateCredits: any, onBack: () => void }) => {
    const [mode, setMode] = useState<'create' | 'edit'>('create');
    const [prompt, setPrompt] = useState("");
    const [model, setModel] = useState("nano-pro");
    const [aspectRatio, setAspectRatio] = useState("1:1");
    const [loading, setLoading] = useState(false);
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [showPayment, setShowPayment] = useState(false);
    const [editImage, setEditImage] = useState<{data: string, mimeType: string} | null>(null);
    const [history, setHistory] = useState<string[]>([]);

    if (user.tier === Tier.FREE || user.tier === Tier.GUEST) {
        return (
            <div className="h-full bg-white text-gray-900 flex flex-col items-center justify-center p-8 relative overflow-hidden font-sans">
                <button onClick={onBack} className="absolute top-8 left-8 p-2 rounded-full hover:bg-gray-100 transition"><ArrowLeft size={20}/></button>
                <div className="relative z-10 text-center animate-in fade-in zoom-in duration-500">
                    <div className="w-16 h-16 bg-black text-white rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                        <ImageIcon size={32} />
                    </div>
                    <h1 className="text-3xl font-bold mb-3 tracking-tight">Image Engine</h1>
                    <p className="text-gray-500 mb-8 max-w-sm mx-auto text-lg">Create stunning visuals with Google's Nano Banana models. Available on Explorer+ plans.</p>
                    <button onClick={() => setShowPayment(true)} className="bg-black text-white px-8 py-3 rounded-full font-bold shadow-lg hover:opacity-80 transition flex items-center gap-2 mx-auto">
                        <Sparkles size={18}/> Upgrade Now
                    </button>
                </div>
                <PaymentModal isOpen={showPayment} onClose={() => setShowPayment(false)} onUpgrade={(t) => window.location.reload()} />
            </div>
        )
    }

    const ensureApiKey = async (forceObj?: boolean) => {
        if ((window as any).aistudio && model === 'nano-pro') {
            const hasKey = await (window as any).aistudio.hasSelectedApiKey();
            if (!hasKey || forceObj) {
                try {
                    await (window as any).aistudio.openSelectKey();
                    await new Promise(r => setTimeout(r, 1000));
                    return true;
                } catch (e) {
                    return false;
                }
            }
        }
        return true;
    };

    const handleGenerate = async () => {
        if (!prompt.trim()) return;
        await ensureApiKey();
        
        if (!updateCredits(2)) return;
        setLoading(true);
        setImageUrl(null);
        
        const apiKey = process.env.API_KEY || user.apiKeys?.google || '';
        
        try {
            const url = await generateNanoImage(prompt, model, apiKey, aspectRatio, "1K", mode === 'edit' && editImage ? editImage : undefined);
            setImageUrl(url);
            setHistory(prev => [url, ...prev]);
        } catch (e: any) { 
            const errMsg = e.message || JSON.stringify(e);
            if (errMsg.includes("403") || errMsg.includes("PERMISSION_DENIED") || errMsg.includes("404") || errMsg.includes("not found")) {
                 alert("API Key Required: High-resolution models require a specific project API key. Please select one with billing.");
                 await ensureApiKey(true);
            } else {
                 alert("Generation Error: " + errMsg); 
            }
        } 
        finally { setLoading(false); }
    };

    const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => setEditImage({ data: (reader.result as string).split(',')[1], mimeType: file.type });
            reader.readAsDataURL(file);
        }
    };

    return (
        <div className="h-full bg-white text-gray-900 flex flex-col font-sans overflow-hidden">
            
            {/* Header */}
            <div className="h-14 border-b border-gray-100 flex items-center justify-between px-4 bg-white z-20">
                <div className="flex items-center gap-4">
                    <button onClick={onBack} className="p-2 hover:bg-gray-50 rounded-lg transition text-gray-500 hover:text-black"><ArrowLeft size={18}/></button>
                    <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm">Image Engine</span>
                    </div>
                </div>
                
                <div className="flex bg-gray-50 p-1 rounded-lg border border-gray-100">
                    <button onClick={() => setMode('create')} className={`px-4 py-1.5 rounded-md text-xs font-bold transition flex items-center gap-2 ${mode === 'create' ? 'bg-white text-black shadow-sm' : 'text-gray-500 hover:text-black'}`}>
                        <Sparkles size={14}/> Create
                    </button>
                    <button onClick={() => setMode('edit')} className={`px-4 py-1.5 rounded-md text-xs font-bold transition flex items-center gap-2 ${mode === 'edit' ? 'bg-white text-black shadow-sm' : 'text-gray-500 hover:text-black'}`}>
                        <Edit size={14}/> Edit
                    </button>
                </div>
                <div className="w-8"></div>
            </div>

            <div className="flex-1 flex overflow-hidden">
                
                {/* Canvas Area */}
                <div className="flex-1 bg-[#f4f4f5] relative flex flex-col">
                    <div className="flex-1 flex items-center justify-center p-8 relative">
                        {/* Dot Pattern Background */}
                        <div className="absolute inset-0 opacity-[0.03]" style={{backgroundImage: 'radial-gradient(#000 1px, transparent 1px)', backgroundSize: '20px 20px'}}></div>

                        <div className="relative max-w-3xl w-full aspect-square md:aspect-auto flex items-center justify-center min-h-[400px]">
                            {loading ? (
                                <div className="flex flex-col items-center gap-4">
                                    <div className="w-12 h-12 bg-white rounded-xl shadow-lg flex items-center justify-center">
                                        <Loader2 className="animate-spin text-black" size={24}/>
                                    </div>
                                    <span className="text-gray-400 font-medium text-xs tracking-widest uppercase">Rendering...</span>
                                </div>
                            ) : imageUrl ? (
                                <div className="relative group shadow-2xl rounded-lg overflow-hidden ring-1 ring-black/5">
                                    <img src={imageUrl} className="max-w-full max-h-[80vh] object-contain bg-white" alt="Generated"/>
                                    <a href={imageUrl} download="generated-image.png" className="absolute top-4 right-4 bg-white/90 p-2 rounded-lg text-gray-700 hover:text-black opacity-0 group-hover:opacity-100 transition shadow-sm backdrop-blur-sm">
                                        <Download size={18}/>
                                    </a>
                                </div>
                            ) : (
                                <div className="text-center text-gray-400">
                                    <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                        <Palette size={32} className="opacity-20 text-black"/>
                                    </div>
                                    <p className="font-medium text-sm">Enter a prompt to start dreaming.</p>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Minimal History Bar */}
                    {history.length > 0 && (
                        <div className="h-20 border-t border-gray-200 bg-white flex items-center px-6 gap-3 overflow-x-auto z-10">
                            <span className="text-xs font-bold text-gray-400 uppercase mr-2 shrink-0">Recent</span>
                            {history.map((url, i) => (
                                <img key={i} src={url} onClick={() => setImageUrl(url)} className={`h-12 w-12 object-cover rounded-md cursor-pointer border-2 transition ${imageUrl === url ? 'border-black' : 'border-transparent hover:border-gray-200'}`} />
                            ))}
                        </div>
                    )}
                </div>

                {/* Right Controls */}
                <div className="w-80 border-l border-gray-100 bg-white p-5 flex flex-col gap-6 overflow-y-auto z-10">
                    
                    {mode === 'edit' && (
                        <div className="space-y-3">
                            <label className="text-xs font-bold text-gray-900">Source Image</label>
                            <div className="border border-dashed border-gray-300 rounded-xl p-6 text-center hover:bg-gray-50 hover:border-gray-400 transition cursor-pointer relative group">
                                {editImage ? (
                                    <>
                                        <img src={`data:${editImage.mimeType};base64,${editImage.data}`} className="h-32 object-contain mx-auto rounded shadow-sm"/>
                                        <button onClick={(e) => {e.stopPropagation(); setEditImage(null);}} className="absolute top-2 right-2 p-1.5 bg-white text-red-500 rounded-md shadow-sm border border-gray-100 opacity-0 group-hover:opacity-100 transition"><Eraser size={14}/></button>
                                    </>
                                ) : (
                                    <label className="cursor-pointer block w-full">
                                        <div className="w-10 h-10 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-2 text-gray-400"><Plus size={20}/></div>
                                        <span className="text-xs font-medium text-gray-500">Upload Reference</span>
                                        <input type="file" className="hidden" onChange={handleUpload}/>
                                    </label>
                                )}
                            </div>
                        </div>
                    )}

                    <div className="space-y-3">
                        <label className="text-xs font-bold text-gray-900">Prompt</label>
                        <textarea 
                            value={prompt} 
                            onChange={e => setPrompt(e.target.value)} 
                            placeholder="A futuristic city in clouds, cyberpunk style..." 
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl p-4 h-32 text-sm focus:border-black/20 focus:ring-2 focus:ring-black/5 outline-none resize-none placeholder:text-gray-400 transition"
                        />
                    </div>

                    <div className="space-y-5">
                        <div>
                            <label className="flex items-center gap-2 text-xs font-bold text-gray-900 mb-3"><Sliders size={12}/> Model Config</label>
                            <div className="grid grid-cols-2 gap-2 mb-3">
                                <button onClick={() => setModel('nano-pro')} className={`py-2 px-3 rounded-lg text-xs font-semibold border transition text-center ${model === 'nano-pro' ? 'bg-black text-white border-black' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
                                    Pro (HQ)
                                </button>
                                <button onClick={() => setModel('nano-flash')} className={`py-2 px-3 rounded-lg text-xs font-semibold border transition text-center ${model === 'nano-flash' ? 'bg-black text-white border-black' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
                                    Flash (Fast)
                                </button>
                            </div>
                        </div>

                        <div>
                            <label className="flex items-center gap-2 text-xs font-bold text-gray-900 mb-3"><Ratio size={12}/> Aspect Ratio</label>
                            <div className="grid grid-cols-3 gap-2">
                                {['1:1', '16:9', '9:16'].map(r => (
                                    <button 
                                        key={r}
                                        onClick={() => setAspectRatio(r)} 
                                        className={`py-2 rounded-lg text-xs font-semibold border transition ${aspectRatio === r ? 'bg-gray-100 border-gray-200 text-black' : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-50'}`}>
                                        {r}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>

                    <div className="mt-auto space-y-3 pt-6 border-t border-gray-100">
                        <button 
                            onClick={handleGenerate} 
                            disabled={loading} 
                            className="w-full bg-black text-white py-3.5 rounded-xl font-bold hover:opacity-80 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-md"
                        >
                            {loading ? <Loader2 className="animate-spin" size={16}/> : <Sparkles size={16}/>}
                            Generate
                        </button>
                        
                        {model === 'nano-pro' && (
                            <button onClick={() => ensureApiKey(true)} className="w-full flex items-center justify-center gap-2 text-[10px] text-gray-400 hover:text-black transition">
                                <Key size={10}/> Manage Google Cloud Key
                            </button>
                        )}
                    </div>

                </div>
            </div>
        </div>
    );
};

export default ImageGenApp;
