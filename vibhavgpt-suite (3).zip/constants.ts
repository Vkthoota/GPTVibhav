
import { Tier, ModelType, ToolConfig, AppConfig } from './types';

export const YOUTUBE_API_KEY = "AIzaSyBqB5M2QWPevjyoXi62CRKeo1eRD2BVgwo";
export const ADMIN_PASSWORD = "Vibhav";
export const ACCESS_KEY = "vibhav-key"; 
export const UNLIMITED_KEY = "xset"; 

export const TEST_PAYMENT = {
    number: "6767 6767 6767 6767",
    date: "01/67",
    cvc: "670",
    name: "Test"
};

export const PROVIDERS = [
  { id: 'vibhav', name: 'VibhavGPT', placeholder: 'System Default' },
  { id: 'google', name: 'Google (Gemini)', placeholder: 'AIza...' },
  { id: 'openai', name: 'OpenAI (GPT)', placeholder: 'sk-...' },
  { id: 'anthropic', name: 'Anthropic (Claude)', placeholder: 'sk-ant-...' },
  { id: 'xai', name: 'xAI (Grok)', placeholder: 'xai-...' },
  { id: 'deepseek', name: 'DeepSeek', placeholder: 'sk-ds-...' },
  { id: 'moonshot', name: 'Moonshot AI (Kimi)', placeholder: 'sk-moon-...' }
];

export const MODEL_PROVIDER_MAP: Record<string, string> = {
  [ModelType.MAX]: 'vibhav', [ModelType.ULTRA]: 'vibhav', [ModelType.PLUS]: 'vibhav', 
  [ModelType.BOLT]: 'vibhav', [ModelType.MUSE]: 'vibhav', [ModelType.ATLAS]: 'vibhav',
  [ModelType.GPT_5_2_PRO]: 'openai', [ModelType.GPT_4O]: 'openai', 
  [ModelType.GPT_4_TURBO]: 'openai', [ModelType.GPT_5_2_THINKING]: 'openai', [ModelType.GPT_5_2_INSTANT]: 'openai',
  [ModelType.GEMINI_3_PRO]: 'google', [ModelType.GEMINI_3_THINKING]: 'google', [ModelType.GEMINI_3_FAST]: 'google', 
  [ModelType.GEMINI_3_BASE]: 'google', [ModelType.GEMINI_2_THINKING]: 'google', [ModelType.GEMINI_2_FAST]: 'google', 
  [ModelType.GEMINI_2_BASE]: 'google', [ModelType.GEMINI_2_5_FLASH_LITE]: 'google', [ModelType.GEMINI_1_5_PRO]: 'google', 
  [ModelType.GEMINI_1_5_FLASH]: 'google',
  [ModelType.CLAUDE_4_6_OPUS]: 'anthropic', [ModelType.CLAUDE_4_5_OPUS]: 'anthropic', [ModelType.CLAUDE_4_5_SONNET]: 'anthropic', 
  [ModelType.CLAUDE_4_5_HAIKU]: 'anthropic', [ModelType.CLAUDE_3_5_SONNET]: 'anthropic', [ModelType.CLAUDE_SONNET_4]: 'anthropic', 
  [ModelType.CLAUDE_OPUS_3]: 'anthropic', [ModelType.CLAUDE_HAIKU_3_5]: 'anthropic',
  [ModelType.GROK_4]: 'xai', [ModelType.GROK_4_1_THINKING]: 'xai', [ModelType.GROK_4_1_EXPERT]: 'xai', 
  [ModelType.GROK_4_1_FAST]: 'xai', [ModelType.GROK_4_1_AUTO]: 'xai', [ModelType.GROK_2]: 'xai',
  [ModelType.DEEPSEEK_R1]: 'deepseek', [ModelType.DEEPSEEK_V3]: 'deepseek', [ModelType.DEEPSEEK_V2]: 'deepseek',
  [ModelType.KIMI_K2_5_PRO]: 'moonshot', [ModelType.KIMI_K2_5_SWARM]: 'moonshot', [ModelType.KIMI_K2_5_AGENT]: 'moonshot', 
  [ModelType.KIMI_K2_5_THINKING]: 'moonshot', [ModelType.KIMI_K2_5_INSTANT]: 'moonshot'
};

export const MODEL_GROUPS = [
  {
    brand: 'VibhavGPT',
    models: [ModelType.MAX, ModelType.ULTRA, ModelType.PLUS, ModelType.BOLT, ModelType.ATLAS, ModelType.MUSE]
  },
  {
    brand: 'Google',
    models: [ModelType.GEMINI_3_PRO, ModelType.GEMINI_3_THINKING, ModelType.GEMINI_3_FAST, ModelType.GEMINI_3_BASE, ModelType.GEMINI_2_THINKING, ModelType.GEMINI_2_FAST, ModelType.GEMINI_2_BASE, ModelType.GEMINI_2_5_FLASH_LITE, ModelType.GEMINI_1_5_PRO, ModelType.GEMINI_1_5_FLASH]
  },
  {
    brand: 'OpenAI',
    models: [ModelType.GPT_5_2_PRO, ModelType.GPT_4O, ModelType.GPT_4_TURBO, ModelType.GPT_5_2_THINKING, ModelType.GPT_5_2_INSTANT]
  },
  {
    brand: 'Anthropic',
    models: [ModelType.CLAUDE_4_6_OPUS, ModelType.CLAUDE_4_5_OPUS, ModelType.CLAUDE_4_5_SONNET, ModelType.CLAUDE_4_5_HAIKU, ModelType.CLAUDE_3_5_SONNET, ModelType.CLAUDE_SONNET_4, ModelType.CLAUDE_OPUS_3, ModelType.CLAUDE_HAIKU_3_5]
  },
  {
    brand: 'xAI',
    models: [ModelType.GROK_4, ModelType.GROK_4_1_THINKING, ModelType.GROK_4_1_EXPERT, ModelType.GROK_4_1_FAST, ModelType.GROK_4_1_AUTO, ModelType.GROK_2]
  },
  {
    brand: 'DeepSeek',
    models: [ModelType.DEEPSEEK_R1, ModelType.DEEPSEEK_V3, ModelType.DEEPSEEK_V2]
  },
  {
    brand: 'Moonshot',
    models: [ModelType.KIMI_K2_5_PRO, ModelType.KIMI_K2_5_SWARM, ModelType.KIMI_K2_5_AGENT, ModelType.KIMI_K2_5_THINKING, ModelType.KIMI_K2_5_INSTANT]
  }
];

export const TIER_LIMITS = {
  [Tier.GUEST]: { daily: 0, monthly: 0 }, 
  [Tier.FREE]: { daily: 10, monthly: 25 }, 
  [Tier.EXPLORER]: { daily: 50, monthly: 500 },
  [Tier.PRO]: { daily: 200, monthly: 2000 },
  [Tier.UNLIMITED]: { daily: 999999, monthly: 999999 },
};

export const MODEL_COSTS: Record<string, number> = {
  [ModelType.MAX]: 10, [ModelType.ULTRA]: 8, [ModelType.PLUS]: 5, [ModelType.BOLT]: 2, [ModelType.MUSE]: 4, [ModelType.ATLAS]: 5,
  [ModelType.GPT_5_2_PRO]: 9, [ModelType.GPT_4O]: 4, [ModelType.GPT_4_TURBO]: 3, [ModelType.GPT_5_2_THINKING]: 10, [ModelType.GPT_5_2_INSTANT]: 2,
  [ModelType.GEMINI_3_PRO]: 4, [ModelType.GEMINI_3_THINKING]: 6, [ModelType.GEMINI_3_FAST]: 2, [ModelType.GEMINI_3_BASE]: 3,
  [ModelType.GEMINI_2_THINKING]: 5, [ModelType.GEMINI_2_FAST]: 2, [ModelType.GEMINI_2_BASE]: 2,
  [ModelType.GEMINI_2_5_FLASH_LITE]: 1, [ModelType.GEMINI_1_5_PRO]: 3, [ModelType.GEMINI_1_5_FLASH]: 1,
  [ModelType.DEEPSEEK_R1]: 5, [ModelType.DEEPSEEK_V3]: 3, [ModelType.DEEPSEEK_V2]: 2,
  [ModelType.KIMI_K2_5_PRO]: 4, [ModelType.KIMI_K2_5_SWARM]: 10, [ModelType.KIMI_K2_5_AGENT]: 6, [ModelType.KIMI_K2_5_THINKING]: 5, [ModelType.KIMI_K2_5_INSTANT]: 2,
  [ModelType.GROK_4]: 6, [ModelType.GROK_4_1_THINKING]: 8, [ModelType.GROK_4_1_EXPERT]: 7, [ModelType.GROK_4_1_FAST]: 3, [ModelType.GROK_4_1_AUTO]: 5, [ModelType.GROK_2]: 4,
  [ModelType.CLAUDE_4_6_OPUS]: 10, [ModelType.CLAUDE_4_5_OPUS]: 9, [ModelType.CLAUDE_4_5_SONNET]: 6, [ModelType.CLAUDE_4_5_HAIKU]: 2, 
  [ModelType.CLAUDE_3_5_SONNET]: 4, [ModelType.CLAUDE_SONNET_4]: 5, [ModelType.CLAUDE_OPUS_3]: 6, [ModelType.CLAUDE_HAIKU_3_5]: 2,
};

// Maps internal ModelTypes to ACTUAL Provider API Model IDs
export const MODEL_MAPPING: Record<string, string> = {
  // --- VibhavGPT (Uses Google Backend) ---
  [ModelType.MAX]: 'gemini-3-pro-preview', 
  [ModelType.ULTRA]: 'gemini-3-pro-preview',
  [ModelType.PLUS]: 'gemini-3-pro-preview',
  [ModelType.BOLT]: 'gemini-3-flash-preview', 
  [ModelType.MUSE]: 'gemini-3-pro-preview',
  [ModelType.ATLAS]: 'gemini-3-flash-preview',

  // --- Google ---
  [ModelType.GEMINI_3_PRO]: 'gemini-3-pro-preview',
  [ModelType.GEMINI_3_THINKING]: 'gemini-3-pro-preview',
  [ModelType.GEMINI_3_FAST]: 'gemini-3-flash-preview',
  [ModelType.GEMINI_3_BASE]: 'gemini-3-pro-preview',
  [ModelType.GEMINI_2_5_FLASH_LITE]: 'gemini-2.5-flash-lite-latest',
  [ModelType.GEMINI_1_5_PRO]: 'gemini-1.5-pro',
  [ModelType.GEMINI_1_5_FLASH]: 'gemini-1.5-flash',
  [ModelType.GEMINI_2_THINKING]: 'gemini-2.0-flash-thinking-exp-01-21',
  [ModelType.GEMINI_2_FAST]: 'gemini-2.0-flash-exp',
  [ModelType.GEMINI_2_BASE]: 'gemini-2.0-pro-exp-02-05',

  // --- OpenAI ---
  [ModelType.GPT_4O]: 'gpt-4o',
  [ModelType.GPT_4_TURBO]: 'gpt-4-turbo',
  [ModelType.GPT_5_2_PRO]: 'gpt-4o', 
  [ModelType.GPT_5_2_THINKING]: 'o1-preview', 
  [ModelType.GPT_5_2_INSTANT]: 'gpt-4o-mini',

  // --- Anthropic ---
  [ModelType.CLAUDE_3_5_SONNET]: 'claude-3-5-sonnet-20240620',
  [ModelType.CLAUDE_OPUS_3]: 'claude-3-opus-20240229',
  [ModelType.CLAUDE_HAIKU_3_5]: 'claude-3-haiku-20240307',
  [ModelType.CLAUDE_4_6_OPUS]: 'claude-3-opus-20240229', 
  [ModelType.CLAUDE_4_5_OPUS]: 'claude-3-opus-20240229', 
  [ModelType.CLAUDE_4_5_SONNET]: 'claude-3-5-sonnet-20240620', 
  [ModelType.CLAUDE_4_5_HAIKU]: 'claude-3-haiku-20240307', 
  [ModelType.CLAUDE_SONNET_4]: 'claude-3-5-sonnet-20240620',

  // --- xAI ---
  [ModelType.GROK_2]: 'grok-beta',
  [ModelType.GROK_4]: 'grok-beta',
  [ModelType.GROK_4_1_THINKING]: 'grok-beta',
  [ModelType.GROK_4_1_EXPERT]: 'grok-beta',
  [ModelType.GROK_4_1_FAST]: 'grok-beta',
  [ModelType.GROK_4_1_AUTO]: 'grok-beta',

  // --- DeepSeek ---
  [ModelType.DEEPSEEK_V3]: 'deepseek-chat',
  [ModelType.DEEPSEEK_R1]: 'deepseek-reasoner',
  [ModelType.DEEPSEEK_V2]: 'deepseek-chat',

  // --- Moonshot ---
  [ModelType.KIMI_K2_5_PRO]: 'moonshot-v1-32k',
  [ModelType.KIMI_K2_5_INSTANT]: 'moonshot-v1-8k',
  [ModelType.KIMI_K2_5_THINKING]: 'moonshot-v1-128k',
  [ModelType.KIMI_K2_5_AGENT]: 'moonshot-v1-32k',
  [ModelType.KIMI_K2_5_SWARM]: 'moonshot-v1-32k',
};

export const MODEL_INFO: Record<string, string> = {
    // Vibhav
    [ModelType.MAX]: "Good for: Master-level reasoning & synthesis.",
    [ModelType.BOLT]: "Good for: Instant answers & quick chats.",
    [ModelType.PLUS]: "Good for: Balanced research & writing.",
    [ModelType.ULTRA]: "Good for: Deep dive analysis & complex tasks.",
    [ModelType.MUSE]: "Good for: Creative writing & storytelling.",
    [ModelType.ATLAS]: "Good for: Real-time web search & news.",
    
    // OpenAI
    [ModelType.GPT_5_2_PRO]: "Good for: Advanced logical reasoning.",
    [ModelType.GPT_5_2_THINKING]: "Good for: Step-by-step math & science.",
    [ModelType.GPT_5_2_INSTANT]: "Good for: Fast, everyday tasks.",
    [ModelType.GPT_4O]: "Good for: Multimodal input & versatility.",
    [ModelType.GPT_4_TURBO]: "Good for: Large context documents.",

    // Google
    [ModelType.GEMINI_3_PRO]: "Good for: Multimodal understanding.",
    [ModelType.GEMINI_3_THINKING]: "Good for: Complex problem solving.",
    [ModelType.GEMINI_3_FAST]: "Good for: High speed processing.",
    [ModelType.GEMINI_3_BASE]: "Good for: General purpose tasks.",
    [ModelType.GEMINI_2_THINKING]: "Good for: Experimental reasoning.",
    [ModelType.GEMINI_2_FAST]: "Good for: Low latency responses.",
    [ModelType.GEMINI_2_BASE]: "Good for: Balanced performance.",
    [ModelType.GEMINI_2_5_FLASH_LITE]: "Good for: Extremely fast, cheap tasks.",
    [ModelType.GEMINI_1_5_PRO]: "Good for: Massive context windows.",
    [ModelType.GEMINI_1_5_FLASH]: "Good for: High efficiency tasks.",

    // Anthropic
    [ModelType.CLAUDE_4_6_OPUS]: "Good for: Nuanced, human-like writing.",
    [ModelType.CLAUDE_4_5_OPUS]: "Good for: High quality creative output.",
    [ModelType.CLAUDE_4_5_SONNET]: "Good for: Coding & technical tasks.",
    [ModelType.CLAUDE_4_5_HAIKU]: "Good for: Quick summaries & translations.",
    [ModelType.CLAUDE_SONNET_4]: "Good for: Balanced intelligence.",
    [ModelType.CLAUDE_OPUS_3]: "Good for: Long-form content.",
    [ModelType.CLAUDE_HAIKU_3_5]: "Good for: Fast, simple queries.",
    [ModelType.CLAUDE_3_5_SONNET]: "Good for: Coding assistance.",

    // xAI
    [ModelType.GROK_4]: "Good for: Unfiltered knowledge & wit.",
    [ModelType.GROK_4_1_THINKING]: "Good for: Deep analytical thinking.",
    [ModelType.GROK_4_1_EXPERT]: "Good for: Specialized domain knowledge.",
    [ModelType.GROK_4_1_FAST]: "Good for: Rapid conversational responses.",
    [ModelType.GROK_4_1_AUTO]: "Good for: Automatic mode switching.",
    [ModelType.GROK_2]: "Good for: Standard conversational tasks.",

    // DeepSeek
    [ModelType.DEEPSEEK_R1]: "Good for: Math & logic reasoning.",
    [ModelType.DEEPSEEK_V3]: "Good for: Coding & general chat.",
    [ModelType.DEEPSEEK_V2]: "Good for: Efficient text generation.",

    // Moonshot
    [ModelType.KIMI_K2_5_PRO]: "Good for: Professional context handling.",
    [ModelType.KIMI_K2_5_SWARM]: "Good for: Multi-perspective analysis.",
    [ModelType.KIMI_K2_5_AGENT]: "Good for: Task execution.",
    [ModelType.KIMI_K2_5_THINKING]: "Good for: Long-chain reasoning.",
    [ModelType.KIMI_K2_5_INSTANT]: "Good for: Instantaneous replies.",
};

export const MODEL_COMPARISON_DATA = [
  {
    name: ModelType.MAX,
    provider: 'VibhavGPT',
    strengths: 'The ultimate synthesis engine. Fuses reasoning traces from GPT-5.2, Claude 4.6, and Gemini 3.',
    weaknesses: 'High credit cost. Slower generation due to multi-agent fusion.',
    bestFor: 'Complex decision making, master-level writing, ultimate logic.'
  },
  {
    name: ModelType.BOLT,
    provider: 'VibhavGPT',
    strengths: 'Optimized for speed. Virtually instantaneous responses.',
    weaknesses: 'Limited depth on highly abstract philosophical queries.',
    bestFor: 'Daily assistance, translations, quick lookups.'
  },
  {
    name: ModelType.GEMINI_3_PRO,
    provider: 'Google',
    strengths: 'Native understanding of images, video, and audio. Blazing fast processing.',
    weaknesses: 'Occasionally verbose in simple chat settings.',
    bestFor: 'Multimodal tasks, rapid brainstorming, large context analysis.'
  }
];

export const TOOLS: ToolConfig[] = [
  { id: 'detector', name: 'AI Detector', description: 'Check if text is AI generated', cost: 1, icon: 'ShieldAlert' },
  { id: 'humanizer', name: 'Humanizer', description: 'Make AI text sound human', cost: 1, icon: 'UserCheck' },
  { id: 'youtube', name: 'YouTube', description: 'Analyze videos with context', cost: 0, icon: 'Youtube' }, 
  { id: 'calculator', name: 'VibhavCalc', description: 'Advanced Neural Graphing Calculator', cost: 0, icon: 'Calculator' },
  { id: 'tone', name: 'Tone Analyzer', description: 'Analyze emotion & context', cost: 1, icon: 'Smile' },
  { id: 'qr', name: 'QR Generator', description: 'Customizable QR codes', cost: 0, icon: 'QrCode' },
  { id: 'summarizer', name: 'Summarizer', description: 'Summarize long text', cost: 1, icon: 'FileText' },
  { id: 'grader', name: 'AI Grader', description: 'Grade homework assignments', cost: 1, icon: 'GraduationCap' },
  { id: 'calendar', name: 'Calendar Maker', description: 'Natural language to Event', cost: 1, icon: 'Calendar' },
  { id: 'homework', name: 'Homework Helper', description: 'Get tips and help', cost: 1, icon: 'BookOpen' },
  { id: 'paraphraser', name: 'Paraphraser', description: 'Rewrite text with style', cost: 1, icon: 'RefreshCw' },
  { id: 'plagiarism', name: 'Plagiarism Detector', description: 'Find copied content', cost: 1.5, icon: 'Search' },
  { id: 'factcheck', name: 'Fact Checker', description: 'Verify accuracy & claims', cost: 1.5, icon: 'CheckCircle' },
  { id: 'translator', name: 'Translator', description: 'Pro multi-language translation', cost: 1, icon: 'Languages' },
  { id: 'resume', name: 'Resume Builder', description: 'Build professional resumes', cost: 2, icon: 'Briefcase' },
  { id: 'email', name: 'Email Writer', description: 'Draft professional emails', cost: 0.5, icon: 'Mail' },
  { id: 'regex', name: 'Regex Gen', description: 'Generate Regular Expressions', cost: 1, icon: 'Code2' },
];

export const APPS: AppConfig[] = [
  { id: 'videostudio', name: 'VidCraft', description: 'Generate high-quality videos using Veo (Paid Only)', icon: 'Video' },
  { id: 'imagine', name: 'Image Engine', description: 'Create stunning images with Nano Banana (Paid Only)', icon: 'Image' },
  { id: 'codecloud', name: 'CodeCloud', description: 'AI Powered Code Editor & Project Manager', icon: 'Code' },
  { id: 'studio', name: 'VibhavGPT Studio', description: 'Create and fine-tune custom AI models', icon: 'Sliders' },
  { id: 'study', name: 'Study', description: 'Flashcards and Quiz generator', icon: 'Brain' },
  { id: 'chef', name: 'Chef', description: 'Recipe generator and nutrition facts', icon: 'Utensils' },
  { id: 'writer', name: 'Pro Writer', description: 'Long-form content creation suite', icon: 'PenTool' },
  { id: 'math', name: 'Math Solver', description: 'Step-by-step math problem solver', icon: 'Sigma' },
];
