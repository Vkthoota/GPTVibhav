import React, { useState } from 'react';
import { Sparkles, ArrowRight, Zap, Cpu, Brain, X, Shield, FileText, Video, Command } from 'lucide-react';
import { ADMIN_PASSWORD } from './constants';
import { User, Tier } from './types';

const LandingPage = ({ onAccessRequest, onLogin }: { onAccessRequest: () => void, onLogin: (u: User) => void }) => {
  const [adminOpen, setAdminOpen] = useState(false);
  const [pass, setPass] = useState("");

  const handleAdmin = (e: React.FormEvent) => {
      e.preventDefault();
      if (pass.trim() === ADMIN_PASSWORD) { 
          const adminUser: User = {
             username: "Admin",
             isAuthenticated: true,
             tier: Tier.UNLIMITED,
             theme: 'light',
             credits: { dailyUsed: 0, monthlyUsed: 0, lastDailyReset: new Date().toISOString(), lastMonthlyReset: new Date().toISOString() },
             apiKeys: {
                 vibhav: "SYSTEM_ACCESS_GRANTED",
                 openai: "SYSTEM_ACCESS_GRANTED",
                 anthropic: "SYSTEM_ACCESS_GRANTED",
                 xai: "SYSTEM_ACCESS_GRANTED",
                 deepseek: "SYSTEM_ACCESS_GRANTED",
                 moonshot: "SYSTEM_ACCESS_GRANTED",
                 google: "SYSTEM_ACCESS_GRANTED"
             }, 
             createdModels: [], savedRecipes: [], codeProjects: [], studySets: [],
             accessKey: 'admin-session' 
          };
          onLogin(adminUser);
          setAdminOpen(false); 
      } else {
          alert("Incorrect Password"); 
      }
  };
  
  return (
    <div className="min-h-screen bg-white text-zinc-900 font-sans selection:bg-blue-100 selection:text-blue-900">
      <header className="px-8 py-6 flex justify-between items-center max-w-7xl mx-auto">
         <div className="flex items-center gap-2 font-bold text-xl tracking-tight">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-red-600 rounded-lg flex items-center justify-center text-white"><Sparkles size={16}/></div>
            VibhavGPT
         </div>
         <button onClick={() => setAdminOpen(true)} className="text-xs font-bold text-zinc-400 hover:text-blue-600 uppercase tracking-widest transition">Admin Login</button>
      </header>

      <main className="container mx-auto px-6 py-24 text-center">
         <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-xs font-medium text-blue-600 mb-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
             <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span> v4.2 Now Live: Gemini 3 & GPT-5
         </div>
         <h1 className="text-6xl md:text-8xl font-extrabold mb-8 tracking-tighter leading-[0.9] animate-in fade-in slide-in-from-bottom-6 duration-700">
            Intelligence,<br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600">Amplified.</span>
         </h1>
         <p className="text-xl md:text-2xl text-zinc-500 max-w-2xl mx-auto mb-12 font-light leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-700 delay-100">
            The unified workspace for the world's most advanced AI models. Create, code, and reason with zero friction.
         </p>
         <div className="flex justify-center gap-4 animate-in fade-in slide-in-from-bottom-10 duration-700 delay-200">
             <button onClick={onAccessRequest} className="bg-gradient-to-r from-blue-600 to-red-500 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:opacity-90 transition shadow-xl hover:-translate-y-1 flex items-center gap-2 shadow-blue-600/30">
                 Start Creating <ArrowRight size={20}/>
             </button>
         </div>

         <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mt-24">
             {[
                 { name: "GPT-5.2 Pro", icon: <Zap className="text-yellow-500"/>, desc: "Reasoning" },
                 { name: "Gemini 3", icon: <Sparkles className="text-blue-500"/>, desc: "Multimodal" },
                 { name: "Claude 4.6", icon: <Brain className="text-orange-500"/>, desc: "Writing" },
                 { name: "VidCraft", icon: <Video className="text-red-500"/>, desc: "Video Gen" },
             ].map((m,i) => (
                 <div key={i} className="p-6 bg-zinc-50 rounded-3xl border border-zinc-100 hover:border-zinc-200 transition text-left">
                     <div className="mb-4">{m.icon}</div>
                     <div className="font-bold text-zinc-900">{m.name}</div>
                     <div className="text-xs text-zinc-500">{m.desc}</div>
                 </div>
             ))}
         </div>
      </main>

      {/* Admin Modal */}
      {adminOpen && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
              <div className="bg-white p-8 rounded-3xl w-full max-w-sm shadow-2xl">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="font-bold text-lg">System Access</h3>
                      <button onClick={()=>setAdminOpen(false)} className="p-2 hover:bg-zinc-100 rounded-full"><X size={18}/></button>
                  </div>
                  <form onSubmit={handleAdmin}>
                      <input type="password" className="border-2 border-zinc-100 p-3 w-full mb-4 rounded-xl outline-none focus:border-blue-600 transition text-center font-mono text-lg" placeholder="••••••" value={pass} onChange={e=>setPass(e.target.value)} autoFocus/>
                      <button type="submit" className="bg-gradient-to-r from-blue-600 to-red-500 text-white px-4 py-3 rounded-xl w-full font-bold hover:opacity-90 transition">Unlock Admin</button>
                  </form>
              </div>
          </div>
      )}
    </div>
  );
};

export default LandingPage;