
import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Sparkles, Copy, Download, Share2, Send, Image as ImageIcon, QrCode, PlayCircle, Layers, CheckCircle, Calculator as CalcIcon, Mail as MailIcon, Languages, FileText, Briefcase, GraduationCap, Scale, Scan, FileCode, BookOpen, RefreshCw, AlignLeft, List, Scissors, Code2, Calendar as CalendarIcon, AlertTriangle, Search, UserCheck, Smile, Activity, Trash2, ChevronUp, ChevronDown, Loader2, Youtube as YoutubeIcon, Check, X, RotateCcw, BarChart3, Shield } from 'lucide-react';
import { User, ToolConfig, ModelType } from './types';
import { generateAIResponse } from './services/geminiService';
import MarkdownRenderer from './components/MarkdownRenderer';
import { YouTubeSearchModal } from './Modals';
import { Type } from "@google/genai";

interface ToolPageProps {
    tool: ToolConfig;
    user: User;
    updateCredits: (cost: number) => boolean;
    onBack: () => void;
}

const TOOL_ENGINES: Record<string, { id: string; name: string; description: string; promptContext: string }[]> = {
    'detector': [
        { 
            id: 'turnitin', 
            name: 'Academic Strict', 
            description: 'Strict analysis on structure & perplexity.', 
            promptContext: "You are an AI detection system. Analyze the text. Return JSON: { \"score\": number (0-100, where 100 is human, 0 is AI), \"verdict\": string ('Likely Human', 'Mixed', 'Likely AI'), \"analysis\": string (detailed explanation) }." 
        },
        { 
            id: 'gptzero', 
            name: 'Burstiness Check', 
            description: 'Focuses on sentence variance.', 
            promptContext: "Analyze for AI patterns focusing on burstiness and perplexity. Return JSON: { \"score\": number (0-100, where 100 is human), \"verdict\": string, \"analysis\": string }." 
        }
    ]
};

const ToolPage: React.FC<ToolPageProps> = ({ tool, user, updateCredits, onBack }) => {
    const [input, setInput] = useState("");
    const [output, setOutput] = useState<any>(null); // output can be object (for JSON tools) or string
    const [loading, setLoading] = useState(false);
    const [youtubeModalOpen, setYoutubeModalOpen] = useState(false);
    
    // Engine State
    const availableEngines = TOOL_ENGINES[tool.id];
    const [selectedEngineId, setSelectedEngineId] = useState<string>(availableEngines ? availableEngines[0].id : "");

    // Specialized States
    const [calcExpression, setCalcExpression] = useState("");
    const [calcHistory, setCalcHistory] = useState<string[]>([]);
    const [calcMode, setCalcMode] = useState<'standard' | 'graph'>('standard');
    const [graphEquation, setGraphEquation] = useState("sin(x)");
    const canvasRef = useRef<HTMLCanvasElement>(null);
    
    const [ytData, setYtData] = useState({ url: "", creator: "", genre: "", focus: "Summarize Video" });
    const [qrData, setQrData] = useState({ content: "", color: "000000", bgcolor: "ffffff" });
    
    // Translation State
    const [sourceLang, setSourceLang] = useState("Auto");
    const [targetLang, setTargetLang] = useState("Spanish");
    
    // General Text Options
    const [textTone, setTextTone] = useState("Professional");
    const [textLength, setTextLength] = useState("Medium");

    useEffect(() => {
        if (availableEngines) setSelectedEngineId(availableEngines[0].id);
        setInput(""); setOutput(null); setCalcExpression(""); setCalcHistory([]); setCalcMode('standard');
    }, [tool.id]);

    useEffect(() => {
        if (calcMode === 'graph' && canvasRef.current) drawGraph();
    }, [calcMode, graphEquation]);

    const drawGraph = () => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        const width = canvas.width; const height = canvas.height; const scale = 40; const step = 0.1;

        ctx.clearRect(0, 0, width, height); 
        ctx.strokeStyle = '#e2e8f0'; ctx.lineWidth = 1; ctx.beginPath();
        for (let x = 0; x < width; x += scale) { ctx.moveTo(x, 0); ctx.lineTo(x, height); }
        for (let y = 0; y < height; y += scale) { ctx.moveTo(0, y); ctx.lineTo(width, y); }
        ctx.stroke();

        ctx.strokeStyle = '#94a3b8'; ctx.lineWidth = 2; ctx.beginPath();
        ctx.moveTo(width / 2, 0); ctx.lineTo(width / 2, height); ctx.moveTo(0, height / 2); ctx.lineTo(width, height / 2);
        ctx.stroke();

        ctx.strokeStyle = '#3b82f6'; ctx.lineWidth = 3; ctx.beginPath();
        let first = true;
        for (let x_val = -width / (2 * scale); x_val < width / (2 * scale); x_val += step) {
            try {
                const expr = graphEquation.replace(/x/g, `(${x_val})`).replace(/sin/g, 'Math.sin').replace(/cos/g, 'Math.cos').replace(/tan/g, 'Math.tan');
                const y_val = eval(expr);
                const x_pixel = width / 2 + x_val * scale; const y_pixel = height / 2 - y_val * scale;
                if (first) { ctx.moveTo(x_pixel, y_pixel); first = false; } else { ctx.lineTo(x_pixel, y_pixel); }
            } catch (e) {}
        }
        ctx.stroke();
    };

    const handleRun = async () => {
        if (tool.cost > 0 && !updateCredits(tool.cost)) return;
        setLoading(true); setOutput(null);
        
        const apiKey = user.apiKeys?.google || process.env.API_KEY || '';

        try {
            // --- Local Tools ---
            if (tool.id === 'qr') {
                const color = qrData.color.replace('#', ''); const bg = qrData.bgcolor.replace('#', '');
                const url = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(qrData.content)}&color=${color}&bgcolor=${bg}&margin=10`;
                setOutput(url); setLoading(false); return;
            }
            if (tool.id === 'calculator') {
                if (calcMode === 'standard') {
                    try {
                        const cleanExpr = calcExpression.replace(/×/g, '*').replace(/÷/g, '/').replace(/\^/g, '**');
                        const result = eval(cleanExpr);
                        setOutput(result.toString());
                        setCalcHistory(prev => [calcExpression + " = " + result, ...prev].slice(0, 10));
                    } catch (e) { setOutput("Error"); }
                } else { setGraphEquation(calcExpression); }
                setLoading(false); return;
            }

            // --- AI Tools ---
            let systemInstruction = ""; 
            let promptText = input; 
            let model: ModelType | string = ModelType.BOLT;
            let responseSchema: any = undefined; 
            let responseMimeType: string | undefined = undefined;

            // Engine override
            const engineConfig = availableEngines?.find(e => e.id === selectedEngineId);
            if (engineConfig) systemInstruction = engineConfig.promptContext;

            switch (tool.id) {
                case 'detector':
                    model = ModelType.GEMINI_1_5_FLASH; // Fast & cheap
                    promptText = `Analyze this text: "${input}"`;
                    responseMimeType = "application/json"; // Enforced by engine config usually
                    break;
                case 'humanizer': systemInstruction = `Rewrite to sound human. Tone: ${textTone}. Length: ${textLength}.`; break;
                case 'youtube': 
                    promptText = `Video: ${ytData.url}. Creator: ${ytData.creator}. Task: ${ytData.focus}. Provide a detailed response.`; 
                    model = ModelType.GEMINI_3_FAST; 
                    break;
                case 'summarizer': systemInstruction = `Summarize text. Length: ${textLength}. Tone: ${textTone}. Use markdown headers.`; break;
                case 'translator': systemInstruction = `Translate from ${sourceLang} to ${targetLang}. Preserve original meaning and tone.`; break;
                case 'email': systemInstruction = `Write a ${textTone} email. Context: ${input}`; break;
                case 'resume': systemInstruction = "Format as professional resume markdown."; model = ModelType.GEMINI_3_FAST; break;
                case 'grader': systemInstruction = "Grade this assignment. Provide letter grade and feedback."; break;
                default: systemInstruction = `You are a helpful assistant specialized in ${tool.name}.`; break;
            }

            const res = await generateAIResponse({ modelName: model, prompt: promptText, systemInstruction, apiKey, responseSchema, responseMimeType });
            
            // Post-processing for JSON tools
            if (tool.id === 'detector' || responseMimeType === 'application/json') {
                try {
                    setOutput(JSON.parse(res.text));
                } catch (e) {
                    setOutput(res.text); // Fallback
                }
            } else {
                setOutput(res.text);
            }

        } catch (e) { setOutput("An error occurred."); } 
        finally { setLoading(false); }
    };

    // --- Specialized Renderers ---

    const renderDetector = () => (
        <div className="flex flex-col md:flex-row gap-6 h-full">
            <div className="flex-1 flex flex-col">
                <textarea 
                    value={input} 
                    onChange={e => setInput(e.target.value)} 
                    placeholder="Paste text to check for AI generation..."
                    className="flex-1 bg-gray-50 border border-gray-200 rounded-2xl p-6 outline-none resize-none text-base focus:ring-2 focus:ring-blue-100 transition"
                />
            </div>
            <div className="w-full md:w-96 bg-white border border-gray-200 rounded-2xl p-6 flex flex-col items-center justify-center relative overflow-hidden">
                {loading ? <Loader2 className="animate-spin text-blue-600" size={32}/> : output ? (
                    typeof output === 'object' ? (
                        <div className="text-center w-full animate-in fade-in zoom-in duration-500">
                             <div className="relative w-40 h-40 mx-auto mb-6 flex items-center justify-center">
                                 <svg className="w-full h-full transform -rotate-90">
                                     <circle cx="80" cy="80" r="70" stroke="#f1f5f9" strokeWidth="12" fill="transparent"/>
                                     <circle cx="80" cy="80" r="70" stroke={output.score > 80 ? "#22c55e" : output.score > 50 ? "#eab308" : "#ef4444"} strokeWidth="12" fill="transparent" strokeDasharray={440} strokeDashoffset={440 - (440 * output.score) / 100} className="transition-all duration-1000 ease-out"/>
                                 </svg>
                                 <div className="absolute inset-0 flex flex-col items-center justify-center">
                                     <span className="text-3xl font-bold text-gray-800">{output.score}%</span>
                                     <span className="text-[10px] uppercase text-gray-400 font-bold">Human</span>
                                 </div>
                             </div>
                             <h3 className="text-xl font-bold text-gray-900 mb-2">{output.verdict}</h3>
                             <p className="text-sm text-gray-500 bg-gray-50 p-4 rounded-xl text-left border border-gray-100">{output.analysis}</p>
                        </div>
                    ) : <div className="text-red-500">Error parsing result.</div>
                ) : (
                    <div className="text-center text-gray-400">
                        <Shield size={48} className="mx-auto mb-4 opacity-20"/>
                        <p>Run check to see authenticity score.</p>
                    </div>
                )}
            </div>
        </div>
    );

    const renderTranslator = () => (
        <div className="flex flex-col h-full gap-4">
            <div className="flex items-center gap-4 bg-gray-100 p-2 rounded-xl border border-gray-200">
                <select value={sourceLang} onChange={e => setSourceLang(e.target.value)} className="flex-1 bg-white p-2 rounded-lg text-sm font-medium outline-none border border-gray-200">
                    <option>Auto</option><option>English</option><option>Spanish</option><option>French</option><option>German</option><option>Chinese</option><option>Japanese</option>
                </select>
                <ArrowLeft size={16} className="text-gray-400 rotate-180"/>
                <select value={targetLang} onChange={e => setTargetLang(e.target.value)} className="flex-1 bg-white p-2 rounded-lg text-sm font-medium outline-none border border-gray-200">
                    <option>Spanish</option><option>English</option><option>French</option><option>German</option><option>Chinese</option><option>Japanese</option><option>Hindi</option>
                </select>
            </div>
            <div className="flex-1 flex flex-col md:flex-row gap-4">
                 <textarea 
                    value={input} 
                    onChange={e => setInput(e.target.value)} 
                    placeholder="Enter text..." 
                    className="flex-1 bg-white border border-gray-200 p-6 rounded-2xl resize-none outline-none focus:ring-2 focus:ring-blue-100 text-lg"
                 />
                 <div className="flex-1 bg-blue-50/50 border border-blue-100 p-6 rounded-2xl overflow-y-auto relative">
                     {loading ? <div className="absolute inset-0 flex items-center justify-center"><Loader2 className="animate-spin text-blue-600"/></div> : 
                     <div className="text-lg text-gray-800 whitespace-pre-wrap">{output || <span className="text-gray-400 italic">Translation will appear here...</span>}</div>}
                     {output && <button onClick={() => navigator.clipboard.writeText(output)} className="absolute top-4 right-4 p-2 text-blue-400 hover:text-blue-600"><Copy size={16}/></button>}
                 </div>
            </div>
        </div>
    );

    const renderQr = () => (
        <div className="flex flex-col md:flex-row gap-8 h-full">
            <div className="w-full md:w-80 space-y-6">
                <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Data Content</label>
                    <textarea value={qrData.content} onChange={e => setQrData({...qrData, content: e.target.value})} className="w-full p-4 border border-gray-200 rounded-xl outline-none focus:border-blue-500 h-32 resize-none" placeholder="https://example.com"/>
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Foreground</label>
                        <div className="flex items-center gap-2 border border-gray-200 p-2 rounded-xl bg-white">
                            <input type="color" value={`#${qrData.color}`} onChange={e => setQrData({...qrData, color: e.target.value.substring(1)})} className="w-8 h-8 rounded cursor-pointer border-none"/>
                            <span className="text-xs font-mono text-gray-500">#{qrData.color}</span>
                        </div>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Background</label>
                        <div className="flex items-center gap-2 border border-gray-200 p-2 rounded-xl bg-white">
                             <input type="color" value={`#${qrData.bgcolor}`} onChange={e => setQrData({...qrData, bgcolor: e.target.value.substring(1)})} className="w-8 h-8 rounded cursor-pointer border-none"/>
                             <span className="text-xs font-mono text-gray-500">#{qrData.bgcolor}</span>
                        </div>
                    </div>
                </div>
            </div>
            <div className="flex-1 bg-gray-100 rounded-3xl flex items-center justify-center relative border border-gray-200 border-dashed">
                {output ? (
                    <div className="bg-white p-6 rounded-2xl shadow-xl flex flex-col items-center animate-in fade-in zoom-in">
                        <img src={output} alt="QR" className="w-64 h-64 mix-blend-multiply"/>
                        <a href={output} download="qr.png" className="mt-6 flex items-center gap-2 text-sm font-bold text-gray-600 hover:text-black">
                            <Download size={16}/> Download PNG
                        </a>
                    </div>
                ) : (
                    <div className="text-gray-400 flex flex-col items-center">
                        <QrCode size={48} className="mb-2 opacity-20"/>
                        <span className="text-sm font-medium">Preview Area</span>
                    </div>
                )}
            </div>
        </div>
    );

    const renderCalculator = () => (
        <div className="h-full flex flex-col md:flex-row gap-6 max-w-5xl mx-auto">
             <div className="flex-1 flex flex-col">
                 <div className="bg-white border border-gray-200 rounded-2xl p-6 mb-4 shadow-sm flex-1 flex flex-col justify-end">
                     <div className="text-right text-gray-400 text-sm h-6">{calcMode === 'standard' ? (calcHistory[0] || '') : 'Graph Mode'}</div>
                     <input 
                        value={calcExpression} 
                        onChange={e => setCalcExpression(e.target.value)}
                        className="w-full text-right text-4xl font-mono outline-none bg-transparent placeholder-gray-200"
                        placeholder="0"
                     />
                     {calcMode === 'standard' && <div className="text-right text-xl text-blue-600 font-bold mt-2 h-8">{output || ''}</div>}
                 </div>
                 
                 <div className="grid grid-cols-4 gap-3">
                     {['C', '(', ')', '÷', '7', '8', '9', '×', '4', '5', '6', '-', '1', '2', '3', '+', '0', '.', '^', '='].map(k => (
                         <button 
                             key={k}
                             onClick={() => {
                                 if (k === 'C') { setCalcExpression(""); setOutput(null); }
                                 else if (k === '=') handleRun();
                                 else setCalcExpression(prev => prev + k);
                             }}
                             className={`p-4 rounded-xl font-bold text-xl shadow-sm transition active:scale-95 ${['÷', '×', '-', '+', '^', '='].includes(k) ? 'bg-blue-600 text-white' : k === 'C' ? 'bg-red-50 text-red-500' : 'bg-white hover:bg-gray-50 text-gray-700'}`}
                         >
                             {k}
                         </button>
                     ))}
                     <button onClick={() => setCalcMode(calcMode === 'standard' ? 'graph' : 'standard')} className="col-span-4 bg-gray-100 text-gray-600 p-3 rounded-xl font-bold text-sm hover:bg-gray-200 mt-2">
                         Switch to {calcMode === 'standard' ? 'Graphing' : 'Standard'}
                     </button>
                 </div>
             </div>
             
             {/* History / Graph Panel */}
             <div className="w-full md:w-80 bg-gray-50 border border-gray-200 rounded-2xl p-4 overflow-hidden flex flex-col">
                 <h3 className="text-xs font-bold text-gray-500 uppercase mb-4">{calcMode === 'standard' ? 'History' : 'Graph Plot'}</h3>
                 {calcMode === 'standard' ? (
                     <div className="space-y-2 overflow-y-auto flex-1 font-mono text-sm">
                         {calcHistory.map((h, i) => (
                             <div key={i} className="p-3 bg-white rounded-lg shadow-sm text-right text-gray-600">{h}</div>
                         ))}
                         {calcHistory.length === 0 && <div className="text-center text-gray-400 mt-10">No history</div>}
                     </div>
                 ) : (
                     <div className="flex items-center justify-center h-full bg-white rounded-xl border border-gray-200">
                         <canvas ref={canvasRef} width={280} height={350} className="w-full h-full"/>
                     </div>
                 )}
             </div>
        </div>
    );

    const renderGenericEditor = () => (
        <div className="flex flex-col h-full">
            {/* Toolbar */}
            <div className="flex items-center gap-4 mb-4 overflow-x-auto pb-2">
                <div className="flex bg-gray-100 p-1 rounded-lg shrink-0">
                    {['Short', 'Medium', 'Long'].map(l => (
                        <button key={l} onClick={() => setTextLength(l)} className={`px-3 py-1.5 text-xs font-bold rounded-md transition ${textLength === l ? 'bg-white shadow text-black' : 'text-gray-500 hover:text-black'}`}>{l}</button>
                    ))}
                </div>
                <div className="flex bg-gray-100 p-1 rounded-lg shrink-0">
                    {['Professional', 'Casual', 'Academic', 'Creative'].map(t => (
                        <button key={t} onClick={() => setTextTone(t)} className={`px-3 py-1.5 text-xs font-bold rounded-md transition ${textTone === t ? 'bg-white shadow text-black' : 'text-gray-500 hover:text-black'}`}>{t}</button>
                    ))}
                </div>
            </div>

            <div className="flex-1 flex flex-col md:flex-row gap-6 min-h-0">
                <div className="flex-1 flex flex-col">
                     <textarea 
                        value={input} 
                        onChange={e => setInput(e.target.value)} 
                        placeholder={`Enter text to ${tool.name.toLowerCase()}...`}
                        className="flex-1 w-full bg-gray-50 border border-gray-200 p-6 rounded-2xl outline-none resize-none focus:ring-2 focus:ring-blue-100 transition text-base leading-relaxed"
                     />
                </div>
                
                <div className="hidden md:flex items-center justify-center">
                    <div className="p-2 bg-gray-100 rounded-full text-gray-400">
                        <ArrowLeft size={20} className="rotate-180"/>
                    </div>
                </div>

                <div className="flex-1 bg-white border border-gray-200 rounded-2xl p-6 overflow-y-auto relative shadow-sm">
                    {loading ? (
                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/80 z-10">
                            <Loader2 className="animate-spin text-blue-600 mb-2" size={32}/>
                            <span className="text-xs font-bold text-blue-600 uppercase tracking-widest">Processing</span>
                        </div>
                    ) : output ? (
                        <div className="prose prose-sm max-w-none">
                            <MarkdownRenderer content={output}/>
                        </div>
                    ) : (
                        <div className="h-full flex flex-col items-center justify-center text-gray-300">
                            <Sparkles size={32} className="mb-3 opacity-30"/>
                            <p className="text-sm">Result will appear here</p>
                        </div>
                    )}
                    {output && !loading && (
                        <div className="absolute top-4 right-4 flex gap-2">
                            <button onClick={() => navigator.clipboard.writeText(output)} className="p-2 bg-white border border-gray-100 rounded-lg text-gray-500 hover:text-black shadow-sm"><Copy size={16}/></button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );

    // Main Layout Wrapper
    return (
        <div className="h-full flex flex-col bg-white font-sans text-gray-900">
            {/* Header */}
            <div className="h-16 px-6 border-b border-gray-100 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-4">
                    <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition"><ArrowLeft size={18}/></button>
                    <div>
                        <h1 className="font-bold text-lg leading-tight">{tool.name}</h1>
                        <p className="text-xs text-gray-400">{tool.description}</p>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    {tool.id === 'youtube' && <button onClick={() => setYoutubeModalOpen(true)} className="flex items-center gap-2 text-xs font-bold text-red-600 bg-red-50 px-3 py-1.5 rounded-full hover:bg-red-100 transition"><YoutubeIcon size={14}/> Select Video</button>}
                    {tool.id !== 'calculator' && tool.id !== 'youtube' && (
                        <button 
                            onClick={handleRun} 
                            disabled={loading || (!input && tool.id !== 'qr')} 
                            className="bg-black text-white px-6 py-2 rounded-full text-sm font-bold hover:opacity-80 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                        >
                            {loading ? <Loader2 className="animate-spin" size={14}/> : <Sparkles size={14}/>} Run
                        </button>
                    )}
                </div>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-hidden p-6 bg-[#f9f9f9]">
                <div className="h-full max-w-7xl mx-auto bg-white rounded-3xl border border-gray-100 shadow-sm p-6 overflow-hidden">
                    {tool.id === 'detector' && renderDetector()}
                    {tool.id === 'translator' && renderTranslator()}
                    {tool.id === 'qr' && renderQr()}
                    {tool.id === 'calculator' && renderCalculator()}
                    {['summarizer', 'humanizer', 'paraphraser', 'email', 'resume', 'grader'].includes(tool.id) && renderGenericEditor()}
                    {tool.id === 'youtube' && (
                         <div className="h-full flex flex-col md:flex-row gap-6">
                            <div className="w-full md:w-80 flex flex-col gap-4 border-r border-gray-100 pr-6">
                                <div className="aspect-video bg-black rounded-xl overflow-hidden relative group">
                                    {ytData.url ? (
                                        <div className="w-full h-full flex items-center justify-center bg-gray-900 text-white">
                                            <YoutubeIcon size={32}/>
                                            <span className="ml-2 font-bold">Video Selected</span>
                                        </div>
                                    ) : (
                                        <div className="w-full h-full flex items-center justify-center text-gray-500">
                                            <span className="text-xs">No video selected</span>
                                        </div>
                                    )}
                                </div>
                                <div>
                                    <label className="text-xs font-bold text-gray-500 uppercase">Analysis Focus</label>
                                    <select value={ytData.focus} onChange={e => setYtData({...ytData, focus: e.target.value})} className="w-full mt-2 p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm outline-none">
                                        <option>Summarize Video</option>
                                        <option>Key Takeaways</option>
                                        <option>Analyze Tone</option>
                                        <option>Fact Check</option>
                                    </select>
                                </div>
                                <button onClick={handleRun} disabled={!ytData.url || loading} className="w-full py-3 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition disabled:opacity-50">
                                    {loading ? 'Analyzing...' : 'Analyze Video'}
                                </button>
                            </div>
                            <div className="flex-1 bg-gray-50 rounded-2xl p-6 overflow-y-auto">
                                <MarkdownRenderer content={output || "*Analysis will appear here...*"}/>
                            </div>
                        </div>
                    )}
                    
                    {/* Fallback for unlisted tools */}
                    {!['detector', 'translator', 'qr', 'calculator', 'youtube', 'summarizer', 'humanizer', 'paraphraser', 'email', 'resume', 'grader'].includes(tool.id) && renderGenericEditor()}
                </div>
            </div>
            
            <YouTubeSearchModal isOpen={youtubeModalOpen} onClose={() => setYoutubeModalOpen(false)} onSelect={(v) => setYtData({ url: `https://youtube.com/watch?v=${v.id.videoId}`, creator: v.snippet.channelTitle, genre: 'General', focus: ytData.focus })} />
        </div>
    );
};

export default ToolPage;
