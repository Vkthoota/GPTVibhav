import React, { useState } from 'react';
import { Swords, ArrowLeft, ArrowRight, Cpu, Zap, Brain, Command } from 'lucide-react';
import { ModelType } from './types';
import { generateAIResponse } from './services/geminiService';
import MarkdownRenderer from './components/MarkdownRenderer';

const AIArena = ({ onBack, updateCredits }: { onBack: () => void, updateCredits: (c:number)=>boolean }) => {
    const [prompt, setPrompt] = useState("");
    const [loading, setLoading] = useState(false);
    const [stage, setStage] = useState<'input' | 'battling' | 'voting' | 'revealed'>('input');
    const [results, setResults] = useState<{a: string, b: string, modelA: string, modelB: string} | null>(null);
    const [selection, setSelection] = useState<'A' | 'B' | 'Tie' | null>(null);

    // Updated battle models to cutting-edge list
    const BATTLE_MODELS = [
        ModelType.GPT_5_2_PRO,
        ModelType.CLAUDE_4_6_OPUS,
        ModelType.GEMINI_3_PRO,
        ModelType.DEEPSEEK_V3,
        ModelType.GROK_4,
        ModelType.KIMI_K2_5_PRO,
        ModelType.GPT_4O,
        ModelType.CLAUDE_3_5_SONNET
    ];

    const startBattle = async () => {
        if(!prompt.trim()) return;
        if(!updateCredits(3)) return; 
        
        setLoading(true);
        setStage('battling');
        setSelection(null);

        let pool = [...BATTLE_MODELS];
        const m1Index = Math.floor(Math.random() * pool.length);
        const m1 = pool[m1Index];
        pool.splice(m1Index, 1);
        const m2 = pool[Math.floor(Math.random() * pool.length)];

        try {
            const [resA, resB] = await Promise.all([
                generateAIResponse({ modelName: m1, prompt, systemInstruction: "You are a helpful assistant participating in a model comparison battle. Answer the user prompt directly and concisely." }),
                generateAIResponse({ modelName: m2, prompt, systemInstruction: "You are a helpful assistant participating in a model comparison battle. Answer the user prompt directly and concisely." })
            ]);

            setResults({
                a: resA.text,
                b: resB.text,
                modelA: m1,
                modelB: m2
            });
            setStage('voting');
        } catch (e) {
            alert("Battle Error. Please try again.");
            setStage('input');
        } finally {
            setLoading(false);
        }
    };

    const handleVote = (vote: 'A' | 'B' | 'Tie') => {
        setSelection(vote);
        setStage('revealed');
    };

    const reset = () => {
        setPrompt("");
        setStage('input');
        setResults(null);
        setSelection(null);
    };

    return (
        <div className="h-full flex flex-col bg-[#f0f4f9] text-gray-900 overflow-hidden">
             <div className="p-4 border-b border-gray-200 bg-[#f0f4f9] flex items-center justify-center relative">
                <div className="flex items-center gap-3 absolute left-4">
                    <button onClick={onBack} className="p-2 hover:bg-gray-200 rounded-full text-gray-500"><ArrowLeft size={20}/></button>
                </div>
                <div className="font-bold text-lg flex items-center gap-2 text-indigo-600">
                    <Swords size={24} /> AI Arena <span className="text-xs bg-indigo-100 text-indigo-600 px-2 py-0.5 rounded-full border border-indigo-200">Beta</span>
                </div>
             </div>

             <div className="flex-1 overflow-y-auto p-4 md:p-8">
                <div className="max-w-6xl mx-auto h-full flex flex-col">
                    
                    {stage === 'input' && (
                        <div className="flex-1 flex flex-col items-center justify-center min-h-[50vh] animate-in fade-in zoom-in duration-500">
                            <div className="text-center mb-8 max-w-2xl">
                                <h1 className="text-4xl font-extrabold mb-4 text-gray-900">Battle of the <span className="text-indigo-600">Intelligences</span></h1>
                                <p className="text-gray-500 text-lg">Enter a prompt. Two anonymous models will generate responses. You decide who wins.</p>
                            </div>
                            
                            <div className="w-full max-w-2xl relative">
                                <textarea 
                                    value={prompt}
                                    onChange={e => setPrompt(e.target.value)}
                                    placeholder="Write a poem about rust, solve a coding problem, or ask a philosophical question..."
                                    className="w-full p-6 pb-16 rounded-2xl border border-gray-200 shadow-xl focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none text-lg resize-none min-h-[200px]"
                                />
                                <div className="absolute bottom-4 right-4 flex items-center gap-2">
                                     <span className="text-xs font-bold text-gray-400 uppercase mr-2">Cost: 3 Credits</span>
                                     <button 
                                        onClick={startBattle}
                                        disabled={!prompt.trim()}
                                        className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-xl font-bold flex items-center gap-2 transition disabled:opacity-50 disabled:cursor-not-allowed"
                                     >
                                        <Swords size={18}/> Start Battle
                                     </button>
                                </div>
                            </div>

                            <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 opacity-50 text-sm font-medium text-gray-400">
                                <div className="flex items-center gap-2"><Cpu size={16}/> Gemini 3 Pro</div>
                                <div className="flex items-center gap-2"><Zap size={16}/> GPT-5.2 Pro</div>
                                <div className="flex items-center gap-2"><Brain size={16}/> Claude 4.6</div>
                                <div className="flex items-center gap-2"><Command size={16}/> DeepSeek V3</div>
                            </div>
                        </div>
                    )}

                    {stage === 'battling' && (
                        <div className="flex-1 flex flex-col items-center justify-center">
                             <div className="flex gap-8 items-center mb-12">
                                 <div className="w-32 h-40 bg-white rounded-xl shadow-lg border-2 border-dashed border-gray-300 flex items-center justify-center animate-pulse">
                                     <div className="text-center">
                                         <div className="w-12 h-12 bg-gray-100 rounded-full mx-auto mb-2 flex items-center justify-center"><Cpu className="text-gray-400"/></div>
                                         <div className="text-xs font-bold text-gray-400">Model A</div>
                                         <div className="text-[10px] text-gray-400 mt-1">Generating...</div>
                                     </div>
                                 </div>
                                 <div className="text-2xl font-black text-gray-300">VS</div>
                                 <div className="w-32 h-40 bg-white rounded-xl shadow-lg border-2 border-dashed border-gray-300 flex items-center justify-center animate-pulse delay-100">
                                      <div className="text-center">
                                         <div className="w-12 h-12 bg-gray-100 rounded-full mx-auto mb-2 flex items-center justify-center"><Cpu className="text-gray-400"/></div>
                                         <div className="text-xs font-bold text-gray-400">Model B</div>
                                         <div className="text-[10px] text-gray-400 mt-1">Generating...</div>
                                     </div>
                                 </div>
                             </div>
                             <h3 className="text-xl font-bold text-gray-700 animate-pulse">The AI models are fighting...</h3>
                        </div>
                    )}

                    {(stage === 'voting' || stage === 'revealed') && results && (
                        <div className="flex flex-col h-full">
                            <div className="mb-6 text-center">
                                <h2 className="text-xl font-bold text-gray-800 line-clamp-1">"{prompt}"</h2>
                            </div>
                            
                            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6 overflow-hidden min-h-0">
                                <div className={`flex flex-col rounded-2xl border-2 transition-all overflow-hidden ${selection === 'A' ? 'border-emerald-500 bg-emerald-50/30 ring-4 ring-emerald-100' : 'border-gray-200 bg-white'}`}>
                                    <div className={`p-4 border-b flex items-center justify-between ${selection === 'A' ? 'bg-emerald-100 border-emerald-200' : 'bg-gray-50 border-gray-100'}`}>
                                        <div className="font-bold flex items-center gap-2">
                                            {stage === 'revealed' ? (
                                                <span className="text-indigo-600 flex items-center gap-2"><Cpu size={16}/> {results.modelA}</span>
                                            ) : "Model A"}
                                        </div>
                                        {stage === 'revealed' && selection === 'A' && <span className="bg-emerald-500 text-white text-xs px-2 py-1 rounded-full font-bold">WINNER</span>}
                                    </div>
                                    <div className="flex-1 overflow-y-auto p-4 prose prose-sm max-w-none">
                                        <MarkdownRenderer content={results.a} />
                                    </div>
                                    {stage === 'voting' && (
                                        <button onClick={() => handleVote('A')} className="p-4 bg-gray-50 hover:bg-emerald-50 border-t border-gray-100 text-gray-600 hover:text-emerald-600 font-bold transition flex items-center justify-center gap-2">
                                            <ArrowLeft size={16}/> Vote for Model A
                                        </button>
                                    )}
                                </div>

                                <div className={`flex flex-col rounded-2xl border-2 transition-all overflow-hidden ${selection === 'B' ? 'border-emerald-500 bg-emerald-50/30 ring-4 ring-emerald-100' : 'border-gray-200 bg-white'}`}>
                                    <div className={`p-4 border-b flex items-center justify-between ${selection === 'B' ? 'bg-emerald-100 border-emerald-200' : 'bg-gray-50 border-gray-100'}`}>
                                        <div className="font-bold flex items-center gap-2">
                                            {stage === 'revealed' ? (
                                                <span className="text-purple-600 flex items-center gap-2"><Zap size={16}/> {results.modelB}</span>
                                            ) : "Model B"}
                                        </div>
                                        {stage === 'revealed' && selection === 'B' && <span className="bg-emerald-500 text-white text-xs px-2 py-1 rounded-full font-bold">WINNER</span>}
                                    </div>
                                    <div className="flex-1 overflow-y-auto p-4 prose prose-sm max-w-none">
                                        <MarkdownRenderer content={results.b} />
                                    </div>
                                    {stage === 'voting' && (
                                        <button onClick={() => handleVote('B')} className="p-4 bg-gray-50 hover:bg-emerald-50 border-t border-gray-100 text-gray-600 hover:text-emerald-600 font-bold transition flex items-center justify-center gap-2">
                                            Vote for Model B <ArrowRight size={16}/>
                                        </button>
                                    )}
                                </div>
                            </div>

                            <div className="mt-6 flex justify-center gap-4">
                                {stage === 'voting' && (
                                    <button onClick={() => handleVote('Tie')} className="px-8 py-3 bg-gray-800 text-white rounded-xl font-bold hover:bg-gray-700 shadow-lg">
                                        It's a Tie
                                    </button>
                                )}
                                {stage === 'revealed' && (
                                    <button onClick={reset} className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 shadow-lg flex items-center gap-2 animate-in fade-in slide-in-from-bottom-4">
                                        <Swords size={18}/> New Battle
                                    </button>
                                )}
                            </div>
                        </div>
                    )}
                </div>
             </div>
        </div>
    );
};

export default AIArena;