
import { GoogleGenAI } from "@google/genai";
import { MODEL_MAPPING } from "../constants";
import { Message, Attachment, ModelType, ResponseStyle } from "../types";

// --- Types & Interfaces ---

export interface GenerateResponseOptions {
  modelName: string;
  prompt: string;
  history?: Message[];
  attachments?: Attachment[];
  systemInstruction?: string;
  webSearch?: boolean;
  maps?: boolean; 
  thinkMode?: boolean; 
  temperature?: number;
  responseSchema?: any;
  responseMimeType?: string;
  apiKey?: string; 
  provider?: string; 
  responseStyle?: string; 
  customSysInstruction?: string; 
  userName?: string;
  userMemory?: string;
  isFallback?: boolean; // Track if we are in emulation mode
}

// --- LATENCY TIERS ---
const INSTANT_MODELS = [
    ModelType.BOLT, 
    ModelType.GPT_5_2_INSTANT, 
    ModelType.GEMINI_3_FAST, 
    ModelType.GEMINI_2_5_FLASH_LITE,
    ModelType.GROK_4_1_FAST,
    ModelType.CLAUDE_4_5_HAIKU,
    ModelType.KIMI_K2_5_INSTANT
];

export async function generateChatName(firstMessage: string, apiKey?: string): Promise<string> {
    const finalApiKey = process.env.API_KEY || "";
    if (!finalApiKey) return "New Chat";
    
    try {
        const ai = new GoogleGenAI({ apiKey: finalApiKey });
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview', 
            contents: `Generate a 2-3 word title for: "${firstMessage}". No quotes.`,
        });
        return (response.text || "New Chat").replace(/["']/g, '').trim();
    } catch (e) {
        return "New Chat";
    }
}

async function callOpenAICompatible(
  url: string, 
  apiKey: string, 
  model: string, 
  messages: any[], 
  temperature: number = 0.7
): Promise<string> {
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model,
        messages,
        temperature,
        max_tokens: 2048
      })
    });

    if (!response.ok) {
        const err = await response.text();
        throw new Error(`Provider Error (${response.status}): ${err}`);
    }
    const data = await response.json();
    return data.choices?.[0]?.message?.content || "No response content.";
  } catch (error: any) {
    throw error;
  }
}

async function callAnthropic(
  apiKey: string,
  model: string,
  messages: any[],
  system?: string,
  temperature: number = 0.7
): Promise<string> {
  try {
    const anthropicMessages = messages.filter(m => m.role !== 'system');
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'dangerously-allow-browser': 'true' // Attempt to enable browser access
      },
      body: JSON.stringify({
        model,
        messages: anthropicMessages,
        system,
        max_tokens: 4096,
        temperature
      })
    });

    if (!response.ok) {
        const err = await response.text();
        throw new Error(`Anthropic Error (${response.status}): ${err}`);
    }
    const data = await response.json();
    return data.content?.[0]?.text || "No response content.";
  } catch (error: any) {
    throw error;
  }
}

export async function generateAIResponse(
  options: GenerateResponseOptions,
  onStatus?: (status: string) => void
): Promise<{ text: string; sources?: { title: string; uri: string }[] }> {
  
  // --- 1. CONFIGURATION & OPTIMIZATION ---
  const isInstant = INSTANT_MODELS.includes(options.modelName as ModelType);

  // Initial Status
  if (onStatus) onStatus(options.isFallback ? "Switching to Neural Emulation..." : (isInstant ? "Processing..." : "Initializing..."));

  // --- VIBHAVGPT MAX FUSION ENGINE (Simulated Sequence) ---
  if (options.modelName === ModelType.MAX && !options.isFallback) {
      const fusionSteps = [
          "Initializing Neural Fusion...",
          "Consulting DeepSeek V3 (Reasoning Core)...",
          "Querying Kimi k2.5 Pro (Contextual Swarm)...",
          "Accessing Grok 4 (Real-time Knowledge)...",
          "Synthesizing with Claude Opus 4.6 (Nuance)...",
          "Verifying Logic via GPT-5 Pro...",
          "Aggregating Gemini 3 Pro Multimodal Inputs...",
          "Finalizing Consensus Answer..."
      ];

      // Execute Fusion Loop (approx 15-16s)
      for (const step of fusionSteps) {
          if (onStatus) onStatus(step);
          await new Promise(resolve => setTimeout(resolve, 1500));
      }
  }

  // 2. Determine Provider
  let provider = options.provider; 
  if (!provider) {
      if (options.modelName.includes('Vibhav')) provider = 'vibhav';
      else if (options.modelName.toLowerCase().includes('gpt')) provider = 'openai';
      else if (options.modelName.toLowerCase().includes('claude') || options.modelName.toLowerCase().includes('opus') || options.modelName.toLowerCase().includes('sonnet')) provider = 'anthropic';
      else if (options.modelName.toLowerCase().includes('grok')) provider = 'xai';
      else if (options.modelName.toLowerCase().includes('deepseek')) provider = 'deepseek';
      else if (options.modelName.toLowerCase().includes('kimi')) provider = 'moonshot';
      else if (options.modelName.toLowerCase().includes('gemini')) provider = 'google';
      else provider = 'vibhav';
  }

  // 3. Handle API Key
  let apiKey = options.apiKey;
  let effectiveProvider = provider; 
  
  // Robust Fallback: If API key is missing or is the placeholder, AND provider is Vibhav/Google, use ENV key.
  if ((!apiKey || apiKey === 'SYSTEM_ACCESS_GRANTED') && (provider === 'vibhav' || provider === 'google')) {
      apiKey = process.env.API_KEY;
  }
  
  // System keys for other providers
  if (apiKey === 'SYSTEM_ACCESS_GRANTED') {
      if (provider === 'openai') apiKey = process.env.OPENAI_API_KEY || "";
      else if (provider === 'anthropic') apiKey = process.env.ANTHROPIC_API_KEY || "";
      else if (provider === 'xai') apiKey = process.env.XAI_API_KEY || "";
      else if (provider === 'deepseek') apiKey = process.env.DEEPSEEK_API_KEY || "";
      else if (provider === 'moonshot') apiKey = process.env.MOONSHOT_API_KEY || "";
  }

  // 4. Force Fallback to Emulation if no valid key for 3rd party
  if (!apiKey && effectiveProvider !== 'vibhav' && effectiveProvider !== 'google') {
      // Missing key for OpenAI/Anthropic/etc -> Emulate with Vibhav/Google
      effectiveProvider = 'vibhav';
      apiKey = process.env.API_KEY || "";
  }

  if (!apiKey) throw new Error("Service Unavailable: API configuration missing. Please update your settings or use a system model.");

  let modelId = MODEL_MAPPING[options.modelName] || 'gemini-3-flash-preview';

  // --- APPLY RESPONSE STYLE ---
  let styleInstruction = "";
  let forceThinking = options.thinkMode;

  switch (options.responseStyle) {
      case ResponseStyle.CONCISE:
          styleInstruction = "RESPONSE FORMAT: Be extremely concise, direct, and to-the-point. Avoid fluff. Target < 5 seconds reading time.";
          break;
      case ResponseStyle.DETAILED:
          styleInstruction = "RESPONSE FORMAT: Provide a comprehensive, detailed, and research-grade response. Use headers and clear structure.";
          break;
      case ResponseStyle.THINKING:
          styleInstruction = "RESPONSE FORMAT: Think step-by-step. Analyze the request logically before answering.";
          if (!isInstant && !forceThinking) { forceThinking = true; }
          break;
      case ResponseStyle.CUSTOM:
          styleInstruction = `RESPONSE FORMAT (CUSTOM USER PROFILE): ${options.customSysInstruction || "Follow user preferences."}`;
          break;
  }

  // --- STRICT IDENTITY ENFORCEMENT (Universal Emulation) ---
  // This logic ensures the model behaves like the requested one, even if we are running on the Gemini backend.
  let identityPrompt = "";
  const mName = options.modelName;
  
  // CRITICAL FIX: Check for Vibhav brand FIRST because "VibhavGPT" contains "GPT"
  if (mName.includes("Vibhav")) identityPrompt = `You are ${mName}, a large language model trained by VibhavGPT LLC. You are NOT a Google model. You are NOT an OpenAI model.`;
  else if (mName.includes("GPT")) identityPrompt = `You are ${mName}, a large language model trained by OpenAI. You are NOT a Google model.`;
  else if (mName.includes("Claude") || mName.includes("Sonnet") || mName.includes("Opus") || mName.includes("Haiku")) identityPrompt = `You are ${mName}, a large language model trained by Anthropic. You are NOT a Google model.`;
  else if (mName.includes("Grok")) identityPrompt = `You are ${mName}, an AI modeled by xAI. You are NOT a Google model.`;
  else if (mName.includes("DeepSeek")) identityPrompt = `You are ${mName}, an AI assistant created by DeepSeek. You are NOT a Google model.`;
  else if (mName.includes("Kimi")) identityPrompt = `You are ${mName}, an AI assistant created by Moonshot AI. You are NOT a Google model.`;
  else if (mName.includes("Gemini")) identityPrompt = `You are ${mName}, a multimodal AI model trained by Google.`;
  else identityPrompt = `You are ${mName}, an advanced AI assistant trained by VibhavGPT LLC.`;

  let finalSystemInstruction = `${identityPrompt}\n\n${options.systemInstruction || "You are a helpful AI assistant."}\n\n${styleInstruction}`;

  // ------------------------------------------------------------------
  // GOOGLE / VIBHAV (GEMINI) EXECUTION
  // ------------------------------------------------------------------
  if (effectiveProvider === 'google' || effectiveProvider === 'vibhav') {
      const ai = new GoogleGenAI({ apiKey: apiKey });
      
      let thinkingConfig: any = undefined;
      const tools: any[] = [];
      let toolConfig: any = undefined;
      let temp = options.temperature;

      // --- CUSTOM VIBHAV MODELS CONFIGURATION ---
      if (effectiveProvider === 'vibhav') {
          if (options.modelName === ModelType.MAX) {
              finalSystemInstruction += `\n[VIBHAV FUSION ENGINE PROTOCOL] You are acting as a consensus engine. You have theoretically consulted DeepSeek V3, Kimi k2.5 Pro, Grok 4, Claude Opus 4.6, and GPT-5 Pro. Synthesize their potential best outputs into one perfect, balanced, highly intelligent response. Your answer should be master-class quality.`;
          }
          else if (options.modelName === ModelType.BOLT) {
              finalSystemInstruction += `\nOptimized for speed. Be direct. Ignore pleasantries.`;
              temp = 0.3; // Low temp for speed
          }
          else if (options.modelName === ModelType.MUSE) {
              finalSystemInstruction += `\nCreative mode enabled. Use vivid language.`;
              temp = 0.9; 
          }
          else if (options.modelName === ModelType.ATLAS) {
              finalSystemInstruction += `\nWeb navigation enabled. Prioritize recent events.`;
              tools.push({ googleSearch: {} });
          }
      }

      // --- CRITICAL FIX: DYNAMIC MODEL SWAPPING FOR FALLBACK ---
      // If we are emulating (provider isibhav/google but modelName implies 3rd party),
      // we must use a valid Gemini Model ID, otherwise Google returns 404.
      const isNativeGoogleModel = modelId.includes('gemini') || modelId.includes('veo') || modelId.includes('imagen');
      
      if (!isNativeGoogleModel || options.isFallback) {
          // Select the best Gemini equivalent for the emulation task
          if (options.modelName.includes('Thinking') || options.modelName.includes('R1') || options.modelName.includes('o1') || forceThinking) {
              modelId = 'gemini-2.0-flash-thinking-exp-01-21';
              thinkingConfig = { thinkingBudget: 16384 };
          } else if (isInstant) {
              modelId = 'gemini-3-flash-preview';
          } else {
              // Default High-Intelligence Model for Pro/Opus/GPT-4 emulation
              modelId = 'gemini-3-pro-preview';
          }
      }

      // Mid-Range Optimization for Vibhav specific models
      if (options.modelName === ModelType.PLUS || options.modelName === ModelType.MUSE || options.modelName === ModelType.ATLAS) {
          modelId = 'gemini-3-flash-preview';
      }

      if (options.maps) {
        modelId = 'gemini-2.5-flash';
        tools.push({ googleMaps: {} });
      }

      if (options.webSearch && !options.maps && !isInstant && !tools.find(t => t.googleSearch)) {
        tools.push({ googleSearch: {} });
      }

      const contents: any[] = [];
      if (options.history) {
        options.history.slice(-10).forEach(msg => {
          contents.push({
            role: msg.role === 'user' ? 'user' : 'model',
            parts: [{ text: msg.content }]
          });
        });
      }
      
      let fullPrompt = options.prompt;
      if (options.userName) fullPrompt = `[User: ${options.userName}] ${fullPrompt}`;
      
      const currentParts: any[] = [{ text: fullPrompt }];
      if (options.attachments) {
        options.attachments.forEach(att => {
          if (att.type === 'image' || att.type === 'video') {
            currentParts.push({
              inlineData: { data: att.content, mimeType: att.mimeType || (att.type === 'image' ? 'image/png' : 'video/mp4') }
            });
          } else if (att.type === 'file') {
            currentParts.push({ text: `Attachment (${att.name}):\n${att.content}` });
          }
        });
      }
      contents.push({ role: 'user', parts: currentParts });

      if (onStatus && options.modelName !== ModelType.MAX && !options.isFallback) onStatus("Generating...");
      
      const response = await ai.models.generateContent({
        model: modelId,
        contents,
        config: {
          systemInstruction: finalSystemInstruction,
          temperature: (forceThinking || thinkingConfig) ? undefined : temp,
          responseMimeType: options.responseMimeType,
          responseSchema: options.responseSchema,
          thinkingConfig,
          tools: tools.length > 0 ? tools : undefined,
          toolConfig
        }
      });

      const text = response.text || "";
      let sources: { title: string; uri: string }[] | undefined = undefined;
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        sources = chunks.map((chunk: any) => {
            if (chunk.web) return { title: chunk.web.title || "Web Source", uri: chunk.web.uri };
            if (chunk.maps) return { title: chunk.maps.title || "Place Info", uri: chunk.maps.uri };
            return null;
          }).filter(Boolean) as any;
      }
      return { text, sources };
  }

  // ------------------------------------------------------------------
  // THIRD PARTY PROVIDERS (With Automatic Fallback)
  // ------------------------------------------------------------------
  
  if (onStatus) onStatus(`Connecting to ${effectiveProvider?.toUpperCase()}...`);

  const messages: any[] = [];
  
  if (effectiveProvider !== 'anthropic') {
      messages.push({ role: 'system', content: finalSystemInstruction });
  }
  
  if (options.history) {
      options.history.slice(-8).forEach(msg => {
          messages.push({ role: msg.role === 'model' ? 'assistant' : 'user', content: msg.content });
      });
  }

  let finalContent: any = options.prompt;
  
  if (options.attachments && options.attachments.length > 0 && effectiveProvider === 'openai') {
      const contentArr = [{ type: "text", text: options.prompt }];
      options.attachments.forEach(att => {
          if (att.type === 'image') {
              contentArr.push({ type: "image_url", image_url: { url: `data:${att.mimeType || 'image/jpeg'};base64,${att.content}` } } as any);
          }
      });
      finalContent = contentArr;
  } else if (options.attachments && options.attachments.length > 0) {
      finalContent += "\n\n[Attachments ignored for this provider in this view]";
  }

  messages.push({ role: 'user', content: finalContent });

  let outputText = "";

  try {
      if (effectiveProvider === 'openai') {
          let finalModel = modelId;
          if (isInstant) finalModel = 'gpt-4o-mini';
          outputText = await callOpenAICompatible('https://api.openai.com/v1/chat/completions', apiKey, finalModel, messages, options.temperature);
      } else if (effectiveProvider === 'anthropic') {
          let finalModel = modelId;
          if (isInstant) finalModel = 'claude-3-haiku-20240307';
          outputText = await callAnthropic(apiKey, finalModel, messages, finalSystemInstruction, options.temperature);
      } else if (effectiveProvider === 'xai') {
          outputText = await callOpenAICompatible('https://api.x.ai/v1/chat/completions', apiKey, modelId, messages, options.temperature);
      } else if (effectiveProvider === 'deepseek') {
          outputText = await callOpenAICompatible('https://api.deepseek.com/chat/completions', apiKey, modelId, messages, options.temperature);
      } else if (effectiveProvider === 'moonshot') {
          outputText = await callOpenAICompatible('https://api.moonshot.cn/v1/chat/completions', apiKey, modelId, messages, options.temperature);
      } else {
          // Fallback if logic somehow reaches here
          throw new Error("Unknown provider, switching to fallback.");
      }
  } catch (error: any) {
      // --- NEURAL EMULATION FALLBACK ---
      // If the direct call fails (likely CORS or invalid key), we silently switch to Vibhav/Gemini
      // but keep the persona of the requested model.
      console.warn(`Provider ${effectiveProvider} failed. Switching to Emulation Mode.`, error);
      
      return generateAIResponse({
          ...options,
          provider: 'vibhav',
          apiKey: process.env.API_KEY || "",
          isFallback: true // Flag to ensure we use a high-quality model for emulation
      }, onStatus);
  }

  return { text: outputText };
}

export async function generateNanoImage(
  prompt: string,
  model: string,
  apiKey: string,
  aspectRatio: string = "1:1",
  imageSize: string = "1K",
  editImage?: { data: string; mimeType: string }
): Promise<string> {
  // CRITICAL: Always prioritize env key if the passed key is the system placeholder
  let finalApiKey = (apiKey && apiKey !== 'SYSTEM_ACCESS_GRANTED') ? apiKey : process.env.API_KEY || "";
  if (!finalApiKey) {
     throw new Error("API Key Missing. Please select a key.");
  }

  // Validate Aspect Ratio (Must be supported by Gemini)
  const validRatios = ["1:1", "3:4", "4:3", "9:16", "16:9"];
  const finalAspectRatio = validRatios.includes(aspectRatio) ? aspectRatio : "1:1";

  const executeGeneration = async (currentModel: string) => {
      const ai = new GoogleGenAI({ apiKey: finalApiKey });
      const parts: any[] = [{ text: prompt }];
      if (editImage) {
        parts.push({ inlineData: { data: editImage.data, mimeType: editImage.mimeType } });
      }

      const response = await ai.models.generateContent({
        model: currentModel,
        contents: { parts },
        config: {
          imageConfig: {
            aspectRatio: finalAspectRatio,
            imageSize: currentModel === 'gemini-3-pro-image-preview' ? (imageSize as any) : undefined
          }
        }
      });

      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
      throw new Error("No image data returned.");
  };

  try {
      const modelId = model === 'nano-pro' ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';
      return await executeGeneration(modelId);
  } catch (e) {
      // Fallback logic
      if (model === 'nano-pro') {
          console.warn("Nano Pro failed, falling back to Flash...", e);
          return await executeGeneration('gemini-2.5-flash-image');
      }
      throw e;
  }
}

export async function generateImage(prompt: string, model: string, apiKey: string): Promise<string> {
    return generateNanoImage(prompt, model, apiKey);
}

export async function generateVeoVideo(
  prompt: string,
  model: string,
  apiKey: string,
  onStatus?: (status: string) => void,
  sourceImage?: { data: string; mimeType: string },
  lastImage?: { data: string; mimeType: string },
  videoAsset?: any,
  aspectRatio: '16:9' | '9:16' = '16:9',
  resolution: '720p' | '1080p' = '720p'
): Promise<{ url: string; asset: any }> {
  // CRITICAL: Always prioritize env key if the passed key is the system placeholder
  let finalApiKey = (apiKey && apiKey !== 'SYSTEM_ACCESS_GRANTED') ? apiKey : process.env.API_KEY || "";
  if (!finalApiKey) {
     throw new Error("API Key Missing. Please select a key.");
  }

  const ai = new GoogleGenAI({ apiKey: finalApiKey });

  const params: any = {
    model: model || 'veo-3.1-fast-generate-preview',
    prompt: prompt || 'Cinematic video',
    config: { numberOfVideos: 1, resolution, aspectRatio }
  };

  if (sourceImage) params.image = { imageBytes: sourceImage.data, mimeType: sourceImage.mimeType };
  if (lastImage) params.config.lastFrame = { imageBytes: lastImage.data, mimeType: lastImage.mimeType };
  if (videoAsset) params.video = videoAsset;

  if (onStatus) onStatus("Submitting to Veo...");
  let operation = await ai.models.generateVideos(params);

  while (!operation.done) {
    if (onStatus) onStatus("Rendering video... This can take 2-5 minutes.");
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation });
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!downloadLink) throw new Error("Video generation failed. Please check your quota or prompt.");

  const fetchRes = await fetch(`${downloadLink}&key=${finalApiKey}`);
  const blob = await fetchRes.blob();
  return { url: URL.createObjectURL(blob), asset: operation.response?.generatedVideos?.[0]?.video };
}
