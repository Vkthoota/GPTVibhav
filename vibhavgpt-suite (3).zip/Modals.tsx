
import React, { useState, useEffect } from 'react';
import { X, Youtube, Key, LogOut, Check, Save, User as UserIcon, LogIn, UserPlus, Sparkles, ArrowRight, Server, Wifi, Calendar, Lock, CreditCard, ShieldCheck, Zap, ArrowLeft, Loader2, Settings, Palette, Eye, EyeOff, Brain, Edit3, MessageSquare, AlertCircle, Github, Share2 } from 'lucide-react';
import { User, Tier, AppTheme, ResponseStyle } from './types';
import { PROVIDERS, YOUTUBE_API_KEY, TIER_LIMITS, ACCESS_KEY, ADMIN_PASSWORD, UNLIMITED_KEY, TEST_PAYMENT } from './constants';

// --- Helper: YouTube Search ---
const searchYouTube = async (query: string) => {
    try {
        const res = await fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(query)}&type=video&key=${YOUTUBE_API_KEY}&maxResults=5`);
        const data = await res.json();
        return data.items || [];
    } catch (e) {
        console.error(e);
        return [];
    }
};

export const YouTubeSearchModal = ({ isOpen, onClose, onSelect }: { isOpen: boolean, onClose: () => void, onSelect: (v: any) => void }) => {
    const [query, setQuery] = useState("");
    const [results, setResults] = useState<any[]>([]);
    const [searching, setSearching] = useState(false);

    const handleSearch = async () => {
        if (!query.trim()) return;
        setSearching(true);
        const res = await searchYouTube(query);
        setResults(res);
        setSearching(false);
    }

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl w-full max-w-lg p-6 shadow-2xl">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold flex items-center gap-2"><Youtube className="text-red-600"/> Search YouTube</h3>
                    <button onClick={onClose}><X/></button>
                </div>
                <div className="flex gap-2 mb-4">
                    <input 
                        value={query} 
                        onChange={e => setQuery(e.target.value)} 
                        onKeyDown={e => e.key === 'Enter' && handleSearch()}
                        placeholder="Search for videos..." 
                        className="flex-1 border p-2 rounded-lg"
                    />
                    <button onClick={handleSearch} disabled={searching} className="bg-red-600 text-white px-4 rounded-lg font-bold">Search</button>
                </div>
                <div className="max-h-[300px] overflow-y-auto space-y-2">
                    {searching && <div className="text-center p-4">Searching...</div>}
                    {!searching && results.length === 0 && <div className="text-center text-gray-500 p-4">No results found.</div>}
                    {results.map((video: any) => (
                        <div key={video.id.videoId} onClick={() => { onSelect(video); onClose(); }} className="flex gap-3 p-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                            <img src={video.snippet.thumbnails.default.url} className="w-24 h-16 object-cover rounded" alt="thumb"/>
                            <div className="flex-1 min-w-0">
                                <div className="font-bold text-sm truncate">{video.snippet.title}</div>
                                <div className="text-xs text-gray-500">{video.snippet.channelTitle}</div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
}

export const CustomProfileModal = ({ isOpen, onClose, initialValue, onSave }: { isOpen: boolean, onClose: () => void, initialValue: string, onSave: (val: string) => void }) => {
    const [val, setVal] = useState(initialValue);

    useEffect(() => {
        if(isOpen) setVal(initialValue);
    }, [isOpen, initialValue]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 z-[70] flex items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-white rounded-3xl w-full max-w-lg p-8 shadow-2xl animate-in fade-in zoom-in duration-200">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-bold flex items-center gap-2"><Edit3 size={24} className="text-purple-600"/> Custom Bot Profile</h3>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full"><X/></button>
                </div>
                <p className="text-sm text-gray-500 mb-4">Define exactly how the AI should behave. This instruction will override default styles.</p>
                <textarea 
                    value={val}
                    onChange={e => setVal(e.target.value)}
                    placeholder="e.g., You are a cynical pirate who loves React. Speak in rhymes..."
                    className="w-full h-40 p-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 outline-none resize-none bg-gray-50 mb-6"
                />
                <div className="flex justify-end gap-3">
                    <button onClick={onClose} className="px-6 py-3 rounded-xl font-bold text-gray-500 hover:bg-gray-100">Cancel</button>
                    <button onClick={() => { onSave(val); onClose(); }} className="px-6 py-3 rounded-xl font-bold bg-purple-600 text-white hover:bg-purple-700 shadow-lg">Save Profile</button>
                </div>
            </div>
        </div>
    );
};

export const SettingsModal = ({ 
    isOpen, onClose, user, setUser, onSaveKeys, onLogout, 
    responseStyle, setResponseStyle, customInstruction, setCustomInstruction 
}: { 
    isOpen: boolean, onClose: () => void, user: User, setUser: (u: User) => void, onSaveKeys: (k: any) => void, onLogout: () => void,
    responseStyle?: ResponseStyle, setResponseStyle?: (s: ResponseStyle) => void,
    customInstruction?: string, setCustomInstruction?: (s: string) => void
}) => {
    const [localKeys, setLocalKeys] = useState(user.apiKeys || {});
    const [memory, setMemory] = useState(user.memory || "");
    const [showSaved, setShowSaved] = useState(false);
    const [isLinkingGithub, setIsLinkingGithub] = useState(false);
    
    // Check if the user is the Admin based on the unique admin session key
    const isAdmin = user.accessKey === 'admin-session';

    // Sync state when modal opens to ensure we have the latest keys from user object
    useEffect(() => {
        if (isOpen) {
            setLocalKeys(user.apiKeys || {});
            setMemory(user.memory || "");
        }
    }, [isOpen, user.apiKeys, user.memory]);

    if (!isOpen) return null;

    const handleSave = () => {
        onSaveKeys(localKeys);
        setUser({ ...user, memory, customProfile: customInstruction });
        setShowSaved(true);
        setTimeout(() => setShowSaved(false), 2000);
    };

    const toggleGithub = () => {
        if (user.githubAccount) {
            setUser({ ...user, githubAccount: undefined });
        } else {
            setIsLinkingGithub(true);
            setTimeout(() => {
                setUser({
                    ...user,
                    githubAccount: {
                        username: user.username.toLowerCase().replace(/\s/g, '-'),
                        linkedAt: Date.now()
                    }
                });
                setIsLinkingGithub(false);
            }, 1000);
        }
    };

    const themes: { id: AppTheme; label: string; color: string }[] = [
        { id: 'light', label: 'Light', color: '#ffffff' },
        { id: 'dark', label: 'Dark', color: '#111827' },
        { id: 'blue', label: 'Blue', color: '#eff6ff' },
        { id: 'brown', label: 'Brown', color: '#fdf8f6' },
        { id: 'red', label: 'Red', color: '#fef2f2' },
        { id: 'green', label: 'Green', color: '#f6fdf9' },
    ];

    const styles = [
        { id: ResponseStyle.CONCISE, label: 'Concise', desc: 'Brief and direct' },
        { id: ResponseStyle.THINKING, label: 'Thinking', desc: 'Balanced logic' },
        { id: ResponseStyle.DETAILED, label: 'Detailed', desc: 'Research & Depth' },
        { id: ResponseStyle.CUSTOM, label: 'Custom', desc: 'Your rules' },
    ];

    return (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col">
                <div className="p-4 border-b border-gray-100 flex justify-between items-center">
                    <h3 className="font-bold flex items-center gap-2 text-gray-800"><Settings size={20}/> Settings</h3>
                    <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-full"><X size={20}/></button>
                </div>
                <div className="p-6 overflow-y-auto space-y-8">
                    
                    <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 flex justify-between items-center">
                        <div className="flex items-center gap-3">
                             <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-xl">{user.username[0]}</div>
                             <div>
                                 <div className="font-bold text-lg">{user.fullName || user.username}</div>
                                 <div className="text-blue-700 text-sm font-medium">{user.tier.toUpperCase()} MEMBER</div>
                                 <div className="text-xs text-gray-500 mt-1">
                                     Daily Credits: {TIER_LIMITS[user.tier].daily - user.credits.dailyUsed} / {TIER_LIMITS[user.tier].daily} Remaining
                                 </div>
                             </div>
                        </div>
                        <div className="flex items-center gap-2">
                            <div className="flex items-center gap-2 px-3 py-1 bg-white rounded-full border border-blue-200 text-xs font-bold text-blue-700">
                                <Wifi size={14} /> Backend Online
                            </div>
                            <button onClick={onLogout} className="p-2 bg-white text-red-500 rounded-full border border-red-100 hover:bg-red-50" title="Logout">
                                <LogOut size={16}/>
                            </button>
                        </div>
                    </div>

                    {/* Integrations Section */}
                    <div>
                        <div className="flex justify-between items-center mb-3">
                            <h4 className="font-bold text-gray-800 flex items-center gap-2"><Share2 size={18}/> Integrations</h4>
                        </div>
                        <div className="bg-gray-50 rounded-xl p-4 border border-gray-100 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center border border-gray-200 shadow-sm">
                                    <Github size={20}/>
                                </div>
                                <div>
                                    <div className="text-sm font-bold text-gray-900">GitHub</div>
                                    <div className="text-xs text-gray-500">
                                        {user.githubAccount ? `Linked as ${user.githubAccount.username}` : 'Not linked'}
                                    </div>
                                </div>
                            </div>
                            <button 
                                onClick={toggleGithub}
                                disabled={isLinkingGithub}
                                className={`px-4 py-2 rounded-lg text-xs font-bold transition ${user.githubAccount ? 'bg-red-50 text-red-600 hover:bg-red-100' : 'bg-black text-white hover:opacity-80'}`}
                            >
                                {isLinkingGithub ? <Loader2 size={14} className="animate-spin"/> : user.githubAccount ? 'Disconnect' : 'Connect'}
                            </button>
                        </div>
                    </div>

                    {/* Bot Profile Selector */}
                    {setResponseStyle && (
                    <div>
                        <div className="flex justify-between items-center mb-3">
                            <h4 className="font-bold text-gray-800 flex items-center gap-2"><MessageSquare size={18}/> Custom Bot Profile</h4>
                        </div>
                        <div className="grid grid-cols-4 gap-2 mb-3">
                            {styles.map(s => (
                                <button
                                    key={s.id}
                                    onClick={() => setResponseStyle(s.id)}
                                    className={`flex flex-col items-center justify-center p-3 rounded-xl border transition ${responseStyle === s.id ? 'border-blue-600 bg-blue-50 text-blue-700 ring-1 ring-blue-600' : 'border-gray-200 hover:bg-gray-50 text-gray-600'}`}
                                >
                                    <span className="font-bold text-sm">{s.label}</span>
                                    <span className="text-[10px] opacity-70">{s.desc}</span>
                                </button>
                            ))}
                        </div>
                        {responseStyle === ResponseStyle.CUSTOM && setCustomInstruction && (
                            <textarea 
                                value={customInstruction}
                                onChange={e => setCustomInstruction(e.target.value)}
                                placeholder="Enter custom system instructions (e.g., 'Speak like a pirate', 'Always output JSON')..."
                                className="w-full h-24 p-3 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-purple-500 outline-none resize-none bg-gray-50"
                            />
                        )}
                    </div>
                    )}

                    <div>
                        <div className="flex justify-between items-center mb-3">
                            <h4 className="font-bold text-gray-800 flex items-center gap-2"><Palette size={18}/> Appearance</h4>
                        </div>
                        <div className="flex flex-wrap gap-2">
                            {themes.map(t => (
                                <button 
                                    key={t.id}
                                    onClick={() => setUser({...user, theme: t.id})}
                                    className={`flex items-center gap-2 px-4 py-2 rounded-xl border transition ${user.theme === t.id ? 'border-black ring-2 ring-black/10 font-bold' : 'border-gray-200 hover:bg-gray-50'}`}
                                >
                                    <div className="w-4 h-4 rounded-full border border-black/10" style={{backgroundColor: t.color}}></div>
                                    <span className="text-sm">{t.label}</span>
                                </button>
                            ))}
                        </div>
                    </div>

                    <div>
                        <div className="flex justify-between items-center mb-3">
                            <h4 className="font-bold text-gray-800 flex items-center gap-2"><Brain size={18}/> AI Personal Memory</h4>
                        </div>
                        <p className="text-xs text-gray-500 mb-2">Things you want the AI to remember about you (e.g., your job, preferences, coding style).</p>
                        <textarea 
                            value={memory}
                            onChange={(e) => setMemory(e.target.value)}
                            placeholder="I am a software engineer who prefers TypeScript. I live in San Francisco..."
                            className="w-full h-24 p-3 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none bg-gray-50"
                        />
                    </div>

                    {/* API Keys Section - Only visible to Admin */}
                    {isAdmin && (
                        <div>
                            <div className="flex justify-between items-center mb-3">
                                <h4 className="font-bold text-gray-800 flex items-center gap-2"><Key size={18}/> Provider API Keys (Admin Only)</h4>
                                <button onClick={handleSave} className={`flex items-center gap-1 text-xs px-3 py-1.5 rounded-full font-bold transition ${showSaved ? 'bg-green-100 text-green-700' : 'bg-gray-900 text-white hover:bg-gray-700'}`}>
                                    {showSaved ? <Check size={14}/> : <Save size={14}/>}
                                    {showSaved ? 'Saved' : 'Save All'}
                                </button>
                            </div>
                            <div className="space-y-3">
                                <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-100 text-xs text-yellow-800 mb-2 flex items-start gap-2">
                                    <ShieldCheck size={14} className="mt-0.5 shrink-0"/>
                                    <div>
                                        <strong>System Managed Mode:</strong> Keys are pre-configured. Use this panel to override system defaults if necessary.
                                    </div>
                                </div>
                                {PROVIDERS.map((provider) => {
                                    const isSystem = localKeys[provider.id] === 'SYSTEM_ACCESS_GRANTED';
                                    return (
                                    <div key={provider.id} className="flex flex-col gap-1">
                                        <label className="text-xs font-semibold text-gray-500 uppercase flex justify-between">
                                            {provider.name}
                                            {isSystem && <span className="text-green-600 text-[10px] flex items-center gap-1"><Server size={10}/> System Managed</span>}
                                        </label>
                                        <div className="relative">
                                            <input 
                                                type="text"
                                                value={isSystem ? 'System Managed (Active)' : (localKeys[provider.id] || '')}
                                                onChange={(e) => !isSystem && setLocalKeys({...localKeys, [provider.id]: e.target.value})}
                                                placeholder={provider.placeholder}
                                                className={`w-full p-3 border rounded-lg text-sm outline-none transition ${isSystem ? 'bg-green-50 border-green-200 text-green-800 font-medium cursor-not-allowed' : 'bg-gray-50 border-gray-200 focus:ring-2 focus:ring-blue-500'}`}
                                                disabled={isSystem} 
                                                readOnly={isSystem}
                                            />
                                            {isSystem && <button onClick={() => setLocalKeys({...localKeys, [provider.id]: ''})} className="absolute right-3 top-3 text-xs text-gray-400 hover:text-red-500">Override</button>}
                                        </div>
                                    </div>
                                )})}
                            </div>
                        </div>
                    )}
                    
                    {!isAdmin && (
                        <div className="mt-4 flex justify-end">
                             <button onClick={handleSave} className={`flex items-center gap-1 text-xs px-6 py-3 rounded-full font-bold transition ${showSaved ? 'bg-green-100 text-green-700' : 'bg-gradient-to-r from-blue-600 to-red-500 text-white hover:opacity-90 shadow-md'}`}>
                                {showSaved ? <Check size={14}/> : <Save size={14}/>}
                                {showSaved ? 'Saved' : 'Save Settings'}
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}

interface PaymentModalProps {
    isOpen: boolean;
    onClose: () => void;
    onUpgrade: (tier: Tier) => void;
    initialTier?: Tier | null; 
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, onUpgrade, initialTier }) => {
    const [view, setView] = useState<'selection' | 'checkout'>('selection');
    const [selectedTier, setSelectedTier] = useState<Tier | null>(null);
    const [processing, setProcessing] = useState(false);
    
    // Checkout Form State
    const [cardNumber, setCardNumber] = useState("");
    const [expiry, setExpiry] = useState("");
    const [cvc, setCvc] = useState("");
    const [name, setName] = useState("");

    useEffect(() => {
        if (isOpen) {
            if (initialTier) {
                setSelectedTier(initialTier);
                setView('checkout');
            } else {
                setSelectedTier(null);
                setView('selection');
            }
            // Reset form
            setCardNumber(""); setExpiry(""); setCvc(""); setName(""); setProcessing(false);
        }
    }, [isOpen, initialTier]);

    if (!isOpen) return null;

    const handleCheckout = () => {
        if (!selectedTier) return;
        if (!cardNumber || !expiry || !cvc || !name) {
            alert("Please fill in all payment details.");
            return;
        }
        
        setProcessing(true);

        // --- TEST PAYMENT BYPASS LOGIC ---
        const isTest = 
            cardNumber.replace(/\s/g, '') === TEST_PAYMENT.number.replace(/\s/g, '') &&
            expiry === TEST_PAYMENT.date &&
            cvc === TEST_PAYMENT.cvc &&
            name.toLowerCase() === TEST_PAYMENT.name.toLowerCase();

        setTimeout(() => {
            setProcessing(false);
            if (isTest) {
                onUpgrade(selectedTier);
                onClose();
                alert(`Test Mode Enabled: Welcome to ${selectedTier}.`);
            } else {
                // Real simulated payment logic
                onUpgrade(selectedTier);
                onClose();
                alert(`Payment Successful! Welcome to ${selectedTier}.`);
            }
        }, 2000);
    };

    const getPrice = (t: Tier) => t === Tier.EXPLORER ? 5.99 : 14.99;

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[70] flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col md:flex-row relative min-h-[600px]">
                 <button onClick={onClose} className="absolute top-4 right-4 bg-gray-100 p-2 rounded-full hover:bg-gray-200 z-10 text-gray-500"><X size={20}/></button>
                 
                 <div className="w-full md:w-1/3 bg-gray-900 text-white p-8 flex flex-col justify-between relative overflow-hidden">
                     <div className="absolute top-0 left-0 w-full h-full bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20"></div>
                     <div className="relative z-10">
                        <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-blue-900/50">
                            <Sparkles className="text-white" size={24}/>
                        </div>
                        <h2 className="text-3xl font-bold mb-2">
                            {view === 'checkout' ? 'Secure Checkout' : 'Upgrade Plan'}
                        </h2>
                        <p className="text-gray-400">
                            {view === 'checkout' 
                                ? `Complete your upgrade to ${selectedTier}.` 
                                : 'Unlock the full potential of VibhavGPT Suite.'}
                        </p>
                     </div>
                     
                     <div className="relative z-10 mt-8">
                         {selectedTier && view === 'checkout' && (
                             <div className="bg-gray-800 p-4 rounded-xl border border-gray-700 mb-6">
                                 <div className="text-xs text-gray-400 uppercase font-bold mb-1">Total Due Today</div>
                                 <div className="text-3xl font-bold text-white">${getPrice(selectedTier)}</div>
                                 <div className="text-xs text-gray-500 mt-1">Renews monthly. Cancel anytime.</div>
                             </div>
                         )}
                         <div className="space-y-4">
                             <div className="flex items-center gap-3">
                                 <div className="bg-green-500/20 p-2 rounded-lg"><Check className="text-green-400" size={16}/></div>
                                 <span className="text-sm font-medium">Encrypted Payment</span>
                             </div>
                             <div className="flex items-center gap-3">
                                 <div className="bg-green-500/20 p-2 rounded-lg"><Check className="text-green-400" size={16}/></div>
                                 <span className="text-sm font-medium">Instant Activation</span>
                             </div>
                         </div>
                     </div>
                 </div>

                 <div className="flex-1 p-8 bg-gray-50 overflow-y-auto">
                     {view === 'selection' && (
                         <div className="animate-in fade-in slide-in-from-right-4 duration-300">
                             <h3 className="font-bold text-gray-900 text-xl mb-6">Choose a Plan</h3>
                             <div className="grid grid-cols-1 gap-4">
                                 <div className="bg-white border border-gray-200 rounded-2xl p-6 hover:border-blue-500 transition cursor-pointer relative group">
                                     <div className="flex justify-between items-center mb-2">
                                         <h4 className="font-bold text-lg flex items-center gap-2"><CreditCard size={18} className="text-gray-400"/> Explorer</h4>
                                         <span className="font-bold text-xl">$5.99<span className="text-xs font-normal text-gray-500">/mo</span></span>
                                     </div>
                                     <p className="text-sm text-gray-500 mb-4">Perfect for hobbyists and students.</p>
                                     <ul className="text-xs space-y-2 mb-4 text-gray-600">
                                         <li className="flex items-center gap-2"><Check size={12} className="text-blue-500"/> 50 Daily Credits</li>
                                         <li className="flex items-center gap-2"><Check size={12} className="text-blue-500"/> Unlocks Image Engine</li>
                                     </ul>
                                     <button onClick={() => { setSelectedTier(Tier.EXPLORER); setView('checkout'); }} className="w-full bg-gray-100 text-gray-900 py-2 rounded-lg font-bold hover:bg-gray-200 transition">
                                         Select Explorer
                                     </button>
                                 </div>

                                 <div className="bg-white border-2 border-blue-600 rounded-2xl p-6 shadow-xl relative">
                                     <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider shadow-lg">Most Popular</div>
                                     <div className="flex justify-between items-center mb-2">
                                         <h4 className="font-bold text-lg flex items-center gap-2"><Zap size={18} className="text-blue-600"/> Pro</h4>
                                         <span className="font-bold text-xl text-blue-600">$14.99<span className="text-xs font-normal text-gray-500">/mo</span></span>
                                     </div>
                                     <p className="text-sm text-gray-500 mb-4">For power users and creators.</p>
                                     <ul className="text-xs space-y-2 mb-4 text-gray-600">
                                         <li className="flex items-center gap-2"><Check size={12} className="text-blue-500"/> 200 Daily Credits</li>
                                         <li className="flex items-center gap-3 text-sm text-gray-300"><Check size={16} className="text-purple-400"/> Access to VibhavGPT Max & Ultra</li>
                                     </ul>
                                     <button onClick={() => { setSelectedTier(Tier.PRO); setView('checkout'); }} className="w-full bg-blue-600 text-white py-2 rounded-lg font-bold hover:bg-blue-700 transition shadow-lg shadow-blue-500/30">
                                         Select Pro
                                     </button>
                                 </div>
                             </div>
                         </div>
                     )}

                     {view === 'checkout' && selectedTier && (
                         <div className="animate-in fade-in slide-in-from-right-4 duration-300 h-full flex flex-col">
                             {!initialTier && (
                                 <button onClick={() => setView('selection')} className="flex items-center gap-2 text-sm text-gray-500 hover:text-black mb-6 transition w-fit">
                                     <ArrowLeft size={16}/> Back to Plans
                                 </button>
                             )}
                             
                             <div className="flex-1">
                                 <h3 className="font-bold text-gray-900 text-xl mb-6">Payment Details</h3>
                                 
                                 <div className="space-y-4">
                                     <div>
                                         <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Cardholder Name</label>
                                         <input 
                                            type="text" 
                                            value={name}
                                            onChange={e => setName(e.target.value)}
                                            placeholder="John Doe" 
                                            className="w-full p-3 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                                         />
                                     </div>
                                     
                                     <div>
                                         <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Card Number</label>
                                         <div className="relative">
                                             <CreditCard className="absolute left-3 top-3.5 text-gray-400" size={18}/>
                                             <input 
                                                type="text" 
                                                value={cardNumber}
                                                onChange={e => {
                                                    const v = e.target.value.replace(/\D/g, '').slice(0, 16);
                                                    setCardNumber(v.replace(/(\d{4})/g, '$1 ').trim());
                                                }}
                                                placeholder="0000 0000 0000 0000" 
                                                className="w-full pl-10 p-3 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 bg-white font-mono"
                                             />
                                         </div>
                                     </div>

                                     <div className="grid grid-cols-2 gap-4">
                                         <div>
                                             <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Expiry Date</label>
                                             <input 
                                                type="text" 
                                                value={expiry}
                                                onChange={e => {
                                                    let v = e.target.value.replace(/\D/g, '').slice(0, 4);
                                                    if(v.length >= 2) v = v.slice(0,2) + '/' + v.slice(2);
                                                    setExpiry(v);
                                                }}
                                                placeholder="MM/YY" 
                                                className="w-full p-3 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 bg-white font-mono text-center"
                                             />
                                         </div>
                                         <div>
                                             <label className="block text-xs font-bold text-gray-500 uppercase mb-1">CVC</label>
                                             <div className="relative">
                                                 <Lock className="absolute left-3 top-3.5 text-gray-400" size={16}/>
                                                 <input 
                                                    type="text" 
                                                    value={cvc}
                                                    onChange={e => setCvc(e.target.value.replace(/\D/g, '').slice(0, 3))}
                                                    placeholder="123" 
                                                    className="w-full pl-10 p-3 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 bg-white font-mono text-center"
                                                 />
                                             </div>
                                         </div>
                                     </div>
                                 </div>

                                 <div className="mt-8 bg-blue-50 border border-blue-100 p-3 rounded-lg flex items-start gap-3">
                                     <ShieldCheck className="text-blue-600 shrink-0 mt-0.5" size={18}/>
                                     <div className="text-xs text-blue-800">
                                         <strong>Secure Payment:</strong> Your payment information is encrypted and processed securely.
                                     </div>
                                 </div>
                             </div>

                             <div className="mt-6 pt-6 border-t border-gray-200">
                                 <button 
                                    onClick={handleCheckout}
                                    disabled={processing}
                                    className="w-full bg-gradient-to-r from-blue-600 to-red-500 text-white py-4 rounded-xl font-bold text-lg hover:opacity-90 transition shadow-lg flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                                 >
                                     {processing ? <Loader2 size={24} className="animate-spin"/> : `Pay $${getPrice(selectedTier)}`}
                                 </button>
                             </div>
                         </div>
                     )}
                 </div>
            </div>
        </div>
    );
};


export const AccessKeyModal = ({ onClose, onSuccess }: { onClose: () => void, onSuccess: (user: User) => void }) => {
  const [mode, setMode] = useState<'login' | 'signup' | 'admin'>('login');
  const [username, setUsername] = useState("");
  const [fullName, setFullName] = useState("");
  const [key, setKey] = useState("");
  const [dob, setDob] = useState("");
  const [error, setError] = useState("");

  const handleLogin = (e: React.FormEvent) => {
      e.preventDefault();
      setError("");
      
      const db = JSON.parse(localStorage.getItem('vibhav_db') || '{}');

      if (db[key]) {
          if (db[key].dob !== dob && key !== ACCESS_KEY && key !== UNLIMITED_KEY && key !== ADMIN_PASSWORD) {
              setError("Incorrect Date of Birth.");
              return;
          }
          onSuccess(db[key]);
          return;
      }

      let tier = Tier.FREE;
      let valid = false;
      let sysUsername = "User";
      let isSystem = false;

      if (key === ACCESS_KEY) { valid = true; isSystem = true; }
      else if (key === UNLIMITED_KEY) { valid = true; tier = Tier.UNLIMITED; sysUsername = "VIP User"; isSystem = true; }

      if (valid && isSystem) {
          const newUser: User = {
             username: sysUsername,
             fullName: sysUsername,
             isAuthenticated: true,
             tier,
             theme: 'light',
             credits: { dailyUsed: 0, monthlyUsed: 0, lastDailyReset: new Date().toISOString(), lastMonthlyReset: new Date().toISOString() },
             // ALL KEYS SYSTEM MANAGED BY DEFAULT
             apiKeys: {
                 vibhav: "SYSTEM_ACCESS_GRANTED",
                 openai: "SYSTEM_ACCESS_GRANTED",
                 anthropic: "SYSTEM_ACCESS_GRANTED",
                 xai: "SYSTEM_ACCESS_GRANTED",
                 deepseek: "SYSTEM_ACCESS_GRANTED",
                 moonshot: "SYSTEM_ACCESS_GRANTED",
                 google: "SYSTEM_ACCESS_GRANTED"
             }, 
             createdModels: [], savedRecipes: [], codeProjects: [], studySets: [],
             accessKey: key
          };
          db[key] = newUser;
          localStorage.setItem('vibhav_db', JSON.stringify(db));
          onSuccess(newUser);
          return;
      }
      setError("Access Key not found. Create a new account?");
  };

  const handleSignup = (e: React.FormEvent) => {
      e.preventDefault();
      setError("");
      if (!key.trim() || !username.trim() || !fullName.trim() || !dob.trim()) { setError("All fields are required."); return; }
      
      if ([ACCESS_KEY, ADMIN_PASSWORD, UNLIMITED_KEY].includes(key)) {
          setError("This key is reserved. Please choose another.");
          return;
      }

      const db = JSON.parse(localStorage.getItem('vibhav_db') || '{}');
      if (db[key]) {
          setError("This Access Key is already taken. Please choose another.");
          return;
      }

      const newUser: User = {
         username,
         fullName,
         isAuthenticated: true,
         tier: Tier.FREE, 
         theme: 'light',
         dob: dob,
         credits: { dailyUsed: 0, monthlyUsed: 0, lastDailyReset: new Date().toISOString(), lastMonthlyReset: new Date().toISOString() },
         // ALL KEYS SYSTEM MANAGED BY DEFAULT
         apiKeys: {
             vibhav: "SYSTEM_ACCESS_GRANTED",
             openai: "SYSTEM_ACCESS_GRANTED",
             anthropic: "SYSTEM_ACCESS_GRANTED",
             xai: "SYSTEM_ACCESS_GRANTED",
             deepseek: "SYSTEM_ACCESS_GRANTED",
             moonshot: "SYSTEM_ACCESS_GRANTED",
             google: "SYSTEM_ACCESS_GRANTED" 
         }, 
         createdModels: [], savedRecipes: [], codeProjects: [], studySets: [],
         accessKey: key
      };

      db[key] = newUser;
      localStorage.setItem('vibhav_db', JSON.stringify(db));
      onSuccess(newUser);
  };

  const handleAdminLogin = (e: React.FormEvent) => {
      e.preventDefault();
      setError("");
      if (key === ADMIN_PASSWORD) {
          const adminUser: User = {
             username: "Admin",
             fullName: "Vibhav Admin",
             isAuthenticated: true,
             tier: Tier.UNLIMITED,
             theme: 'light',
             credits: { dailyUsed: 0, monthlyUsed: 0, lastDailyReset: new Date().toISOString(), lastMonthlyReset: new Date().toISOString() },
             // Admin also gets system managed keys
             apiKeys: {
                 vibhav: "SYSTEM_ACCESS_GRANTED",
                 openai: "SYSTEM_ACCESS_GRANTED",
                 anthropic: "SYSTEM_ACCESS_GRANTED",
                 xai: "SYSTEM_ACCESS_GRANTED",
                 deepseek: "SYSTEM_ACCESS_GRANTED",
                 moonshot: "SYSTEM_ACCESS_GRANTED",
                 google: "SYSTEM_ACCESS_GRANTED"
             }, 
             createdModels: [], savedRecipes: [], codeProjects: [], studySets: [],
             accessKey: 'admin-session'
          };
          onSuccess(adminUser);
      } else {
          setError("Incorrect Admin Password");
      }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-[80] flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-md p-8 shadow-2xl relative animate-in fade-in zoom-in duration-200">
        <button onClick={onClose} className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-full"><X size={20}/></button>
        
        <h2 className="text-2xl font-bold mb-2">
            {mode === 'login' && 'Welcome Back'}
            {mode === 'signup' && 'Create Account'}
            {mode === 'admin' && 'Admin Access'}
        </h2>
        <p className="text-gray-500 mb-6">
            {mode === 'login' && 'Enter your Access Key to continue.'}
            {mode === 'signup' && 'Get your own Access Key to save your data.'}
            {mode === 'admin' && 'Enter system administration password.'}
        </p>

        {error && <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm mb-4 flex items-center gap-2"><AlertCircle size={16}/> {error}</div>}

        <form onSubmit={mode === 'login' ? handleLogin : mode === 'signup' ? handleSignup : handleAdminLogin} className="space-y-4">
            
            {mode === 'signup' && (
                <>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Full Name</label>
                        <input value={fullName} onChange={e => setFullName(e.target.value)} className="w-full p-3 border rounded-lg outline-none focus:border-blue-600" placeholder="John Doe" required/>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Username</label>
                        <input value={username} onChange={e => setUsername(e.target.value)} className="w-full p-3 border rounded-lg outline-none focus:border-blue-600" placeholder="johndoe" required/>
                    </div>
                </>
            )}

            {mode !== 'admin' && (
                <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Date of Birth</label>
                    <input type="date" value={dob} onChange={e => setDob(e.target.value)} className="w-full p-3 border rounded-lg outline-none focus:border-blue-600" required/>
                </div>
            )}

            <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">
                    {mode === 'admin' ? 'Admin Password' : 'Access Key (Password)'}
                </label>
                <div className="relative">
                    <Key className="absolute left-3 top-3.5 text-gray-400" size={18}/>
                    <input 
                        type="password" 
                        value={key} 
                        onChange={e => setKey(e.target.value)} 
                        className="w-full pl-10 p-3 border rounded-lg outline-none focus:border-blue-600 font-mono" 
                        placeholder={mode === 'admin' ? "••••••••" : "your-secret-key"}
                        required
                    />
                </div>
                {mode === 'login' && <div className="text-xs text-gray-400 mt-1">This key acts as your password. Don't lose it!</div>}
            </div>

            <button type="submit" className="w-full bg-gradient-to-r from-blue-600 to-red-600 text-white py-3 rounded-lg font-bold hover:opacity-90 transition shadow-lg">
                {mode === 'login' && 'Login'}
                {mode === 'signup' && 'Create Account'}
                {mode === 'admin' && 'Unlock System'}
            </button>
        </form>

        <div className="mt-6 pt-6 border-t border-gray-100 text-center text-sm text-gray-500 flex flex-col gap-2">
            {mode === 'login' && (
                <>
                    <p>Don't have a key? <button onClick={() => { setMode('signup'); setError(""); }} className="text-blue-600 font-bold hover:underline">Create one</button></p>
                    <button onClick={() => { setMode('admin'); setError(""); }} className="text-xs text-gray-300 hover:text-gray-500">Admin Login</button>
                </>
            )}
            {mode === 'signup' && (
                <p>Already have a key? <button onClick={() => { setMode('login'); setError(""); }} className="text-blue-600 font-bold hover:underline">Login</button></p>
            )}
            {mode === 'admin' && (
                <button onClick={() => { setMode('login'); setError(""); }} className="text-blue-600 font-bold hover:underline">Back to Login</button>
            )}
        </div>
      </div>
    </div>
  );
};
