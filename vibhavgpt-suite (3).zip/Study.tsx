
import React, { useState } from 'react';
import { ArrowLeft, Loader2, Brain, RotateCw, Play, GraduationCap, ChevronRight, Check } from 'lucide-react';
import { User, StudySet, ModelType } from './types';
import { generateAIResponse } from './services/geminiService';
import { Type } from "@google/genai";

const StudyApp = ({ user, setUser, updateCredits, onBack }: { user: User, setUser: any, updateCredits: any, onBack: () => void }) => {
    const [view, setView] = useState<'home' | 'create' | 'study'>('home');
    const [activeSet, setActiveSet] = useState<StudySet | null>(null);
    const [prompt, setPrompt] = useState("");
    const [loading, setLoading] = useState(false);
    const [index, setIndex] = useState(0);
    const [flipped, setFlipped] = useState(false);

    const generateSet = async () => {
        if (!updateCredits(2)) return;
        setLoading(true);
        try {
            const schema = { type: Type.OBJECT, properties: { title: {type: Type.STRING}, content: {type: Type.ARRAY, items: {type: Type.OBJECT, properties: {question: {type: Type.STRING}, answer: {type: Type.STRING}}}} } };
            const res = await generateAIResponse({ modelName: ModelType.GEMINI_3_PRO, prompt: `Create a comprehensive study set (10-15 cards) about: ${prompt}`, responseSchema: schema, responseMimeType: "application/json" });
            const data = JSON.parse(res.text);
            const newSet: StudySet = { id: Date.now().toString(), title: data.title, type: 'flashcard', content: data.content, author: user.username, isPublic: false };
            setUser({...user, studySets: [...user.studySets, newSet]});
            setActiveSet(newSet);
            setView('study');
        } catch(e) { alert("Error generating study set."); } finally { setLoading(false); }
    };

    if (view === 'study' && activeSet) {
        const card = activeSet.content[index];
        const progress = ((index + 1) / activeSet.content.length) * 100;

        return (
            <div className="h-full bg-indigo-50 flex flex-col font-sans">
                {/* Header */}
                <div className="px-8 py-6 flex items-center justify-between">
                     <button onClick={() => setView('home')} className="p-2 bg-white rounded-full hover:bg-gray-100 shadow-sm text-indigo-900 transition"><ArrowLeft size={20}/></button>
                     <div className="flex flex-col items-center">
                         <h2 className="font-bold text-indigo-900 text-lg">{activeSet.title}</h2>
                         <span className="text-xs text-indigo-400 font-bold tracking-widest uppercase">{index + 1} / {activeSet.content.length}</span>
                     </div>
                     <div className="w-10"></div>
                </div>

                {/* Progress Bar */}
                <div className="w-full h-1 bg-indigo-200">
                    <div className="h-full bg-indigo-600 transition-all duration-300" style={{width: `${progress}%`}}></div>
                </div>
                
                <div className="flex-1 flex flex-col items-center justify-center p-8">
                    <div 
                        onClick={() => setFlipped(!flipped)} 
                        className="w-full max-w-3xl aspect-[3/2] relative perspective-1000 cursor-pointer group"
                    >
                        <div className={`w-full h-full absolute inset-0 transition-all duration-500 transform-style-3d bg-white rounded-[40px] shadow-2xl shadow-indigo-200 flex items-center justify-center p-12 text-center border-4 border-white ${flipped ? 'rotate-y-180' : ''}`} style={{backfaceVisibility: 'hidden'}}>
                            <div className="text-3xl font-medium text-gray-800 leading-relaxed select-none">
                                {card.question}
                            </div>
                            <div className="absolute bottom-8 text-gray-400 text-sm font-bold uppercase tracking-widest flex items-center gap-2">
                                <RotateCw size={14}/> Tap to Flip
                            </div>
                        </div>

                        <div className={`w-full h-full absolute inset-0 transition-all duration-500 transform-style-3d bg-indigo-600 rounded-[40px] shadow-2xl shadow-indigo-500/30 flex items-center justify-center p-12 text-center border-4 border-indigo-500 ${flipped ? '' : 'rotate-y-180'}`} style={{backfaceVisibility: 'hidden', transform: flipped ? 'rotateY(0deg)' : 'rotateY(180deg)'}}>
                            <div className="text-3xl font-medium text-white leading-relaxed select-none">
                                {card.answer}
                            </div>
                        </div>
                    </div>

                    <div className="flex gap-4 mt-12">
                        <button onClick={() => { setFlipped(false); setTimeout(() => setIndex(Math.max(0, index-1)), 150); }} className="w-16 h-16 rounded-full bg-white text-indigo-900 shadow-lg flex items-center justify-center hover:scale-110 transition disabled:opacity-50" disabled={index === 0}>
                            <ArrowLeft size={24}/>
                        </button>
                        <button onClick={() => { setFlipped(false); setTimeout(() => setIndex(Math.min(activeSet.content.length-1, index+1)), 150); }} className="w-20 h-20 rounded-full bg-indigo-600 text-white shadow-xl shadow-indigo-500/40 flex items-center justify-center hover:scale-110 transition disabled:opacity-50" disabled={index === activeSet.content.length - 1}>
                            <Check size={32}/>
                        </button>
                    </div>
                </div>
            </div>
        )
    }

    if (view === 'create') {
        return (
            <div className="h-full bg-white flex flex-col items-center justify-center p-6 relative overflow-hidden">
                <button onClick={() => setView('home')} className="absolute top-8 left-8 p-3 rounded-full hover:bg-gray-100 transition z-10"><ArrowLeft size={24}/></button>
                
                {/* Background Blobs */}
                <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-100 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
                <div className="absolute bottom-0 left-0 w-96 h-96 bg-pink-100 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>

                <div className="relative z-10 w-full max-w-lg text-center">
                    <div className="w-24 h-24 bg-gradient-to-tr from-indigo-500 to-purple-500 text-white rounded-[30px] flex items-center justify-center mx-auto mb-8 shadow-xl shadow-indigo-500/30">
                        <Brain size={48} className="drop-shadow-md"/>
                    </div>
                    <h1 className="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight">What do you want to learn?</h1>
                    <p className="text-gray-500 mb-10 text-lg">Enter a topic, book, or concept. AI will build a custom study deck for you instantly.</p>
                    
                    <div className="bg-white p-2 rounded-3xl shadow-2xl shadow-indigo-100 border border-gray-100 flex flex-col gap-2">
                        <textarea 
                            value={prompt} 
                            onChange={e => setPrompt(e.target.value)} 
                            placeholder="e.g., 'Photosynthesis process', 'Spanish vocab for travel', 'React Hooks'..." 
                            className="w-full p-6 rounded-2xl outline-none resize-none text-xl text-center placeholder:text-gray-300 min-h-[120px]"
                        />
                        <button 
                            onClick={generateSet} 
                            disabled={loading || !prompt.trim()} 
                            className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-bold text-xl hover:bg-indigo-700 transition disabled:opacity-50 flex items-center justify-center gap-3 shadow-lg"
                        >
                            {loading ? <Loader2 className="animate-spin" size={24}/> : <Play size={24} fill="currentColor"/>}
                            {loading ? 'Building Deck...' : 'Start Learning'}
                        </button>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <div className="h-full bg-gray-50 p-8 overflow-y-auto font-sans">
            <div className="max-w-6xl mx-auto">
                <div className="flex justify-between items-center mb-12">
                    <div className="flex items-center gap-4">
                        <button onClick={onBack} className="text-gray-400 hover:text-black transition"><ArrowLeft/></button>
                        <h1 className="text-3xl font-extrabold text-indigo-900">Library</h1>
                    </div>
                    <button onClick={() => setView('create')} className="bg-indigo-600 text-white px-6 py-3 rounded-full text-sm font-bold hover:bg-indigo-700 transition shadow-lg shadow-indigo-500/30 flex items-center gap-2">
                        <PlusIcon /> Create Deck
                    </button>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {user.studySets.map(s => (
                        <div key={s.id} onClick={() => { setActiveSet(s); setView('study'); setIndex(0); setFlipped(false); }} className="bg-white p-8 rounded-3xl cursor-pointer hover:-translate-y-2 transition-transform duration-300 shadow-sm hover:shadow-xl border-b-4 border-gray-100 hover:border-indigo-500 group relative">
                             <div className="mb-4">
                                 <h3 className="font-bold text-xl text-gray-800 mb-1 group-hover:text-indigo-600 transition">{s.title}</h3>
                                 <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">{s.content.length} Cards</span>
                             </div>
                             <div className="flex items-center gap-2 text-indigo-500 font-bold text-sm opacity-0 group-hover:opacity-100 transition-opacity absolute bottom-8 right-8">
                                 Study <ChevronRight size={16}/>
                             </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

const PlusIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14M5 12h14"/></svg>
)

export default StudyApp;
