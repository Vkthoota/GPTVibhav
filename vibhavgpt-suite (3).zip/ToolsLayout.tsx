
import React, { useState } from 'react';
import { User, ToolConfig } from './types';
import { TOOLS } from './constants';
import ToolPage from './ToolPage';
import { Search, Wrench } from 'lucide-react';

const ToolsLayout = ({ user, setUser, updateCredits, onBack }: { user: User, setUser: any, updateCredits: any, onBack?: () => void }) => {
    const [currentTool, setCurrentTool] = useState<ToolConfig | null>(null);
    const [search, setSearch] = useState("");

    const filteredTools = TOOLS.filter(t => t.name.toLowerCase().includes(search.toLowerCase()) || t.description.toLowerCase().includes(search.toLowerCase()));

    if (currentTool) {
        return <ToolPage tool={currentTool} user={user} updateCredits={updateCredits} onBack={() => setCurrentTool(null)} />;
    }

    return (
        <div className="h-full bg-white p-8 overflow-y-auto font-sans">
            <div className="max-w-7xl mx-auto">
                <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
                    <div>
                        <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-green-600 mb-2 tracking-tight">Utilities</h1>
                        <p className="text-gray-500">Micro-tools for specific tasks. Fast, efficient, and precise.</p>
                    </div>
                    <div className="relative w-full md:w-80">
                        <Search className="absolute left-3 top-3 text-gray-400" size={18}/>
                        <input 
                            value={search} 
                            onChange={e => setSearch(e.target.value)} 
                            placeholder="Find a tool..." 
                            className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border-none rounded-xl outline-none focus:ring-2 focus:ring-green-100 transition text-sm"
                        />
                    </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {filteredTools.map(tool => (
                        <div 
                            key={tool.id} 
                            onClick={() => setCurrentTool(tool)} 
                            className="group border border-gray-100 bg-white p-5 rounded-2xl hover:border-green-200 hover:shadow-lg hover:shadow-green-900/5 transition-all cursor-pointer flex flex-col justify-between h-40 relative overflow-hidden"
                        >
                            <div className="absolute top-0 right-0 w-20 h-20 bg-green-50 rounded-full blur-xl -mr-10 -mt-10 transition opacity-0 group-hover:opacity-100"></div>
                            
                            <div className="relative z-10">
                                <h3 className="font-bold text-base text-gray-900 mb-1 group-hover:text-green-600 transition">{tool.name}</h3>
                                <p className="text-gray-500 text-xs leading-relaxed">{tool.description}</p>
                            </div>
                            <div className="relative z-10 flex items-center justify-between mt-4">
                                <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest bg-gray-50 px-2 py-1 rounded-md">{tool.cost} Credits</div>
                                <Wrench size={16} className="text-gray-300 group-hover:text-green-500 transition"/>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

export default ToolsLayout;
