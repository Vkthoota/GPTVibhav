import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';
import { Mic, MicOff, PhoneOff, Loader2, X, ChevronDown, Sparkles } from 'lucide-react';

interface GeminiLiveProps {
  onClose: () => void;
}

const VOICES = [
  { id: 'Zephyr', name: 'Zephyr', desc: 'Calm & Steady' },
  { id: 'Puck', name: 'Puck', desc: 'Playful' },
  { id: 'Charon', name: 'Charon', desc: 'Deep' },
  { id: 'Kore', name: 'Kore', desc: 'Soft' },
  { id: 'Fenrir', name: 'Fenrir', desc: 'Strong' },
];

const GeminiLive: React.FC<GeminiLiveProps> = ({ onClose }) => {
  const [isActive, setIsActive] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [status, setStatus] = useState("Initializing...");
  const [selectedVoice, setSelectedVoice] = useState("Zephyr");
  const [volumeLevel, setVolumeLevel] = useState(0); 
  const [showVoiceMenu, setShowVoiceMenu] = useState(false);
  
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // --- Audio Helpers ---
  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  async function decodeAudioData(
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  }

  function createBlob(data: Float32Array): Blob {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
      int16[i] = data[i] * 32768;
    }
    return {
      data: encode(new Uint8Array(int16.buffer)),
      mimeType: 'audio/pcm;rate=16000',
    };
  }

  const updateVisualizer = () => {
    if (analyserRef.current) {
        const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
        analyserRef.current.getByteFrequencyData(dataArray);
        const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
        setVolumeLevel(average); 
    }
    animationFrameRef.current = requestAnimationFrame(updateVisualizer);
  };

  const cleanup = () => {
      if (sessionPromiseRef.current) {
          sessionPromiseRef.current.then(s => s.close()).catch(e => console.error("Session close error", e));
      }
      if (inputAudioContextRef.current) inputAudioContextRef.current.close();
      if (outputAudioContextRef.current) outputAudioContextRef.current.close();
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      sourcesRef.current.forEach(s => s.stop());
      sourcesRef.current.clear();
  };

  const connect = async (voiceName: string) => {
      cleanup();
      setStatus("Connecting...");
      setIsActive(false);

      try {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
          const inCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
          const outCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
          
          const analyser = outCtx.createAnalyser();
          analyser.fftSize = 32;
          analyser.smoothingTimeConstant = 0.8;
          analyserRef.current = analyser;
          updateVisualizer();

          inputAudioContextRef.current = inCtx;
          outputAudioContextRef.current = outCtx;

          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          
          const sessionPromise = ai.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-12-2025',
            callbacks: {
              onopen: () => {
                setStatus("Active");
                setIsActive(true);
                const source = inCtx.createMediaStreamSource(stream);
                const scriptProcessor = inCtx.createScriptProcessor(4096, 1, 1);
                scriptProcessor.onaudioprocess = (e) => {
                  if (isMuted) return; 
                  const inputData = e.inputBuffer.getChannelData(0);
                  const pcmBlob = createBlob(inputData);
                  sessionPromise.then((session) => {
                    session.sendRealtimeInput({ media: pcmBlob });
                  });
                };
                source.connect(scriptProcessor);
                scriptProcessor.connect(inCtx.destination);
              },
              onmessage: async (message: LiveServerMessage) => {
                const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                if (base64Audio) {
                  nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outCtx.currentTime);
                  const audioBuffer = await decodeAudioData(decode(base64Audio), outCtx, 24000, 1);
                  const source = outCtx.createBufferSource();
                  source.buffer = audioBuffer;
                  source.connect(analyser); 
                  analyser.connect(outCtx.destination);
                  source.addEventListener('ended', () => sourcesRef.current.delete(source));
                  source.start(nextStartTimeRef.current);
                  nextStartTimeRef.current += audioBuffer.duration;
                  sourcesRef.current.add(source);
                }
                if (message.serverContent?.interrupted) {
                  sourcesRef.current.forEach(source => source.stop());
                  sourcesRef.current.clear();
                  nextStartTimeRef.current = 0;
                }
              },
              onerror: (e) => {
                console.error('Live Error:', e);
                setStatus("Error");
                setIsActive(false);
              },
              onclose: () => {
                setStatus("Disconnected");
                setIsActive(false);
              },
            },
            config: {
              responseModalities: [Modality.AUDIO],
              speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: voiceName } },
              },
              systemInstruction: 'You are VibhavGPT Live. Concise, helpful, friendly.',
            },
          });

          sessionPromiseRef.current = sessionPromise;
      } catch (e) {
          console.error(e);
          setStatus("Failed to connect");
      }
  };

  useEffect(() => {
    connect(selectedVoice);
    return cleanup;
  }, []);

  const handleVoiceSelect = (voiceId: string) => {
      setSelectedVoice(voiceId);
      setShowVoiceMenu(false);
      connect(voiceId);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 font-sans">
      <div className="bg-[#18181b] border border-white/10 w-[95%] md:w-full max-w-md rounded-[32px] md:rounded-[40px] p-6 md:p-8 shadow-2xl relative overflow-hidden transition-all animate-in fade-in zoom-in duration-300">
        
        {/* Glow */}
        <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-blue-500/10 rounded-full blur-[80px] transition-all duration-700 ${isActive ? 'opacity-100' : 'opacity-0'}`}></div>

        {/* Header */}
        <div className="relative z-10 flex justify-between items-center mb-8 md:mb-10">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-full border border-white/5">
                <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
                <span className="text-white/80 text-xs font-bold uppercase tracking-wider">{status}</span>
            </div>
            
            <button onClick={onClose} className="text-white/50 hover:text-white bg-white/5 hover:bg-white/10 p-2 rounded-full transition">
                <X size={20}/>
            </button>
        </div>

        {/* Visualizer & Centerpiece */}
        <div className="relative z-10 flex justify-center items-center mb-10 md:mb-12">
            <div className="relative w-32 h-32 md:w-40 md:h-40 flex items-center justify-center">
                {/* Ripples */}
                {[1, 2, 3].map(i => (
                    <div 
                        key={i}
                        className="absolute rounded-full border border-blue-500/20 transition-all duration-100 ease-out"
                        style={{
                            width: `${100 + (volumeLevel / 1.5) * i}%`,
                            height: `${100 + (volumeLevel / 1.5) * i}%`,
                            opacity: isActive ? Math.max(0, 0.4 - i * 0.1) : 0
                        }}
                    />
                ))}
                
                {/* Main Orb */}
                <div className="w-20 h-20 md:w-24 md:h-24 bg-gradient-to-tr from-blue-600 to-indigo-600 rounded-full flex items-center justify-center shadow-lg shadow-blue-600/30 z-20">
                    {isActive ? (
                        <div className="flex gap-1.5 items-center h-8">
                             {[1,2,3,4,5].map(bar => (
                                 <div 
                                    key={bar}
                                    className="w-1 md:w-1.5 bg-white rounded-full transition-all duration-75"
                                    style={{
                                        height: `${Math.max(20, Math.min(100, volumeLevel / 1.5 + Math.random() * 40))}%`,
                                    }}
                                 />
                             ))}
                        </div>
                    ) : (
                        <Loader2 className="text-white/50 animate-spin" size={32}/>
                    )}
                </div>
            </div>
        </div>

        {/* Controls */}
        <div className="relative z-10 space-y-4 md:space-y-6">
            {/* Voice Selector */}
            <div className="relative">
                <button 
                    onClick={() => setShowVoiceMenu(!showVoiceMenu)}
                    className="w-full flex items-center justify-between bg-white/5 hover:bg-white/10 border border-white/5 px-5 py-3 md:py-4 rounded-2xl transition text-white"
                >
                    <div className="flex items-center gap-3">
                        <Sparkles size={18} className="text-blue-400"/>
                        <span className="font-medium text-sm">{VOICES.find(v => v.id === selectedVoice)?.name}</span>
                    </div>
                    <ChevronDown size={16} className={`transition-transform ${showVoiceMenu ? 'rotate-180' : ''}`}/>
                </button>
                
                {showVoiceMenu && (
                    <div className="absolute bottom-full left-0 w-full mb-2 bg-[#27272a] border border-white/10 rounded-2xl overflow-hidden shadow-xl z-50">
                        {VOICES.map(v => (
                            <button
                                key={v.id}
                                onClick={() => handleVoiceSelect(v.id)}
                                className={`w-full text-left px-5 py-3 text-sm hover:bg-white/10 flex justify-between items-center ${selectedVoice === v.id ? 'text-blue-400 bg-white/5' : 'text-gray-300'}`}
                            >
                                <span>{v.name}</span>
                                <span className="opacity-50 text-xs">{v.desc}</span>
                            </button>
                        ))}
                    </div>
                )}
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-4">
                <button 
                    onClick={() => setIsMuted(!isMuted)}
                    className={`flex items-center justify-center gap-2 py-3 md:py-4 rounded-2xl font-bold transition-all ${isMuted ? 'bg-red-500/20 text-red-400 border border-red-500/30' : 'bg-white/5 text-white hover:bg-white/10 border border-white/5'}`}
                >
                    {isMuted ? <MicOff size={20}/> : <Mic size={20}/>}
                    <span className="text-sm">{isMuted ? 'Unmute' : 'Mute'}</span>
                </button>
                <button 
                    onClick={onClose}
                    className="flex items-center justify-center gap-2 py-3 md:py-4 rounded-2xl font-bold bg-red-600 hover:bg-red-700 text-white transition-all shadow-lg shadow-red-600/20"
                >
                    <PhoneOff size={20}/>
                    <span className="text-sm">End</span>
                </button>
            </div>
        </div>

      </div>
    </div>
  );
};

export default GeminiLive;
