
import React from 'react';
import { Check, X, Zap, Crown, Sparkles, ArrowLeft, Shield, Image as ImageIcon, Video } from 'lucide-react';
import { Tier } from './types';

interface PricingPageProps {
    user: any;
    onUpgrade: (tier: Tier) => void;
    onBack: () => void;
}

const PricingPage: React.FC<PricingPageProps> = ({ user, onUpgrade, onBack }) => {
    
    // Updated to trigger the checkout flow via parent component
    const handleSubscribe = (tier: Tier) => {
        onUpgrade(tier);
    };

    const isCurrent = (tier: Tier) => user.tier === tier;

    return (
        <div className="min-h-screen bg-[#f0f4f9] overflow-y-auto pb-20">
            {/* Header */}
            <div className="bg-white border-b border-gray-200 sticky top-0 z-20 px-6 py-4 flex items-center gap-4">
                <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition">
                    <ArrowLeft size={20} />
                </button>
                <div className="font-bold text-xl flex items-center gap-2">
                    VibhavGPT <span className="text-blue-500">Premium</span>
                </div>
            </div>

            <div className="max-w-7xl mx-auto px-4 py-12">
                <div className="text-center mb-16">
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-6">Unlock Infinite Intelligence</h1>
                    <p className="text-xl text-gray-500 max-w-2xl mx-auto">
                        Choose the plan that fits your creative and professional needs. Upgrade anytime.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                    
                    {/* Free Plan */}
                    <div className="bg-white rounded-[32px] p-8 border border-gray-100 shadow-sm relative flex flex-col">
                        <div className="mb-4">
                            <span className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">Starter</span>
                        </div>
                        <h2 className="text-3xl font-bold mb-2">Free</h2>
                        <div className="text-4xl font-bold mb-6">$0<span className="text-lg text-gray-400 font-normal">/mo</span></div>
                        <p className="text-gray-500 mb-8 text-sm">Essential AI access for casual users.</p>
                        
                        <div className="space-y-4 mb-8 flex-1">
                            <li className="flex items-center gap-3 text-sm text-gray-700"><Check size={16} className="text-green-500"/> 10 Daily Credits</li>
                            <li className="flex items-center gap-3 text-sm text-gray-700"><Check size={16} className="text-green-500"/> Access to VibhavGPT Bolt</li>
                            <li className="flex items-center gap-3 text-sm text-gray-700"><Check size={16} className="text-green-500"/> Standard Chat Speed</li>
                            <li className="flex items-center gap-3 text-sm text-gray-400"><X size={16}/> No Image Generation</li>
                            <li className="flex items-center gap-3 text-sm text-gray-400"><X size={16}/> No Video Generation</li>
                        </div>

                        <button 
                            disabled={isCurrent(Tier.FREE) || isCurrent(Tier.GUEST)}
                            className="w-full py-3 rounded-xl font-bold border-2 border-gray-100 text-gray-400 cursor-not-allowed"
                        >
                            {isCurrent(Tier.FREE) ? "Current Plan" : "Included"}
                        </button>
                    </div>

                    {/* Explorer Plan */}
                    <div className="bg-white rounded-[32px] p-8 border-2 border-blue-100 shadow-xl relative flex flex-col transform md:-translate-y-4">
                        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-blue-600 text-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wider shadow-lg">
                            Best Value
                        </div>
                        <div className="mb-4">
                            <span className="bg-blue-50 text-blue-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider flex w-fit items-center gap-1"><Zap size={12}/> Explorer</span>
                        </div>
                        <h2 className="text-3xl font-bold mb-2">Explorer</h2>
                        <div className="text-4xl font-bold mb-6 text-blue-600">$5.99<span className="text-lg text-gray-400 font-normal">/mo</span></div>
                        <p className="text-gray-500 mb-8 text-sm">For creators and students who need more power.</p>
                        
                        <div className="space-y-4 mb-8 flex-1">
                            <li className="flex items-center gap-3 text-sm text-gray-900 font-medium"><Check size={16} className="text-blue-500"/> 50 Daily Credits</li>
                            <li className="flex items-center gap-3 text-sm text-gray-900 font-medium"><ImageIcon size={16} className="text-blue-500"/> Unlock Image Generation</li>
                            <li className="flex items-center gap-3 text-sm text-gray-700"><Check size={16} className="text-blue-500"/> Access to GPT-4o & Claude Sonnet</li>
                            <li className="flex items-center gap-3 text-sm text-gray-700"><Check size={16} className="text-blue-500"/> Priority Support</li>
                            <li className="flex items-center gap-3 text-sm text-gray-400"><X size={16}/> No Video Generation</li>
                        </div>

                        {isCurrent(Tier.EXPLORER) ? (
                             <button disabled className="w-full py-3 rounded-xl font-bold bg-green-50 text-green-600 border border-green-200">Current Plan</button>
                        ) : (
                            <button onClick={() => handleSubscribe(Tier.EXPLORER)} className="w-full py-3 rounded-xl font-bold bg-blue-600 text-white hover:bg-blue-700 transition shadow-lg shadow-blue-500/30">
                                Upgrade to Explorer
                            </button>
                        )}
                    </div>

                    {/* Pro Plan */}
                    <div className="bg-gray-900 text-white rounded-[32px] p-8 border border-gray-800 shadow-2xl relative flex flex-col overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/50 to-blue-900/50 pointer-events-none"></div>
                        <div className="relative z-10">
                            <div className="mb-4">
                                <span className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider flex w-fit items-center gap-1"><Crown size={12}/> Pro</span>
                            </div>
                            <h2 className="text-3xl font-bold mb-2">Pro</h2>
                            <div className="text-4xl font-bold mb-6">$14.99<span className="text-lg text-gray-500 font-normal">/mo</span></div>
                            <p className="text-gray-400 mb-8 text-sm">The ultimate suite for professionals.</p>
                            
                            <div className="space-y-4 mb-8 flex-1">
                                <li className="flex items-center gap-3 text-sm text-white font-medium"><Check size={16} className="text-purple-400"/> 200 Daily Credits</li>
                                <li className="flex items-center gap-3 text-sm text-white font-medium"><Video size={16} className="text-purple-400"/> Unlock Veo Video Gen</li>
                                <li className="flex items-center gap-3 text-sm text-gray-300"><Check size={16} className="text-purple-400"/> Access to VibhavGPT Max & Ultra</li>
                                <li className="flex items-center gap-3 text-sm text-gray-300"><Check size={16} className="text-purple-400"/> Thinking Models (o1, R1)</li>
                                <li className="flex items-center gap-3 text-sm text-gray-300"><Check size={16} className="text-purple-400"/> Early Access to New Tools</li>
                            </div>

                            {isCurrent(Tier.PRO) || isCurrent(Tier.UNLIMITED) ? (
                                <button disabled className="w-full py-3 rounded-xl font-bold bg-gray-800 text-gray-400 border border-gray-700">Current Plan</button>
                            ) : (
                                <button onClick={() => handleSubscribe(Tier.PRO)} className="w-full py-3 rounded-xl font-bold bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:shadow-lg hover:shadow-purple-500/40 transition border border-white/10">
                                    Get Pro Access
                                </button>
                            )}
                        </div>
                    </div>

                </div>

                <div className="mt-16 text-center">
                    <p className="text-gray-500 text-sm flex items-center justify-center gap-2">
                        <Shield size={14}/> Secure payment processing. Cancel anytime.
                    </p>
                </div>
            </div>
        </div>
    );
};

export default PricingPage;
