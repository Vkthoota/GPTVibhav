
import React, { useState, useRef, useEffect } from 'react';
import { Loader2, ArrowLeft, Video, Clapperboard, Layers, Image as ImageIcon, Wand2, Play, Settings2, Download, AlertCircle, Key, MonitorPlay, Film } from 'lucide-react';
import { User, Tier } from './types';
import { generateVeoVideo } from './services/geminiService';
import { PaymentModal } from './Modals';

const VideoGenApp = ({ user, updateCredits, onBack }: { user: User, updateCredits: any, onBack: () => void }) => {
    const [mode, setMode] = useState<'text' | 'image' | 'storyboard' | 'extend'>('text');
    const [prompt, setPrompt] = useState("");
    const [model, setModel] = useState("veo-3.1-fast-generate-preview");
    const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
    const [loading, setLoading] = useState(false);
    const [status, setStatus] = useState("");
    const [videoUrl, setVideoUrl] = useState<string | null>(null);
    const [videoAsset, setVideoAsset] = useState<any>(null);
    const [sourceImage, setSourceImage] = useState<{data: string, mimeType: string} | null>(null);
    const [lastImage, setLastImage] = useState<{data: string, mimeType: string} | null>(null);
    const [showPayment, setShowPayment] = useState(false);
    const [showSettings, setShowSettings] = useState(false);

    if (user.tier === Tier.FREE || user.tier === Tier.GUEST) {
        return (
            <div className="h-full bg-white text-gray-900 flex flex-col items-center justify-center p-12 relative overflow-hidden font-sans">
                <button onClick={onBack} className="absolute top-8 left-8 p-2 rounded-full hover:bg-gray-100 transition"><ArrowLeft size={20}/></button>
                <div className="max-w-md text-center relative z-10 animate-in fade-in zoom-in duration-500">
                    <div className="w-16 h-16 bg-black text-white rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                        <Video size={32} />
                    </div>
                    <h1 className="text-3xl font-bold mb-3 tracking-tight text-gray-900">VidCraft Studio</h1>
                    <p className="text-gray-500 mb-8 text-lg leading-relaxed">Cinematic video generation powered by Veo. Upgrade to Explorer or Pro to unlock this studio.</p>
                    <button onClick={() => setShowPayment(true)} className="bg-black text-white px-8 py-3 rounded-full font-bold hover:opacity-80 transition shadow-lg flex items-center gap-2 mx-auto">
                        <Wand2 size={18}/> Upgrade Access
                    </button>
                </div>
                <PaymentModal isOpen={showPayment} onClose={() => setShowPayment(false)} onUpgrade={(t) => { window.location.reload(); }} />
            </div>
        )
    }

    const ensureApiKey = async (forceObj?: boolean) => {
        if ((window as any).aistudio) {
            const hasKey = await (window as any).aistudio.hasSelectedApiKey();
            if (!hasKey || forceObj) {
                try {
                    await (window as any).aistudio.openSelectKey();
                    await new Promise(r => setTimeout(r, 1000));
                    return true;
                } catch (e) {
                    console.error("Key selection failed", e);
                    return false;
                }
            }
        }
        return true;
    };

    const handleGenerate = async () => {
        if (!prompt.trim() && mode === 'text') return;
        if (mode === 'image' && !sourceImage) return;
        if (mode === 'storyboard' && (!sourceImage || !lastImage)) return;
        if (mode === 'extend' && !videoAsset) { alert("Generate a video first to extend it."); return; }
        
        await ensureApiKey(); 
        
        if (!updateCredits(10)) return;

        setLoading(true);
        setStatus("Initializing...");
        setVideoUrl(null);

        const apiKey = process.env.API_KEY || user.apiKeys?.google || '';
        
        try {
            const res = await generateVeoVideo(
                prompt || (mode === 'image' ? "Animate this image" : mode === 'storyboard' ? "Transition" : "Continue"), 
                model, 
                apiKey, 
                (s) => setStatus(s),
                (mode === 'image' || mode === 'storyboard') && sourceImage ? sourceImage : undefined,
                mode === 'storyboard' && lastImage ? lastImage : undefined,
                mode === 'extend' ? videoAsset : undefined,
                aspectRatio
            );
            setVideoUrl(res.url);
            setVideoAsset(res.asset);
        } catch (e: any) {
            console.error(e);
            const errMsg = e.message || JSON.stringify(e);
            if (errMsg.includes("403") || errMsg.includes("PERMISSION_DENIED") || errMsg.includes("404") || errMsg.includes("not found")) {
                 alert("Access Issue: The selected API key does not have permission for Veo. Please select a valid project key with billing enabled.");
                 await ensureApiKey(true);
            } else {
                 alert("Generation Failed: " + errMsg);
            }
        } finally {
            setLoading(false);
            setStatus("");
        }
    };

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, isLast: boolean = false) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64 = (reader.result as string).split(',')[1];
                if(isLast) setLastImage({ data: base64, mimeType: file.type });
                else setSourceImage({ data: base64, mimeType: file.type });
            };
            reader.readAsDataURL(file);
        }
    };

    return (
        <div className="h-full bg-white text-gray-900 flex flex-col font-sans overflow-hidden">
            
            {/* Header */}
            <div className="h-14 border-b border-gray-100 flex items-center justify-between px-4 bg-white z-20">
                <div className="flex items-center gap-4">
                    <button onClick={onBack} className="p-2 hover:bg-gray-50 rounded-lg transition text-gray-500 hover:text-black"><ArrowLeft size={18}/></button>
                    <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm">VidCraft</span>
                        <span className="text-gray-300">/</span>
                        <span className="text-xs font-medium text-gray-500 bg-gray-50 px-2 py-0.5 rounded-full border border-gray-100">Veo 3.1</span>
                    </div>
                </div>
                
                <div className="flex bg-gray-50 p-1 rounded-lg border border-gray-100">
                    {[
                        {id: 'text', icon: <Wand2 size={14}/>, label: 'Text'},
                        {id: 'image', icon: <ImageIcon size={14}/>, label: 'Image'},
                        {id: 'storyboard', icon: <Layers size={14}/>, label: 'Storyboard'},
                        {id: 'extend', icon: <Play size={14}/>, label: 'Extend'},
                    ].map((m) => (
                        <button 
                            key={m.id}
                            onClick={() => setMode(m.id as any)}
                            disabled={m.id === 'extend' && !videoAsset}
                            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition flex items-center gap-2 ${mode === m.id ? 'bg-white text-black shadow-sm ring-1 ring-black/5' : 'text-gray-500 hover:text-gray-800 disabled:opacity-30'}`}
                        >
                            {m.icon} {m.label}
                        </button>
                    ))}
                </div>

                <div className="w-8"></div> {/* Spacer balance */}
            </div>

            <div className="flex-1 flex overflow-hidden">
                
                {/* Main Stage */}
                <div className="flex-1 bg-[#f4f4f5] flex items-center justify-center p-8 relative">
                    <div className="relative w-full max-w-4xl aspect-video bg-[#09090b] rounded-xl shadow-2xl flex items-center justify-center overflow-hidden ring-1 ring-black/5 group">
                        {loading && (
                            <div className="absolute inset-0 bg-black/80 z-20 flex flex-col items-center justify-center backdrop-blur-sm">
                                <Loader2 size={32} className="text-white animate-spin mb-4"/>
                                <span className="text-xs font-medium text-gray-400 uppercase tracking-widest animate-pulse">{status}</span>
                            </div>
                        )}
                        
                        {!videoUrl && !loading && (
                            <div className="text-center opacity-40 group-hover:opacity-60 transition duration-500 text-white">
                                <MonitorPlay size={48} className="mx-auto mb-4 stroke-1"/>
                                <p className="text-sm font-medium tracking-wide">PREVIEW AREA</p>
                            </div>
                        )}

                        {videoUrl && (
                            <video 
                                src={videoUrl} 
                                className="w-full h-full object-contain" 
                                controls 
                                autoPlay
                                loop
                            />
                        )}
                    </div>
                </div>

                {/* Right Control Sidebar */}
                <div className="w-80 border-l border-gray-100 bg-white flex flex-col z-10">
                    <div className="p-5 border-b border-gray-50 flex items-center justify-between">
                         <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Configuration</h3>
                         <button onClick={() => setShowSettings(!showSettings)} className={`p-1.5 rounded-md transition ${showSettings ? 'bg-gray-100 text-black' : 'text-gray-400 hover:text-black'}`}>
                            <Settings2 size={16}/>
                         </button>
                    </div>

                    <div className="flex-1 overflow-y-auto p-5 space-y-6">
                        
                        {/* Settings Overlay (Inline) */}
                        {showSettings && (
                            <div className="p-4 bg-gray-50 rounded-xl border border-gray-100 space-y-4 mb-4 animate-in fade-in slide-in-from-top-2">
                                <div>
                                    <label className="block text-xs font-semibold text-gray-600 mb-2">Model Version</label>
                                    <select value={model} onChange={e => setModel(e.target.value)} className="w-full bg-white border border-gray-200 rounded-lg p-2.5 text-xs outline-none text-gray-800 focus:border-black/20 focus:ring-2 focus:ring-black/5">
                                        <option value="veo-3.1-fast-generate-preview">Veo Fast (Standard)</option>
                                        <option value="veo-3.1-generate-preview">Veo Pro (High Quality)</option>
                                    </select>
                                </div>
                                <button onClick={() => ensureApiKey(true)} className="w-full flex items-center justify-center gap-2 py-2 rounded-lg bg-white border border-gray-200 text-gray-600 hover:bg-gray-50 text-xs font-medium transition">
                                    <Key size={12}/> Update API Key
                                </button>
                            </div>
                        )}

                        {(mode === 'image' || mode === 'storyboard') && (
                            <div className="space-y-3">
                                <label className="text-xs font-bold text-gray-900">Start Frame</label>
                                <div className="relative w-full aspect-video rounded-lg border border-dashed border-gray-300 bg-gray-50 hover:bg-gray-100 hover:border-gray-400 transition overflow-hidden group cursor-pointer">
                                    {sourceImage ? (
                                        <>
                                            <img src={`data:${sourceImage.mimeType};base64,${sourceImage.data}`} className="w-full h-full object-cover" alt="Start"/>
                                            <button onClick={() => setSourceImage(null)} className="absolute top-2 right-2 bg-black/50 text-white p-1 rounded-full hover:bg-red-500 transition backdrop-blur-sm"><AlertCircle size={12}/></button>
                                        </>
                                    ) : (
                                        <label className="absolute inset-0 flex flex-col items-center justify-center cursor-pointer text-gray-400">
                                            <ImageIcon size={20} className="mb-2 opacity-50"/>
                                            <span className="text-[10px] font-medium uppercase tracking-wide">Upload Image</span>
                                            <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, false)}/>
                                        </label>
                                    )}
                                </div>
                            </div>
                        )}

                        {mode === 'storyboard' && (
                            <div className="space-y-3">
                                <label className="text-xs font-bold text-gray-900">End Frame</label>
                                <div className="relative w-full aspect-video rounded-lg border border-dashed border-gray-300 bg-gray-50 hover:bg-gray-100 hover:border-gray-400 transition overflow-hidden group cursor-pointer">
                                    {lastImage ? (
                                        <>
                                            <img src={`data:${lastImage.mimeType};base64,${lastImage.data}`} className="w-full h-full object-cover" alt="End"/>
                                            <button onClick={() => setLastImage(null)} className="absolute top-2 right-2 bg-black/50 text-white p-1 rounded-full hover:bg-red-500 transition backdrop-blur-sm"><AlertCircle size={12}/></button>
                                        </>
                                    ) : (
                                        <label className="absolute inset-0 flex flex-col items-center justify-center cursor-pointer text-gray-400">
                                            <ImageIcon size={20} className="mb-2 opacity-50"/>
                                            <span className="text-[10px] font-medium uppercase tracking-wide">Upload Image</span>
                                            <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, true)}/>
                                        </label>
                                    )}
                                </div>
                            </div>
                        )}

                        <div className="space-y-3">
                            <label className="text-xs font-bold text-gray-900">Prompt</label>
                            <textarea 
                                value={prompt}
                                onChange={e => setPrompt(e.target.value)}
                                placeholder="Describe the motion, camera angles, lighting..."
                                className="w-full h-32 bg-gray-50 border border-gray-200 rounded-xl p-4 text-sm text-gray-900 outline-none focus:border-black/20 focus:ring-2 focus:ring-black/5 transition resize-none placeholder:text-gray-400"
                            />
                        </div>

                         <div className="space-y-3">
                            <label className="text-xs font-bold text-gray-900">Aspect Ratio</label>
                            <div className="grid grid-cols-2 gap-2">
                                <button onClick={() => setAspectRatio('16:9')} className={`py-2 rounded-lg text-xs font-semibold border transition ${aspectRatio === '16:9' ? 'bg-black text-white border-black' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'}`}>16:9 Landscape</button>
                                <button onClick={() => setAspectRatio('9:16')} className={`py-2 rounded-lg text-xs font-semibold border transition ${aspectRatio === '9:16' ? 'bg-black text-white border-black' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'}`}>9:16 Portrait</button>
                            </div>
                        </div>

                    </div>

                    <div className="p-5 border-t border-gray-100 bg-white">
                        <button 
                            onClick={handleGenerate}
                            disabled={loading}
                            className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold bg-black text-white hover:opacity-80 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
                        >
                            {loading ? <Loader2 className="animate-spin" size={16}/> : <Film size={16}/>}
                            Generate Video
                        </button>
                        <div className="text-center mt-3 text-[10px] text-gray-400 font-medium">
                            Cost: 10 Credits
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default VideoGenApp;
