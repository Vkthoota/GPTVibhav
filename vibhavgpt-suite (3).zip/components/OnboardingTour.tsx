
import React, { useState } from 'react';
import { ArrowRight, Check, X, Sparkles, ChevronDown, LayoutGrid, Zap, Search } from 'lucide-react';

interface Props {
  onComplete: () => void;
}

const OnboardingTour: React.FC<Props> = ({ onComplete }) => {
  const [step, setStep] = useState(0);

  const steps = [
    {
      title: "Welcome to VibhavGPT",
      description: "You've unlocked the ultimate AI workspace. Access the world's best models—Gemini 3, GPT-5, Claude, and more—all from one unified interface.",
      icon: <Sparkles className="w-12 h-12 text-blue-500 mb-4" />,
      highlight: null
    },
    {
      title: "Select Your Intelligence",
      description: "Click the dropdown at the top to switch between models instantly. Use 'VibhavGPT Max' for ultimate reasoning or 'Bolt' for speed.",
      icon: <ChevronDown className="w-12 h-12 text-purple-500 mb-4" />,
      highlight: "header-model-selector" 
    },
    {
      title: "Tools & Apps",
      description: "The sidebar is your command center. Access specialized Apps for coding and video generation, or use Tools like the AI Calculator and Detector.",
      icon: <LayoutGrid className="w-12 h-12 text-orange-500 mb-4" />,
      highlight: "sidebar-nav"
    },
    {
      title: "Powerful Input",
      description: "Attach files, paste YouTube links for analysis, or toggle Web Search for real-time data. You can even talk to VibhavGPT using the Live mode.",
      icon: <Zap className="w-12 h-12 text-green-500 mb-4" />,
      highlight: "input-area"
    },
    {
      title: "Ready to Launch",
      description: "You have free daily credits to start exploring. Upgrade to Explorer or Pro for advanced features like Video Generation and unlimited thinking models.",
      icon: <Check className="w-12 h-12 text-blue-600 mb-4" />,
      highlight: null
    }
  ];

  const currentStep = steps[step];

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white rounded-[32px] max-w-md w-full p-8 shadow-2xl relative border border-white/20">
        <button 
          onClick={onComplete} 
          className="absolute top-6 right-6 text-gray-400 hover:text-gray-900 transition"
        >
          <X size={24} />
        </button>

        <div className="flex flex-col items-center text-center">
            <div className="bg-gray-50 p-6 rounded-full mb-6 shadow-inner">
                {currentStep.icon}
            </div>
            
            <h2 className="text-2xl font-bold text-gray-900 mb-3">
              {currentStep.title}
            </h2>
            
            <p className="text-gray-500 leading-relaxed mb-8 h-20">
              {currentStep.description}
            </p>

            <div className="flex gap-2 mb-8">
              {steps.map((_, i) => (
                <div 
                  key={i} 
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${i === step ? 'w-8 bg-blue-600' : 'bg-gray-200'}`}
                />
              ))}
            </div>

            <button 
              onClick={handleNext}
              className="w-full bg-black text-white py-4 rounded-xl font-bold hover:bg-gray-800 transition flex items-center justify-center gap-2 shadow-lg"
            >
              {step === steps.length - 1 ? 'Get Started' : 'Next'} 
              {step !== steps.length - 1 && <ArrowRight size={18} />}
            </button>
        </div>
      </div>
    </div>
  );
};

export default OnboardingTour;
