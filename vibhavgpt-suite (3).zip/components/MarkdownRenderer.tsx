import React from 'react';

// Simple regex-based markdown parser since we can't install heavy libraries
// Supports: Bold, Italic, Code Blocks, Inline Code, Headers, Lists, Tables

interface Props {
  content: string;
}

const MarkdownRenderer: React.FC<Props> = ({ content }) => {
  const renderBlock = (block: string, index: number) => {
    // Headers
    if (block.match(/^#{1,6}\s/)) {
      const level = block.match(/^#+/)?.[0].length || 1;
      const text = block.replace(/^#{1,6}\s/, '');
      const sizes = ['text-3xl', 'text-2xl', 'text-xl', 'text-lg', 'text-base', 'text-sm'];
      return <div key={index} className={`font-bold my-2 ${sizes[level - 1]}`}>{text}</div>;
    }

    // Code Blocks
    if (block.startsWith('```')) {
      const lines = block.split('\n');
      const lang = lines[0].replace('```', '').trim();
      const code = lines.slice(1, -1).join('\n');
      return (
        <div key={index} className="bg-gray-800 text-gray-100 p-3 rounded-md my-2 overflow-x-auto font-mono text-sm relative group">
          <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity text-xs text-gray-400">{lang}</div>
          <pre>{code}</pre>
        </div>
      );
    }

    // Tables
    if (block.includes('|') && block.includes('\n') && block.trim().split('\n').length > 1) {
        const rows = block.trim().split('\n').map(r => r.trim()).filter(r => r);
        // Basic check if it looks like a table
        if (rows.length >= 2 && rows[0].includes('|') && rows[1].includes('---')) {
            const headers = rows[0].split('|').filter(c => c.trim() !== '').map(c => c.trim());
            const dataRows = rows.slice(2).map(row => 
                row.split('|').filter(c => c.trim() !== '').map(c => c.trim())
            );

            return (
                <div key={index} className="overflow-x-auto my-3 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead className="bg-gray-50 dark:bg-gray-800">
                            <tr>
                                {headers.map((h, i) => (
                                    <th key={i} className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">{h}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
                            {dataRows.map((row, i) => (
                                <tr key={i}>
                                    {row.map((cell, j) => (
                                        <td key={j} className="px-4 py-2 whitespace-normal text-sm text-gray-700 dark:text-gray-300">
                                            <span dangerouslySetInnerHTML={{__html: parseInline(cell)}} />
                                        </td>
                                    ))}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )
        }
    }

    // Lists
    if (block.match(/^(\*|-|\d+\.)\s/)) {
       const items = block.split('\n').filter(l => l.trim());
       return (
           <ul key={index} className="list-disc pl-5 my-2 space-y-1">
               {items.map((item, i) => (
                   <li key={i} dangerouslySetInnerHTML={{__html: parseInline(item.replace(/^(\*|-|\d+\.)\s/, ''))}} />
               ))}
           </ul>
       )
    }

    // Paragraphs
    return <p key={index} className="my-2 leading-relaxed" dangerouslySetInnerHTML={{__html: parseInline(block)}} />;
  };

  const parseInline = (text: string) => {
    // Bold
    text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    // Italic
    text = text.replace(/\*(.*?)\*/g, '<em>$1</em>');
    // Inline Code
    text = text.replace(/`([^`]+)`/g, '<code class="bg-gray-200 dark:bg-gray-700 px-1 rounded font-mono text-sm">$1</code>');
    // Links
    text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" class="text-blue-500 hover:underline">$1</a>');
    return text;
  };

  // Split content logic carefully
  const blocks = [];
  const lines = content.split('\n');
  let currentBlock = '';
  let inCodeBlock = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.trim().startsWith('```')) {
        if (inCodeBlock) {
             // End code block
             currentBlock += line;
             blocks.push(currentBlock);
             currentBlock = '';
             inCodeBlock = false;
        } else {
             // Start code block
             if (currentBlock) blocks.push(currentBlock);
             currentBlock = line + '\n';
             inCodeBlock = true;
        }
    } else {
        if (inCodeBlock) {
            currentBlock += line + '\n';
        } else {
            // Check for table start
            if (line.trim().startsWith('|')) {
               currentBlock += line + '\n';
            } else if (currentBlock.includes('|') && !line.trim().startsWith('|')) {
               // End of table
               blocks.push(currentBlock);
               currentBlock = line + '\n';
            } else {
               // Normal text, aggregate unless double newline (paragraph break)
               if (line.trim() === '') {
                   if (currentBlock) blocks.push(currentBlock);
                   currentBlock = '';
               } else {
                   currentBlock += line + '\n';
               }
            }
        }
    }
  }
  if (currentBlock) blocks.push(currentBlock);

  return <div className="markdown-body">{blocks.map(renderBlock)}</div>;
};

export default MarkdownRenderer;
