
export enum Tier {
  GUEST = 'Guest',
  FREE = 'Free',
  EXPLORER = 'Explorer',
  PRO = 'Pro',
  UNLIMITED = 'Unlimited'
}

export type AppTheme = 'light' | 'dark' | 'blue' | 'brown' | 'red' | 'green';

export enum ResponseStyle {
  CONCISE = 'Concise',
  DETAILED = 'Detailed',
  THINKING = 'Thinking',
  CUSTOM = 'Custom'
}

export enum ModelType {
  MAX = 'VibhavGPT Max', 
  BOLT = 'VibhavGPT Bolt',
  PLUS = 'VibhavGPT Plus',
  ULTRA = 'VibhavGPT Ultra',
  MUSE = 'VibhavGPT Muse',
  ATLAS = 'VibhavGPT Atlas',
  KIMI_K2_5_INSTANT = 'Kimi k2.5 instant',
  KIMI_K2_5_THINKING = 'Kimi k2.5 thinking',
  KIMI_K2_5_AGENT = 'Kimi k2.5 agent',
  KIMI_K2_5_SWARM = 'Kimi k2.5 agent swarm',
  KIMI_K2_5_PRO = 'Kimi k2.5 Pro',
  DEEPSEEK_V3 = 'DeepSeek-V3',
  DEEPSEEK_R1 = 'DeepSeek-R1',
  DEEPSEEK_V2 = 'DeepSeek-V2',
  GEMINI_3_PRO = 'Gemini 3 Pro',
  GEMINI_3_FAST = 'Gemini 3 Fast',
  GEMINI_3_THINKING = 'Gemini 3 Thinking',
  GEMINI_3_BASE = 'Gemini 3 Base',
  GEMINI_2_5_FLASH_LITE = 'Gemini 2.5 Flash Lite',
  GEMINI_2_THINKING = 'Gemini 2 Thinking',
  GEMINI_2_FAST = 'Gemini 2 Fast',
  GEMINI_2_BASE = 'Gemini 2 Base',
  GEMINI_1_5_PRO = 'Gemini 1.5 Pro',
  GEMINI_1_5_FLASH = 'Gemini 1.5 Flash',
  GPT_5_2_PRO = 'GPT-5.2 Pro',
  GPT_5_2_THINKING = 'GPT-5.2 Thinking',
  GPT_5_2_INSTANT = 'GPT-5.2 Instant',
  GPT_4O = 'GPT-4o',
  GPT_4_TURBO = 'GPT-4 Turbo',
  CLAUDE_4_6_OPUS = 'Claude 4.6 Opus',
  CLAUDE_4_5_HAIKU = 'Claude 4.5 Haiku',
  CLAUDE_4_5_OPUS = 'Claude 4.5 Opus',
  CLAUDE_4_5_SONNET = 'Claude 4.5 Sonnet',
  CLAUDE_SONNET_4 = 'Sonnet 4',
  CLAUDE_OPUS_3 = 'Opus 3',
  CLAUDE_HAIKU_3_5 = 'Haiku 3.5',
  CLAUDE_3_5_SONNET = 'Claude 3.5 Sonnet',
  GROK_4_1_AUTO = 'Grok 4.1 Auto',
  GROK_4_1_THINKING = 'Grok 4.1 Thinking',
  GROK_4_1_EXPERT = 'Grok 4.1 Expert',
  GROK_4_1_FAST = 'Grok 4.1 Fast',
  GROK_2 = 'Grok 2',
  GROK_4 = 'Grok 4'
}

export interface Attachment {
  id: string;
  type: 'image' | 'file' | 'youtube' | 'video';
  content: string; 
  name: string; 
  mimeType?: string;
  meta?: string; 
}

export interface User {
  username: string; 
  fullName?: string; 
  isAuthenticated: boolean;
  tier: Tier;
  theme: AppTheme; 
  hasCompletedOnboarding?: boolean; 
  accessKey?: string; 
  dob?: string; 
  memory?: string; 
  credits: {
    dailyUsed: number;
    monthlyUsed: number;
    lastDailyReset: string; 
    lastMonthlyReset: string; 
  };
  apiKeys: Record<string, string>; 
  createdModels: CustomModel[];
  savedRecipes: Recipe[];
  codeProjects: CodeProject[];
  studySets: StudySet[];
  pendingShares?: string[];
  customProfile?: string;
  githubAccount?: {
      username: string;
      linkedAt: number;
  };
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  attachments?: Attachment[];
  sources?: { title: string; uri: string }[];
}

export interface ChatSession {
  id: string;
  title: string;
  model: string;
  messages: Message[];
  sharedWith: string[]; 
  sharedBy?: string; 
  lastUpdated: number;
}

export interface CustomModel {
  id: string;
  name: string;
  description: string;
  systemInstruction: string;
  webSearch: boolean;
  temperature: number; 
  responseSpeed: number; 
  maxLength: number;
  author: string;
  isPublic: boolean;
  isActive?: boolean; 
  forkedFrom?: string;
}

export interface CodeProject {
  id: string;
  name: string;
  language: string;
  code: string; 
  chatHistory: Message[];
  isPublic: boolean;
  author: string;
  forkedFrom?: string;
  lastUpdated: number;
  githubRepo?: string;
  lastSynced?: number;
}

export interface Recipe {
  id: string;
  title: string;
  cuisine: string;
  mealType: string;
  content: string; 
  nutrition: {
      calories: number;
      protein: string;
      carbs: string;
      fat: string;
  };
  author: string;
  isPublic: boolean;
  forkedFrom?: string;
}

export interface StudySet {
  id: string;
  title: string;
  type: 'flashcard' | 'quiz';
  content: Array<{
      question: string;
      answer: string;
      options?: string[]; 
  }>;
  author: string;
  isPublic: boolean;
  forkedFrom?: string;
}

export interface ToolConfig {
  id: string;
  name: string;
  description: string;
  cost: number; 
  icon: string;
}

export interface AppConfig {
  id: string;
  name: string;
  description: string;
  icon: string;
}
