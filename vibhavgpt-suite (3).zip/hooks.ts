import { useState, useEffect } from 'react';
import { User, Tier, AppTheme } from './types';
import { TIER_LIMITS } from './constants';

export const useUser = () => {
  const [user, setUserState] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Helper to sync to localStorage
  const setUser = (newUser: User | null) => {
    setUserState(newUser);
    if (newUser) {
      localStorage.setItem('vibhav_user_v4', JSON.stringify(newUser));
      // Also update the "database" for persistence across sessions
      if (newUser.accessKey) {
        const db = JSON.parse(localStorage.getItem('vibhav_db') || '{}');
        db[newUser.accessKey] = newUser;
        localStorage.setItem('vibhav_db', JSON.stringify(db));
      }
    } else {
      localStorage.removeItem('vibhav_user_v4');
    }
  };

  useEffect(() => {
    const loadUser = () => {
      const saved = localStorage.getItem('vibhav_user_v4');
      if (saved) {
        try {
          let parsedUser: User = JSON.parse(saved);
          
          // --- Daily Credit Reset Logic ---
          const now = new Date();
          const lastReset = new Date(parsedUser.credits.lastDailyReset);
          
          if (now.toDateString() !== lastReset.toDateString()) {
            parsedUser.credits.dailyUsed = 0;
            parsedUser.credits.lastDailyReset = now.toISOString();
          }

          // --- Monthly Credit Reset Logic ---
          const lastMonthlyReset = new Date(parsedUser.credits.lastMonthlyReset);
          if (now.getMonth() !== lastMonthlyReset.getMonth() || now.getFullYear() !== lastMonthlyReset.getFullYear()) {
             parsedUser.credits.monthlyUsed = 0;
             parsedUser.credits.lastMonthlyReset = now.toISOString();
          }

          setUser(parsedUser);
        } catch (e) {
          console.error("Failed to parse saved user", e);
        }
      }
      setIsLoading(false);
    };

    loadUser();
  }, []);

  const updateCredits = (cost: number): boolean => {
    if (!user) return false;
    
    // Unlimited tier check
    if (user.tier === Tier.UNLIMITED) return true;

    const tierLimits = TIER_LIMITS[user.tier];
    const dailyLimit = tierLimits.daily;
    const monthlyLimit = tierLimits.monthly;

    // Daily credits don't compile. Capped by monthly limit remainder.
    const monthlyRemaining = monthlyLimit - user.credits.monthlyUsed;
    const effectiveDailyLimit = Math.min(dailyLimit, monthlyRemaining);

    if (user.credits.dailyUsed + cost > effectiveDailyLimit) {
      if (monthlyRemaining < dailyLimit && user.credits.dailyUsed + cost > monthlyRemaining) {
        alert(`You've reached your monthly allowance limit (${monthlyLimit} credits). Please upgrade for more!`);
      } else {
        alert(`You've reached your daily limit of ${dailyLimit} credits. Upgrade to a higher tier for more!`);
      }
      return false;
    }

    const updatedUser = {
      ...user,
      credits: {
        ...user.credits,
        dailyUsed: user.credits.dailyUsed + cost,
        monthlyUsed: user.credits.monthlyUsed + cost
      }
    };
    setUser(updatedUser);
    return true;
  };

  const updateUserKeys = (keys: Record<string, string>) => {
    if (!user) return;
    setUser({ ...user, apiKeys: { ...user.apiKeys, ...keys } });
  };

  const logout = () => {
    setUser(null);
  };

  return { 
    user, 
    setUser, 
    updateCredits, 
    updateUserKeys, 
    isLoading, 
    logout 
  };
};