
import React, { useState } from 'react';
import { ArrowLeft, Loader2, Calculator, Sigma, Delete, Eraser, Play } from 'lucide-react';
import { User, ModelType } from './types';
import { generateAIResponse } from './services/geminiService';
import MarkdownRenderer from './components/MarkdownRenderer';

const MathSolverApp = ({ user, updateCredits, onBack }: { user: User, updateCredits: any, onBack: () => void }) => {
    const [input, setInput] = useState("");
    const [solution, setSolution] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);

    const solve = async () => {
        if (!updateCredits(2)) return;
        setLoading(true);
        try {
            const res = await generateAIResponse({ modelName: ModelType.GEMINI_3_THINKING, prompt: input, systemInstruction: "Solve this math problem step by step. Use LaTeX formatting for math expressions. Be extremely precise." });
            setSolution(res.text);
        } catch(e) { alert("Error"); } finally { setLoading(false); }
    };

    return (
        <div className="h-full bg-[#f8f9fa] font-sans flex flex-col relative overflow-hidden" style={{backgroundImage: 'radial-gradient(#e5e7eb 1px, transparent 1px)', backgroundSize: '20px 20px'}}>
            <div className="absolute top-0 left-0 right-0 h-16 bg-white/80 backdrop-blur border-b border-gray-200 flex items-center justify-between px-6 z-10">
                 <div className="flex items-center gap-4">
                    <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-lg text-gray-500"><ArrowLeft size={20}/></button>
                    <h1 className="font-bold text-gray-800 flex items-center gap-2"><Sigma className="text-blue-600"/> MathSolver <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">Pro</span></h1>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto pt-24 pb-12 px-4">
                <div className="max-w-4xl mx-auto space-y-6">
                    {/* Input Area */}
                    <div className="bg-white rounded-2xl shadow-xl shadow-blue-900/5 border border-gray-100 p-2">
                        <textarea 
                            value={input} 
                            onChange={e => setInput(e.target.value)} 
                            placeholder="Enter problem (e.g. 'Integral of x^2 from 0 to 5')..." 
                            className="w-full p-6 text-2xl font-mono text-gray-800 outline-none resize-none placeholder:text-gray-300"
                            rows={3}
                        />
                        <div className="flex justify-between items-center px-4 pb-2">
                            <button onClick={() => setInput('')} className="text-gray-400 hover:text-red-500 p-2"><Eraser size={20}/></button>
                            <button 
                                onClick={solve}
                                disabled={!input.trim() || loading}
                                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-xl font-bold transition disabled:opacity-50 flex items-center gap-2 shadow-lg shadow-blue-500/30"
                            >
                                {loading ? <Loader2 className="animate-spin" size={20}/> : <Play size={20} fill="currentColor"/>}
                                Solve
                            </button>
                        </div>
                    </div>

                    {/* Solution Area */}
                    {solution && (
                        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden animate-in slide-in-from-bottom-4">
                            <div className="bg-gray-50 border-b border-gray-200 px-6 py-4 flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full bg-red-400"></div>
                                <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                                <div className="w-3 h-3 rounded-full bg-green-400"></div>
                                <span className="ml-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Step-by-Step Solution</span>
                            </div>
                            <div className="p-8 prose prose-lg max-w-none prose-blue font-serif">
                                <MarkdownRenderer content={solution}/>
                            </div>
                        </div>
                    )}
                    
                    {!solution && !loading && (
                        <div className="text-center py-12">
                            <p className="text-gray-400 text-sm">Powered by Gemini 3 Thinking Mode</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default MathSolverApp;
