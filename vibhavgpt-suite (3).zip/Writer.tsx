
import React, { useState } from 'react';
import { ArrowLeft, Loader2, PenTool, Feather, Type, AlignLeft, MoreHorizontal, Download, Copy, Check } from 'lucide-react';
import { User, ModelType } from './types';
import { generateAIResponse } from './services/geminiService';
import MarkdownRenderer from './components/MarkdownRenderer';

const WriterApp = ({ user, updateCredits, onBack }: { user: User, updateCredits: any, onBack: () => void }) => {
    const [topic, setTopic] = useState("");
    const [content, setContent] = useState("");
    const [loading, setLoading] = useState(false);
    const [copied, setCopied] = useState(false);

    const generate = async () => {
        if (!updateCredits(2)) return;
        setLoading(true);
        try {
            const res = await generateAIResponse({ modelName: ModelType.CLAUDE_4_6_OPUS, prompt: `Write a high-quality, long-form piece about: ${topic}. Use headers, clear structure, and elegant prose.`, systemInstruction: "You are an expert writer." });
            setContent(res.text);
        } catch(e) { alert("Error"); } finally { setLoading(false); }
    };

    const handleCopy = () => {
        navigator.clipboard.writeText(content);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="h-full bg-[#f3f3f3] font-sans flex flex-col relative">
            {/* Minimal Toolbar */}
            <div className="h-14 bg-white border-b border-gray-200 flex items-center justify-between px-4 sticky top-0 z-10">
                <div className="flex items-center gap-4">
                    <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded text-gray-500"><ArrowLeft size={18}/></button>
                    <div className="h-4 w-[1px] bg-gray-300"></div>
                    <span className="font-serif font-bold text-gray-700">ProWriter</span>
                    <span className="text-xs text-gray-400">Draft</span>
                </div>
                <div className="flex items-center gap-2">
                     <button className="p-2 hover:bg-gray-100 rounded text-gray-500"><Type size={18}/></button>
                     <button className="p-2 hover:bg-gray-100 rounded text-gray-500"><AlignLeft size={18}/></button>
                     <div className="h-4 w-[1px] bg-gray-300 mx-2"></div>
                     <button onClick={handleCopy} className="p-2 hover:bg-gray-100 rounded text-gray-500 hover:text-black">
                         {copied ? <Check size={18}/> : <Copy size={18}/>}
                     </button>
                     <button className="bg-black text-white px-4 py-1.5 rounded text-sm font-medium hover:bg-gray-800 transition">Export</button>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto p-8 flex justify-center">
                <div className="w-full max-w-[850px] bg-white min-h-[1100px] shadow-sm border border-gray-200 p-16 sm:p-24 relative">
                    {!content && !loading && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center p-10 bg-white z-10">
                            <Feather size={48} className="text-gray-200 mb-6"/>
                            <h2 className="text-2xl font-serif font-bold text-gray-800 mb-2">Start writing</h2>
                            <p className="text-gray-400 mb-8 text-center max-w-md">Enter a topic, headline, or rough idea. We'll handle the draft.</p>
                            
                            <div className="w-full max-w-lg relative">
                                <input 
                                    value={topic}
                                    onChange={e => setTopic(e.target.value)}
                                    placeholder="e.g., 'The Future of Renewable Energy'..."
                                    className="w-full p-4 pr-32 border-b-2 border-gray-100 outline-none text-xl font-serif focus:border-black transition placeholder:font-sans placeholder:text-gray-300"
                                    onKeyDown={e => e.key === 'Enter' && generate()}
                                />
                                <button 
                                    onClick={generate}
                                    disabled={!topic.trim()}
                                    className="absolute right-0 bottom-3 text-sm font-bold bg-black text-white px-4 py-2 rounded-full hover:bg-gray-800 disabled:opacity-0 transition-opacity"
                                >
                                    Write
                                </button>
                            </div>
                        </div>
                    )}

                    {loading && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/90 z-20 backdrop-blur-sm">
                            <Loader2 className="animate-spin text-gray-400 mb-4" size={32}/>
                            <p className="font-serif text-lg text-gray-500 animate-pulse">Drafting...</p>
                        </div>
                    )}

                    {content && (
                        <div className="prose prose-lg prose-slate max-w-none font-serif leading-loose">
                            <MarkdownRenderer content={content}/>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default WriterApp;
