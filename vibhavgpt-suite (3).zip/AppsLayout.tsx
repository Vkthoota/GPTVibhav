
import React, { useState } from 'react';
import { ArrowLeft, Search } from 'lucide-react';
import { User } from './types';
import { APPS } from './constants';
import CodeCloudApp from './CodeCloud';
import StudioApp from './Studio';
import StudyApp from './Study';
import ChefApp from './Chef';
import VideoGenApp from './VideoGen';
import ImageGenApp from './ImageGen';
import WriterApp from './Writer';
import MathSolverApp from './MathSolver';

const AppsLayout = ({ user, setUser, updateCredits, onBack }: { user: User, setUser: any, updateCredits: any, onBack?: () => void }) => {
    const [currentApp, setCurrentApp] = useState<string | null>(null);
    const [search, setSearch] = useState("");

    const filteredApps = APPS.filter(a => a.name.toLowerCase().includes(search.toLowerCase()) || a.description.toLowerCase().includes(search.toLowerCase()));

    if (currentApp === 'codecloud') return <CodeCloudApp user={user} setUser={setUser} updateCredits={updateCredits} onBack={() => setCurrentApp(null)} />;
    if (currentApp === 'studio') return <StudioApp user={user} setUser={setUser} updateCredits={updateCredits} onBack={() => setCurrentApp(null)} />;
    if (currentApp === 'study') return <StudyApp user={user} setUser={setUser} updateCredits={updateCredits} onBack={() => setCurrentApp(null)} />;
    if (currentApp === 'chef') return <ChefApp user={user} setUser={setUser} updateCredits={updateCredits} onBack={() => setCurrentApp(null)} />;
    if (currentApp === 'videostudio') return <VideoGenApp user={user} updateCredits={updateCredits} onBack={() => setCurrentApp(null)} />;
    if (currentApp === 'imagine') return <ImageGenApp user={user} updateCredits={updateCredits} onBack={() => setCurrentApp(null)} />;
    if (currentApp === 'writer') return <WriterApp user={user} updateCredits={updateCredits} onBack={() => setCurrentApp(null)} />;
    if (currentApp === 'math') return <MathSolverApp user={user} updateCredits={updateCredits} onBack={() => setCurrentApp(null)} />;

    return (
        <div className="h-full bg-white p-8 overflow-y-auto font-sans">
            <div className="max-w-7xl mx-auto">
                <div className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
                    <div>
                        <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-red-600 mb-2 tracking-tight">Applications</h1>
                        <p className="text-gray-500">Specialized AI suites for every creative and technical task.</p>
                    </div>
                    <div className="relative w-full md:w-96">
                        <Search className="absolute left-3 top-3 text-gray-400" size={20}/>
                        <input 
                            value={search} 
                            onChange={e => setSearch(e.target.value)} 
                            placeholder="Search apps..." 
                            className="w-full pl-10 pr-4 py-3 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-blue-100 transition"
                        />
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredApps.map((app, idx) => (
                        <div 
                            key={app.id} 
                            onClick={() => setCurrentApp(app.id)} 
                            className="group cursor-pointer bg-white border border-gray-100 rounded-3xl p-6 hover:shadow-2xl hover:shadow-blue-900/5 transition-all duration-300 hover:-translate-y-1 relative overflow-hidden"
                        >
                            <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-50 to-red-50 rounded-full blur-2xl -mr-16 -mt-16 transition opacity-0 group-hover:opacity-100`}></div>
                            
                            <div className="h-16 w-16 bg-gray-50 rounded-2xl mb-6 flex items-center justify-center border border-gray-100 group-hover:bg-white group-hover:scale-110 transition shadow-sm z-10 relative text-blue-600 font-bold text-2xl">
                                {app.name.charAt(0)}
                            </div>
                            
                            <div className="relative z-10">
                                <h3 className="font-bold text-xl text-gray-900 mb-2 group-hover:text-blue-600 transition">{app.name}</h3>
                                <p className="text-gray-500 text-sm leading-relaxed">{app.description}</p>
                            </div>

                            <div className="absolute bottom-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity -translate-x-2 group-hover:translate-x-0 text-blue-600">
                                <ArrowLeft className="rotate-180" size={20}/>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

export default AppsLayout;
