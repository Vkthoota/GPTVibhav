
import React, { useState } from 'react';
import { ArrowLeft, Loader2, Code2, Play, Terminal, Folder, FileCode, Plus, Save, ChevronRight, ChevronDown, Command, Github, CloudUpload, Link } from 'lucide-react';
import { User, CodeProject, Message, ModelType } from './types';
import { generateAIResponse } from './services/geminiService';
import MarkdownRenderer from './components/MarkdownRenderer';

const CodeCloudApp = ({ user, setUser, updateCredits, onBack }: { user: User, setUser: any, updateCredits: any, onBack: () => void }) => {
    const [view, setView] = useState<'home' | 'project'>('home');
    const [activeProject, setActiveProject] = useState<CodeProject | null>(null);
    const [chatInput, setChatInput] = useState("");
    const [chatLoading, setChatLoading] = useState(false);
    const [showTerminal, setShowTerminal] = useState(true);
    const [isSyncing, setIsSyncing] = useState(false);

    const createProject = () => {
        const newProj: CodeProject = {
            id: Date.now().toString(), name: "Untitled Project", language: "javascript", code: "// Welcome to CodeCloud\nconsole.log('Hello World');", chatHistory: [], isPublic: false, author: user.username, lastUpdated: Date.now()
        };
        setUser({ ...user, codeProjects: [newProj, ...user.codeProjects] });
        setActiveProject(newProj);
        setView('project');
    };

    const connectGithub = () => {
        setIsSyncing(true);
        // Simulated OAuth Delay
        setTimeout(() => {
            setUser({
                ...user,
                githubAccount: {
                    username: user.username.toLowerCase().replace(/\s/g, '-'),
                    linkedAt: Date.now()
                }
            });
            setIsSyncing(false);
        }, 1500);
    };

    const syncToGithub = () => {
        if (!activeProject) return;
        setIsSyncing(true);
        setTimeout(() => {
            const updated = { ...activeProject, lastSynced: Date.now(), githubRepo: `${user.githubAccount?.username}/${activeProject.name.toLowerCase().replace(/\s/g, '-')}` };
            const list = user.codeProjects.map(p => p.id === activeProject.id ? updated : p);
            setUser({ ...user, codeProjects: list });
            setActiveProject(updated);
            setIsSyncing(false);
            alert("Code pushed to GitHub successfully!");
        }, 2000);
    };

    const handleChat = async () => {
        if (!chatInput.trim() || !activeProject) return;
        if (!updateCredits(1.5)) return;
        setChatLoading(true);
        const newMsg: Message = { id: Date.now().toString(), role: 'user', content: chatInput, timestamp: Date.now() };
        const updatedChat = [...activeProject.chatHistory, newMsg];
        setActiveProject({ ...activeProject, chatHistory: updatedChat });
        setChatInput("");
        try {
            const prompt = `Current Code:\n\`\`\`${activeProject.language}\n${activeProject.code}\n\`\`\`\nRequest: ${newMsg.content}\n\nReturn ONLY the updated code block.`;
            const res = await generateAIResponse({ modelName: ModelType.PLUS, prompt });
            const codeMatch = res.text.match(/```(?:\w+)?\n([\s\S]*?)```/);
            const newCode = codeMatch ? codeMatch[1] : activeProject.code;
            const aiMsg: Message = { id: Date.now().toString(), role: 'model', content: res.text, timestamp: Date.now() };
            const final: CodeProject = { ...activeProject, chatHistory: [...updatedChat, aiMsg], code: newCode, lastUpdated: Date.now() };
            
            const list = user.codeProjects.map(p => p.id === activeProject.id ? final : p);
            setUser({ ...user, codeProjects: list });
            setActiveProject(final);
        } catch(e) { alert("Error generating code."); } finally { setChatLoading(false); }
    };

    if (view === 'home') {
        return (
            <div className="h-full bg-[#0d1117] text-gray-300 font-mono p-8 overflow-y-auto">
                <div className="max-w-6xl mx-auto">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-4">
                        <div className="flex items-center gap-4">
                            <button onClick={onBack} className="text-gray-500 hover:text-white transition"><ArrowLeft/></button>
                            <h1 className="text-2xl font-bold text-white flex items-center gap-2"><Terminal className="text-green-500"/> ~/CodeCloud</h1>
                        </div>
                        <div className="flex items-center gap-3">
                            {user.githubAccount ? (
                                <div className="flex items-center gap-2 bg-[#161b22] px-4 py-2 rounded-md border border-gray-700 text-xs font-bold text-gray-400">
                                    <Github size={14} className="text-white"/> {user.githubAccount.username}
                                </div>
                            ) : (
                                <button onClick={connectGithub} disabled={isSyncing} className="bg-white text-black px-4 py-2 rounded-md text-sm font-bold hover:bg-gray-200 transition flex items-center gap-2">
                                    {isSyncing ? <Loader2 size={16} className="animate-spin"/> : <Github size={16}/>} Connect GitHub
                                </button>
                            )}
                            <button onClick={createProject} className="bg-green-600 text-white px-4 py-2 rounded-md text-sm font-bold hover:bg-green-700 transition flex items-center gap-2">
                                <Plus size={16}/> New Project
                            </button>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        {user.codeProjects.map(p => (
                            <div key={p.id} onClick={() => { setActiveProject(p); setView('project'); }} className="group border border-gray-800 bg-[#161b22] p-4 rounded-lg cursor-pointer hover:border-gray-600 transition relative">
                                <div className="flex items-center gap-3 mb-3">
                                    <div className="w-10 h-10 bg-blue-500/10 text-blue-400 rounded flex items-center justify-center"><FileCode size={20}/></div>
                                    <div className="overflow-hidden">
                                        <h3 className="font-bold text-sm text-gray-200 truncate">{p.name}</h3>
                                        <p className="text-xs text-gray-500">{new Date(p.lastUpdated).toLocaleDateString()}</p>
                                    </div>
                                </div>
                                <div className="flex justify-between items-center">
                                    <div className="text-[10px] text-gray-500 font-mono bg-black/20 p-1 rounded truncate">{p.language}</div>
                                    {p.lastSynced && <div className="text-[10px] text-green-500 flex items-center gap-1 font-bold uppercase"><CloudUpload size={10}/> Synced</div>}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="h-full flex flex-col bg-[#1e1e1e] text-gray-300 font-mono text-sm">
            {/* IDE Header */}
            <div className="h-10 bg-[#2d2d2d] flex items-center justify-between px-4 border-b border-[#111]">
                <div className="flex items-center gap-4">
                     <button onClick={() => setView('home')} className="hover:text-white"><ArrowLeft size={14}/></button>
                     <span className="font-bold text-gray-400 text-xs flex items-center gap-2">
                        {activeProject?.name}
                        {activeProject?.githubRepo && <span className="text-[10px] bg-green-900/40 text-green-400 px-2 py-0.5 rounded-full border border-green-500/20">{activeProject.githubRepo}</span>}
                     </span>
                </div>
                <div className="flex items-center gap-2">
                     {user.githubAccount && (
                         <button 
                            onClick={syncToGithub} 
                            disabled={isSyncing}
                            className="p-1.5 hover:bg-white/10 rounded text-gray-400 hover:text-white transition flex items-center gap-2" 
                            title="Push to GitHub"
                         >
                            {isSyncing ? <Loader2 size={14} className="animate-spin"/> : <CloudUpload size={14}/>}
                            <span className="text-[10px] font-bold uppercase hidden sm:inline">{isSyncing ? 'Pushing...' : 'Push'}</span>
                         </button>
                     )}
                     <button onClick={() => alert("Saved!")} className="p-1.5 hover:bg-white/10 rounded"><Save size={14}/></button>
                     <button className="bg-green-600 text-white px-3 py-1 rounded-sm text-xs font-bold flex items-center gap-1"><Play size={10}/> Run</button>
                </div>
            </div>

            <div className="flex-1 flex overflow-hidden">
                {/* Sidebar Explorer */}
                <div className="w-64 bg-[#252526] border-r border-[#111] flex flex-col">
                    <div className="p-2 text-xs font-bold uppercase tracking-wider text-gray-500 pl-4">Explorer</div>
                    <div className="px-2">
                        <div className="flex items-center gap-1 text-gray-200 hover:bg-[#2a2d2e] p-1 cursor-pointer">
                            <ChevronDown size={14}/> 
                            <Folder size={14} className="text-blue-400"/>
                            <span>src</span>
                        </div>
                        <div className="flex items-center gap-1 text-gray-200 hover:bg-[#2a2d2e] p-1 pl-6 cursor-pointer bg-[#37373d]">
                            <FileCode size={14} className="text-yellow-400"/>
                            <span>index.{activeProject?.language === 'python' ? 'py' : 'js'}</span>
                        </div>
                    </div>
                </div>

                {/* Main Code Area */}
                <div className="flex-1 flex flex-col relative">
                    <textarea 
                        value={activeProject?.code} 
                        onChange={e => setActiveProject({...activeProject!, code: e.target.value})} 
                        className="flex-1 w-full bg-[#1e1e1e] text-[#d4d4d4] p-4 outline-none resize-none leading-relaxed"
                        spellCheck={false}
                    />
                    
                    {/* Bottom Terminal / Chat */}
                    {showTerminal && (
                        <div className="h-1/3 bg-[#1e1e1e] border-t border-[#414141] flex flex-col">
                            <div className="flex border-b border-[#2d2d2d] text-xs">
                                <button className="px-4 py-2 border-t-2 border-blue-500 bg-[#1e1e1e] text-white">AI Assistant</button>
                                <button className="px-4 py-2 text-gray-500 hover:text-gray-300">Terminal</button>
                                <button className="ml-auto px-4 text-gray-500 hover:text-white" onClick={() => setShowTerminal(false)}><ChevronDown size={14}/></button>
                            </div>
                            <div className="flex-1 flex flex-col overflow-hidden">
                                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                                    {activeProject?.chatHistory.map((msg, i) => (
                                        <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                                            <div className={`p-3 rounded-lg max-w-[80%] text-xs ${msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-[#2d2d2d] text-gray-300'}`}>
                                                <MarkdownRenderer content={msg.content}/>
                                            </div>
                                        </div>
                                    ))}
                                    {chatLoading && <Loader2 className="animate-spin text-blue-500" size={16}/>}
                                </div>
                                <div className="p-3 border-t border-[#2d2d2d] bg-[#252526] flex gap-2">
                                    <div className="flex-1 bg-[#3c3c3c] rounded-sm flex items-center px-2">
                                        <Command size={12} className="text-gray-400 mr-2"/>
                                        <input 
                                            value={chatInput}
                                            onChange={e => setChatInput(e.target.value)}
                                            onKeyDown={e => e.key === 'Enter' && handleChat()}
                                            placeholder="Ask Copilot to refactor or fix bugs..." 
                                            className="bg-transparent border-none outline-none text-white text-xs w-full py-2"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            
            {/* Status Bar */}
            <div className="h-6 bg-[#007acc] text-white flex items-center px-4 text-xs justify-between">
                <div className="flex gap-4">
                    <span>main*</span>
                    <span>0 errors</span>
                </div>
                <div className="flex gap-4">
                    <span>Ln 12, Col 4</span>
                    <span>UTF-8</span>
                    <span>{activeProject?.language.toUpperCase()}</span>
                </div>
            </div>
        </div>
    );
};

export default CodeCloudApp;
