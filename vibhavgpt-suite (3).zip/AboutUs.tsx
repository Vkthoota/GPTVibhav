
import React from 'react';
import { ArrowLeft, Sparkles, Shield, Zap, Globe, Heart } from 'lucide-react';

const AboutUs = ({ onBack }: { onBack: () => void }) => {
    return (
        <div className="min-h-screen bg-[#f0f4f9] text-[#1f1f1f] font-sans overflow-y-auto">
            {/* Header */}
            <div className="bg-white border-b border-gray-200 sticky top-0 z-20 px-6 py-4 flex items-center gap-4">
                <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition">
                    <ArrowLeft size={20} />
                </button>
                <div className="font-bold text-xl flex items-center gap-2">
                    VibhavGPT <span className="text-blue-500">Suite</span>
                </div>
            </div>

            <main className="max-w-4xl mx-auto px-6 py-12">
                <div className="text-center mb-16 animate-in fade-in slide-in-from-bottom-4 duration-700">
                    <h1 className="text-5xl font-extrabold tracking-tight mb-6">Empowering the Future of Intelligence</h1>
                    <p className="text-xl text-gray-500 max-w-2xl mx-auto">
                        VibhavGPT Suite is the culmination of next-generation AI models, designed to provide a unified, limitless workspace for creators, developers, and thinkers in 2026.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
                    <div className="bg-white p-8 rounded-[24px] border border-gray-100 shadow-sm">
                        <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 mb-6">
                            <Sparkles size={24} />
                        </div>
                        <h3 className="text-xl font-bold mb-3">Universal Model Access</h3>
                        <p className="text-gray-500 leading-relaxed">
                            We believe in freedom of choice. That's why we've integrated the world's most powerful engines—Gemini 3, GPT-5, Claude 4.6, and our proprietary VibhavGPT Max—into a single, cohesive interface.
                        </p>
                    </div>
                    <div className="bg-white p-8 rounded-[24px] border border-gray-100 shadow-sm">
                        <div className="w-12 h-12 bg-purple-50 rounded-2xl flex items-center justify-center text-purple-600 mb-6">
                            <Zap size={24} />
                        </div>
                        <h3 className="text-xl font-bold mb-3">Real-Time Fusion</h3>
                        <p className="text-gray-500 leading-relaxed">
                            Our proprietary "Fusion Engine" technology allows multiple AI agents to collaborate on a single query, cross-referencing logic, creativity, and factual data to produce superior results.
                        </p>
                    </div>
                    <div className="bg-white p-8 rounded-[24px] border border-gray-100 shadow-sm">
                        <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center text-green-600 mb-6">
                            <Shield size={24} />
                        </div>
                        <h3 className="text-xl font-bold mb-3">Privacy First</h3>
                        <p className="text-gray-500 leading-relaxed">
                            Your data remains yours. We employ advanced encryption and optional local-processing modes (Nano Banana) to ensure sensitive information never leaves your control without permission.
                        </p>
                    </div>
                    <div className="bg-white p-8 rounded-[24px] border border-gray-100 shadow-sm">
                        <div className="w-12 h-12 bg-orange-50 rounded-2xl flex items-center justify-center text-orange-600 mb-6">
                            <Globe size={24} />
                        </div>
                        <h3 className="text-xl font-bold mb-3">Global Connectivity</h3>
                        <p className="text-gray-500 leading-relaxed">
                            With integrated real-time web search (Atlas) and deep integration with global knowledge bases, VibhavGPT Suite keeps you connected to the pulse of the world, instant by instant.
                        </p>
                    </div>
                </div>

                <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-[32px] p-12 text-center text-white mb-16">
                    <Heart className="mx-auto mb-6 opacity-80" size={48}/>
                    <h2 className="text-3xl font-bold mb-4">Built with passion.</h2>
                    <p className="text-blue-100 max-w-xl mx-auto text-lg">
                        Designed for the dreamers of 2026.
                    </p>
                </div>

                <div className="text-center border-t border-gray-200 pt-12">
                    <p className="text-gray-400 font-medium">© 2026 VibhavGPT Suite. All rights reserved.</p>
                </div>
            </main>
        </div>
    );
};

export default AboutUs;
