import React from 'react';
import { ArrowLeft, CheckCircle2, XCircle, Zap, Brain, Sparkles, Cpu, Target } from 'lucide-react';
import { MODEL_COMPARISON_DATA } from './constants';

const CompareModels: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  return (
    <div className="h-full bg-white flex flex-col overflow-y-auto">
      <div className="sticky top-0 bg-white/90 backdrop-blur-sm z-20 px-8 py-6 border-b border-gray-100 flex items-center gap-4">
        <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition">
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-2xl font-bold text-gray-900">Intelligence <span className="text-blue-600">Comparison</span></h1>
      </div>

      <div className="max-w-6xl mx-auto px-8 py-12 w-full">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-extrabold text-gray-900 mb-4">Choose the right <span className="text-blue-600">mind</span> for the job.</h2>
          <p className="text-gray-500 text-lg max-w-2xl mx-auto">
            Not all neural engines are built equal. Compare the strengths and weaknesses of our suite of frontier models.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 mb-20">
          {MODEL_COMPARISON_DATA.map((model, idx) => (
            <div key={idx} className="bg-gray-50 rounded-[40px] p-8 border border-gray-100 flex flex-col md:flex-row gap-8 hover:shadow-xl transition-shadow duration-500 group">
              <div className="md:w-1/4">
                <div className="flex items-center gap-2 mb-2">
                   {model.provider === 'VibhavGPT' ? <Sparkles size={16} className="text-blue-600" /> : <Cpu size={16} className="text-gray-400" />}
                   <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">{model.provider}</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 group-hover:text-blue-600 transition">{model.name}</h3>
              </div>

              <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white rounded-2xl p-6 shadow-sm">
                  <div className="flex items-center gap-2 text-green-600 font-bold text-sm mb-3 uppercase tracking-tighter">
                     <CheckCircle2 size={16}/> Strengths
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed">{model.strengths}</p>
                </div>

                <div className="bg-white rounded-2xl p-6 shadow-sm">
                  <div className="flex items-center gap-2 text-red-500 font-bold text-sm mb-3 uppercase tracking-tighter">
                     <XCircle size={16}/> Weaknesses
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed">{model.weaknesses}</p>
                </div>

                <div className="bg-blue-600 text-white rounded-2xl p-6 shadow-lg transform group-hover:scale-[1.02] transition">
                  <div className="flex items-center gap-2 font-bold text-sm mb-3 uppercase tracking-tighter">
                     <Target size={16}/> Best For
                  </div>
                  <p className="text-blue-50 text-sm leading-relaxed">{model.bestFor}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
           <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600 mx-auto mb-4"><Zap size={24}/></div>
              <h4 className="font-bold text-lg mb-2">Speed Optimized</h4>
              <p className="text-gray-500 text-sm">Low-latency responses for real-time workflows.</p>
           </div>
           <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center text-purple-600 mx-auto mb-4"><Brain size={24}/></div>
              <h4 className="font-bold text-lg mb-2">Reasoning Depth</h4>
              <p className="text-gray-500 text-sm">Advanced logic gates for complex problem solving.</p>
           </div>
           <div className="text-center">
              <div className="w-12 h-12 bg-indigo-100 rounded-2xl flex items-center justify-center text-indigo-600 mx-auto mb-4"><Sparkles size={24}/></div>
              <h4 className="font-bold text-lg mb-2">Creativity Fusion</h4>
              <p className="text-gray-500 text-sm">Unmatched expressive ability for creative endeavors.</p>
           </div>
        </div>
      </div>

      <footer className="py-12 border-t border-gray-100 text-center text-gray-400 text-xs">
         Performance data updated weekly based on neural benchmarks from VibhavGPT Inc. Laboratory.
      </footer>
    </div>
  );
};

export default CompareModels;