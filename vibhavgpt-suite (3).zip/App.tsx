
import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageCircle, Menu, Plus, 
  Send, X, Settings, Check,
  Trash2, Globe, Sparkles, 
  Image as ImageIcon, FileText, Youtube, ChevronDown, 
  Home, Sliders, ShieldAlert, Calculator, Smile, QrCode, GraduationCap, 
  Calendar, CheckCircle, Languages, Copy, Video, Info, CreditCard, Mic, BarChart3, Loader2, ArrowRight, Swords, Brain, Zap, LogOut, LayoutGrid, AlertCircle, RotateCcw, MapPin, Compass, Search, Code, Wrench, Lightbulb, Plane, Music, Feather, BookOpen, Edit3, Briefcase, PenTool, Edit2, PanelLeft, CloudLightning, Terminal
} from 'lucide-react';
import { ModelType, Message, ChatSession, Attachment, Tier, ResponseStyle } from './types';
import { MODEL_COSTS, MODEL_PROVIDER_MAP, MODEL_INFO, TIER_LIMITS, ACCESS_KEY, UNLIMITED_KEY, MODEL_MAPPING, PROVIDERS, MODEL_GROUPS } from './constants';
import { generateAIResponse } from './services/geminiService';
import MarkdownRenderer from './components/MarkdownRenderer';
import { useUser } from './hooks';
import { SettingsModal, PaymentModal, AccessKeyModal, YouTubeSearchModal, CustomProfileModal } from './Modals';
import LandingPage from './LandingPage';
import AIArena from './AIArena';
import AppsLayout from './AppsLayout';
import ToolsLayout from './ToolsLayout';
import AboutUs from './AboutUs';
import PricingPage from './PricingPage';
import GeminiLive from './GeminiLive';
import CompareModels from './CompareModels';
import OnboardingTour from './components/OnboardingTour';
import VideoGenApp from './VideoGen';
import ImageGenApp from './ImageGen';

const INSTANT_MODELS = [
    ModelType.BOLT, 
    ModelType.GPT_5_2_INSTANT, 
    ModelType.GEMINI_3_FAST, 
    ModelType.GEMINI_2_5_FLASH_LITE,
    ModelType.GROK_4_1_FAST,
    ModelType.CLAUDE_4_5_HAIKU,
    ModelType.CLAUDE_HAIKU_3_5,
    ModelType.KIMI_K2_5_INSTANT,
    ModelType.GEMINI_1_5_FLASH
];

const FLAGSHIP_MODELS = [
    ModelType.MAX,
    ModelType.ULTRA,
    ModelType.GPT_5_2_PRO,
    ModelType.CLAUDE_4_6_OPUS,
    ModelType.CLAUDE_OPUS_3,
    ModelType.GEMINI_3_PRO,
    ModelType.GPT_4O,
    ModelType.GROK_4,
    ModelType.CLAUDE_SONNET_4
];

const SUGGESTIONS = [
    { label: "Debug Code", icon: <Terminal size={16} className="text-red-500"/>, prompt: "Debug this code snippet:" },
    { label: "Plan a Trip", icon: <Plane size={16} className="text-blue-500"/>, prompt: "Plan a 3-day itinerary for..." },
    { label: "Brainstorm", icon: <Lightbulb size={16} className="text-yellow-500"/>, prompt: "Brainstorm 5 creative ideas for..." },
    { label: "Write Lyrics", icon: <Music size={16} className="text-purple-500"/>, prompt: "Write lyrics for a song about..." },
];

const App: React.FC = () => {
  const { user, setUser, updateCredits, updateUserKeys, isLoading, logout } = useUser();
  // Default to chat, no home tab
  const [currentTab, setCurrentTab] = useState<'chat' | 'tools' | 'apps' | 'arena' | 'compare' | 'about' | 'pricing' | 'video' | 'image'>('chat');
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth >= 1024); // Hidden on smaller screens initially
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [isAccessKeyOpen, setIsAccessKeyOpen] = useState(false);
  const [isLiveOpen, setIsLiveOpen] = useState(false);
  const [youtubeModalOpen, setYoutubeModalOpen] = useState(false);
  const [customProfileOpen, setCustomProfileOpen] = useState(false);
  
  const [selectedModel, setSelectedModel] = useState<ModelType>(ModelType.BOLT); // Default to Bolt as per screenshot
  const [responseStyle, setResponseStyle] = useState<ResponseStyle>(ResponseStyle.DETAILED);
  const [customInstruction, setCustomInstruction] = useState("");
  
  const [isModelSelectorOpen, setIsModelSelectorOpen] = useState(false);

  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStatus, setGenerationStatus] = useState("");
  const [webSearch, setWebSearch] = useState(true);
  const [mapsSearch, setMapsSearch] = useState(false);

  // Renaming State
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");

  const chatEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Define createNewSession BEFORE useEffect to avoid ReferenceError
  const createNewSession = () => {
    // If the active session is already empty and we are on chat tab, just stay there/reset UI
    const activeSession = sessions.find(s => s.id === activeSessionId);
    if (currentTab === 'chat' && activeSession && activeSession.messages.length === 0) {
         if (window.innerWidth < 1024) setIsSidebarOpen(false);
         setInput("");
         setAttachments([]);
         return;
    }

    const newSession: ChatSession = {
      id: Date.now().toString(),
      title: "New Chat",
      model: selectedModel,
      messages: [],
      sharedWith: [],
      lastUpdated: Date.now()
    };
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
    setCurrentTab('chat');
    setInput("");
    setAttachments([]);
    if (window.innerWidth < 1024) setIsSidebarOpen(false);
  };

  // Auto-switch profile and settings based on model tier
  useEffect(() => {
      if (INSTANT_MODELS.includes(selectedModel)) {
          setResponseStyle(ResponseStyle.CONCISE);
          setWebSearch(false);
      } else if (FLAGSHIP_MODELS.includes(selectedModel)) {
          setResponseStyle(ResponseStyle.DETAILED);
          setWebSearch(true); // Research Mode enabled for Flagship
      } else {
          // Mid-tier models (Thinking)
          setResponseStyle(ResponseStyle.THINKING);
          setWebSearch(false);
      }
  }, [selectedModel]);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsSidebarOpen(true);
      } else {
        setIsSidebarOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem('vibhav_sessions_v4');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSessions(parsed);
        if (parsed.length > 0 && !activeSessionId) setActiveSessionId(parsed[0].id);
        else if (parsed.length === 0) createNewSession();
      } catch (e) { console.error("Failed to load sessions", e); }
    } else {
        createNewSession();
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('vibhav_sessions_v4', JSON.stringify(sessions));
  }, [sessions]);

  const scrollToBottom = (instant = false) => {
    if (chatEndRef.current) {
        chatEndRef.current.scrollIntoView({ behavior: instant ? 'auto' : 'smooth' });
    }
  };

  useEffect(() => {
    scrollToBottom(true);
  }, [activeSessionId, currentTab]);

  useEffect(() => {
    if (isGenerating) scrollToBottom();
  }, [sessions, isGenerating]);

  useEffect(() => {
    if (user?.theme) {
      document.body.setAttribute('data-theme', user.theme);
    }
    if (user?.customProfile) {
        setCustomInstruction(user.customProfile);
    }
  }, [user?.theme, user?.customProfile]);

  if (isLoading) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-gray-50 text-gray-900">
         <div className="text-2xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-red-600">VibhavGPT Suite</div>
      </div>
    );
  }

  if (!user || !user.isAuthenticated) {
    return (
      <>
        <LandingPage onAccessRequest={() => setIsAccessKeyOpen(true)} onLogin={(u) => setUser(u)} />
        {isAccessKeyOpen && (
          <AccessKeyModal 
            onClose={() => setIsAccessKeyOpen(false)} 
            onSuccess={(u) => {
              setUser(u);
              setIsAccessKeyOpen(false);
            }} 
          />
        )}
      </>
    );
  }

  const activeSession = sessions.find(s => s.id === activeSessionId);

  const deleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newSessions = sessions.filter(s => s.id !== id);
    setSessions(newSessions);
    if (activeSessionId === id) {
      setActiveSessionId(newSessions.length > 0 ? newSessions[0].id : null);
    }
  };

  // Renaming Logic
  const startRenaming = (e: React.MouseEvent, session: ChatSession) => {
      e.stopPropagation();
      setEditingSessionId(session.id);
      setEditTitle(session.title);
  };

  const saveRename = (id: string) => {
      if (!editTitle.trim()) return;
      setSessions(prev => prev.map(s => s.id === id ? { ...s, title: editTitle } : s));
      setEditingSessionId(null);
  };

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = customPrompt || input;
    if ((!textToSend.trim() && attachments.length === 0) || isGenerating) return;
    
    const cost = MODEL_COSTS[selectedModel] || 0;
    if (!updateCredits(cost)) return;

    let targetSessionId = activeSessionId;
    let currentSessions = [...sessions];

    if (!targetSessionId || currentTab !== 'chat') {
      const newSession: ChatSession = {
        id: Date.now().toString(),
        title: textToSend.slice(0, 30) || "New Conversation",
        model: selectedModel,
        messages: [],
        sharedWith: [],
        lastUpdated: Date.now()
      };
      currentSessions = [newSession, ...currentSessions];
      targetSessionId = newSession.id;
      setSessions(currentSessions);
      setActiveSessionId(targetSessionId);
      setCurrentTab('chat');
    }

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: textToSend,
      timestamp: Date.now(),
      attachments: attachments.length > 0 ? [...attachments] : undefined
    };

    const updatedSessions = currentSessions.map(s => {
      if (s.id === targetSessionId) {
        return { 
          ...s, 
          messages: [...s.messages, userMsg], 
          lastUpdated: Date.now(),
          title: s.messages.length === 0 ? (textToSend.slice(0, 30) || "New Conversation") : s.title
        };
      }
      return s;
    });

    setSessions(updatedSessions);
    setInput("");
    setAttachments([]);
    setIsGenerating(true);
    setGenerationStatus("Thinking...");
    
    setTimeout(() => scrollToBottom(), 50);

    try {
      let provider = MODEL_PROVIDER_MAP[selectedModel];
      if (!provider) {
          // Fallback logic for unmapped models
          if (selectedModel.toLowerCase().includes('gpt')) provider = 'openai';
          else if (selectedModel.toLowerCase().includes('claude') || selectedModel.includes('Sonnet') || selectedModel.includes('Opus') || selectedModel.includes('Haiku')) provider = 'anthropic';
          else if (selectedModel.toLowerCase().includes('gemini')) provider = 'google';
          else provider = 'vibhav';
      }

      const apiKey = user.apiKeys[provider] || (provider === 'vibhav' || provider === 'google' ? "SYSTEM_ACCESS_GRANTED" : "");
      
      const response = await generateAIResponse({
        modelName: selectedModel,
        prompt: userMsg.content,
        history: updatedSessions.find(s => s.id === targetSessionId)?.messages,
        attachments: userMsg.attachments,
        provider: provider,
        apiKey: apiKey,
        webSearch: webSearch || selectedModel === ModelType.ATLAS,
        maps: mapsSearch,
        systemInstruction: "You are a helpful AI assistant.",
        responseStyle: responseStyle, // Use the state variable here
        customSysInstruction: customInstruction
      }, (status) => setGenerationStatus(status));

      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        content: response.text,
        timestamp: Date.now(),
        sources: response.sources
      };

      setSessions(prev => prev.map(s => {
        if (s.id === targetSessionId) {
          return { ...s, messages: [...s.messages, aiMsg], lastUpdated: Date.now() };
        }
        return s;
      }));

    } catch (error: any) {
      const errMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        content: `**Error:** ${error.message}`,
        timestamp: Date.now()
      };
      setSessions(prev => prev.map(s => {
        if (s.id === targetSessionId) {
          return { ...s, messages: [...s.messages, errMsg], lastUpdated: Date.now() };
        }
        return s;
      }));
    } finally {
      setIsGenerating(false);
      setGenerationStatus("");
      setTimeout(() => scrollToBottom(), 100);
    }
  };

  const getGreeting = () => {
      const hour = new Date().getHours();
      if (hour < 12) return "Good Morning";
      if (hour < 18) return "Good Afternoon";
      return "Good Evening";
  };

  const renderContent = () => {
    switch (currentTab) {
      case 'chat':
        return (
          <div className="flex flex-col h-full bg-white relative">
             {activeSession ? (
                <>
                  <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 scroll-smooth" ref={chatContainerRef}>
                      {activeSession.messages.length === 0 && (
                          <div className="flex flex-col items-center justify-center h-full text-center px-4 animate-in fade-in slide-in-from-bottom-8 duration-700">
                              <h1 className="text-4xl font-normal text-gray-800 mb-2 tracking-tight">
                                  {getGreeting()}, <span className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-red-600">{user.username}</span>
                              </h1>
                              <p className="text-xl text-gray-400 font-light mb-12">How can I help you today?</p>
                              
                              <div className="flex flex-wrap justify-center gap-3 max-w-3xl">
                                  {SUGGESTIONS.map((s, i) => (
                                      <button 
                                        key={i} 
                                        onClick={() => setInput(s.prompt)}
                                        className="flex items-center gap-2 px-5 py-3 rounded-full bg-gray-50 hover:bg-blue-50 border border-gray-200 text-gray-600 text-sm font-medium transition hover:-translate-y-0.5 hover:shadow-sm group"
                                      >
                                          <span className="text-gray-400 group-hover:scale-110 transition">{s.icon}</span> {s.label}
                                      </button>
                                  ))}
                              </div>
                          </div>
                      )}
                      
                      {activeSession.messages.map((msg) => (
                          <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''} animate-in fade-in slide-in-from-bottom-2 duration-300`}>
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${msg.role === 'user' ? 'bg-black text-white' : 'bg-gradient-to-r from-blue-600 to-red-600 text-white'}`}>
                                  {msg.role === 'user' ? (user.username ? user.username[0] : 'U') : <Sparkles size={16}/>}
                              </div>
                              <div className={`max-w-[85%] md:max-w-[75%] space-y-2`}>
                                  <div className={`p-4 rounded-2xl shadow-sm ${msg.role === 'user' ? 'bg-gray-100 text-gray-900 rounded-tr-none' : 'bg-white border border-gray-100 rounded-tl-none'}`}>
                                      {msg.attachments && msg.attachments.length > 0 && (
                                          <div className="flex gap-2 mb-3 flex-wrap">
                                              {msg.attachments.map(att => (
                                                  <div key={att.id} className="relative group overflow-hidden rounded-lg border border-gray-200 bg-gray-50">
                                                      {att.type === 'image' && <img src={`data:${att.mimeType};base64,${att.content}`} className="h-32 object-cover" alt="attachment"/>}
                                                      {att.type === 'youtube' && (
                                                          <div className="flex items-center gap-2 p-2 text-red-600 text-xs font-bold">
                                                              <Youtube size={16}/> Video
                                                          </div>
                                                      )}
                                                      {att.type === 'file' && (
                                                          <div className="flex items-center gap-2 p-2 text-gray-600 text-xs font-bold">
                                                              <FileText size={16}/> File
                                                          </div>
                                                      )}
                                                  </div>
                                              ))}
                                          </div>
                                      )}
                                      <div className="prose prose-slate max-w-none text-sm md:text-base leading-relaxed break-words">
                                          <MarkdownRenderer content={msg.content}/>
                                      </div>
                                      {msg.sources && msg.sources.length > 0 && (
                                          <div className="mt-3 pt-3 border-t border-gray-100 grid grid-cols-1 gap-1">
                                              <div className="text-[10px] font-bold text-gray-400 uppercase">Sources</div>
                                              {msg.sources.map((s, i) => (
                                                  <a key={i} href={s.uri} target="_blank" rel="noreferrer" className="text-xs text-blue-600 hover:underline truncate block flex items-center gap-1">
                                                      <Globe size={10}/> {s.title}
                                                  </a>
                                              ))}
                                          </div>
                                      )}
                                  </div>
                              </div>
                          </div>
                      ))}
                      {isGenerating && (
                          <div className="flex gap-4">
                              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-600 to-red-600 flex items-center justify-center shrink-0">
                                  <Sparkles size={16} className="text-white animate-pulse"/>
                              </div>
                              <div className="bg-white border border-gray-100 p-4 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-3">
                                  <Loader2 className="animate-spin text-blue-600" size={18}/>
                                  <span className="text-sm font-medium text-gray-600">{generationStatus || "Thinking..."}</span>
                              </div>
                          </div>
                      )}
                      <div ref={chatEndRef} className="h-4"/>
                  </div>
                  
                  {/* Floating Input Area - Refactored to Static Footer */}
                  <div className="z-20 px-4 pb-4 pt-2 bg-gradient-to-t from-white via-white to-white/0">
                      <div className="max-w-3xl mx-auto flex flex-col items-center">
                          {attachments.length > 0 && (
                              <div className="flex gap-2 mb-2 w-full overflow-x-auto pb-2 px-2">
                                  {attachments.map(att => (
                                      <div key={att.id} className="relative bg-white rounded-lg p-2 pr-8 border border-gray-200 shrink-0 shadow-sm">
                                          <div className="text-xs font-bold truncate max-w-[100px]">{att.name}</div>
                                          <button onClick={() => setAttachments(attachments.filter(a => a.id !== att.id))} className="absolute top-1 right-1 hover:text-red-500"><X size={12}/></button>
                                      </div>
                                  ))}
                              </div>
                          )}
                          
                          <div className="w-full bg-white rounded-[32px] p-2 shadow-xl border border-gray-200/50 flex items-end gap-2 relative ring-1 ring-gray-100">
                              {/* Left Actions */}
                              <div className="flex items-center gap-1 pb-2 pl-2 text-gray-400">
                                  <label className="p-2 hover:bg-gray-100 rounded-full cursor-pointer transition hover:text-gray-600" title="Add Attachment">
                                      <Plus size={20}/>
                                      <input type="file" className="hidden" onChange={(e) => {
                                          const file = e.target.files?.[0];
                                          if (file) {
                                              const reader = new FileReader();
                                              reader.onloadend = () => {
                                                  const type = file.type.startsWith('image/') ? 'image' : 'file';
                                                  setAttachments([...attachments, { id: Date.now().toString(), type, content: (reader.result as string).split(',')[1], name: file.name, mimeType: file.type }]);
                                              }
                                              if (file.type.startsWith('image/')) reader.readAsDataURL(file); else reader.readAsText(file);
                                          }
                                      }}/>
                                  </label>
                                  {/* Hidden on Mobile to fix spacing */}
                                  <button onClick={() => setYoutubeModalOpen(true)} className="hidden sm:block p-2 hover:bg-red-50 rounded-full transition hover:text-red-600"><Youtube size={20}/></button>
                                  <button onClick={() => setMapsSearch(!mapsSearch)} className={`hidden sm:block p-2 hover:bg-green-50 rounded-full transition ${mapsSearch ? 'text-green-600' : 'hover:text-green-600'}`}><MapPin size={20}/></button>
                              </div>

                              {/* Input Field */}
                              <textarea 
                                  value={input}
                                  onChange={e => setInput(e.target.value)}
                                  onKeyDown={e => {
                                      if (e.key === 'Enter' && !e.shiftKey) {
                                          e.preventDefault();
                                          handleSendMessage();
                                      }
                                  }}
                                  placeholder="Ask anything..."
                                  className="flex-1 bg-transparent border-none outline-none resize-none py-3 px-2 max-h-32 text-gray-800 placeholder:text-gray-400"
                                  rows={1}
                                  style={{minHeight: '48px'}}
                              />
                              
                              {/* Right Actions */}
                              <div className="flex items-center gap-1 pb-1 pr-1">
                                  {isGenerating ? (
                                      <div className="p-3 bg-gray-100 text-gray-500 rounded-full"><Loader2 className="animate-spin" size={20}/></div>
                                  ) : (
                                      <>
                                          <button onClick={() => setWebSearch(!webSearch)} className={`p-3 rounded-full transition ${webSearch ? 'text-blue-600 bg-blue-50' : 'text-gray-400 hover:bg-gray-100 hover:text-blue-600'}`} title="Web Search">
                                              <Globe size={20}/>
                                          </button>
                                          <button onClick={() => setIsLiveOpen(true)} className="p-3 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition"><Mic size={20}/></button>
                                          <button 
                                              onClick={() => handleSendMessage()} 
                                              disabled={!input.trim() && attachments.length === 0}
                                              className={`p-3 rounded-full transition ${(!input.trim() && attachments.length === 0) ? 'bg-gray-100 text-gray-400' : 'bg-gradient-to-r from-blue-600 to-red-500 text-white hover:opacity-90 shadow-md'}`}
                                          >
                                              <Send size={20}/>
                                          </button>
                                      </>
                                  )}
                              </div>
                          </div>
                          
                          <div className="text-[10px] text-gray-400 mt-3 font-medium">
                              VibhavGPT can make mistakes. Check important info.
                          </div>
                      </div>
                  </div>
                </>
             ) : (
                <div/>
             )}
          </div>
        );
      case 'tools':
        return <ToolsLayout user={user} setUser={setUser} updateCredits={updateCredits} onBack={() => setCurrentTab('chat')} />;
      case 'apps':
        return <AppsLayout user={user} setUser={setUser} updateCredits={updateCredits} onBack={() => setCurrentTab('chat')} />;
      case 'arena':
        return <AIArena onBack={() => setCurrentTab('chat')} updateCredits={updateCredits} />;
      case 'compare':
        return <CompareModels onBack={() => setCurrentTab('chat')} />;
      case 'about':
        return <AboutUs onBack={() => setCurrentTab('chat')} />;
      case 'pricing':
        return <PricingPage user={user} onUpgrade={(t) => { setUser({...user, tier: t}); setCurrentTab('chat'); setIsPaymentOpen(false); alert(`Upgraded to ${t}!`); }} onBack={() => setCurrentTab('chat')} />;
      case 'video':
        return <VideoGenApp user={user} updateCredits={updateCredits} onBack={() => setCurrentTab('chat')} />;
      case 'image':
        return <ImageGenApp user={user} updateCredits={updateCredits} onBack={() => setCurrentTab('chat')} />;
      default:
        return <div/>;
    }
  };

  return (
    <div className={`flex h-[100dvh] overflow-hidden font-sans bg-white text-gray-900`}>
      
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && window.innerWidth < 1024 && (
        <div 
          className="fixed inset-0 bg-black/20 z-40 backdrop-blur-sm transition-opacity"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar - Clean & Modern */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-[260px] flex flex-col transition-transform duration-300 bg-[#f9f9f9] border-r border-gray-200 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:relative lg:translate-x-0 ${!isSidebarOpen ? 'lg:hidden' : ''}`}>
        
        <div className="p-3">
           <div className="flex justify-between items-center mb-4 px-2">
                <button 
                    onClick={() => createNewSession()} 
                    className="font-bold text-lg text-gray-800 flex items-center gap-2 hover:opacity-80 transition"
                    title="Go Home / New Chat"
                >
                    <div className="w-6 h-6 bg-gradient-to-r from-blue-600 to-red-600 rounded-md flex items-center justify-center text-white">
                        <Sparkles size={12}/>
                    </div>
                    VibhavGPT
                </button>
                <button 
                    onClick={() => setIsSidebarOpen(false)} 
                    className="p-2 text-gray-500 hover:bg-gray-200 rounded-lg transition"
                    title="Close Sidebar"
                >
                    <X size={18} />
                </button>
           </div>

           <button 
                onClick={() => { createNewSession(); }} 
                className="group flex items-center justify-between w-full px-4 py-3 text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 border border-gray-200/60 rounded-[15px] transition shadow-sm mb-6"
           >
               <span className="flex items-center gap-2 font-semibold text-gray-600"><Plus size={18} className="text-gray-400 group-hover:text-gray-600"/> New chat</span>
               <Edit2 size={14} className="text-gray-400 opacity-0 group-hover:opacity-100 transition"/>
           </button>

           <div className="px-3 py-1.5 text-xs font-medium text-gray-500 mb-1">Recent</div>
           
           <div className="flex-1 overflow-y-auto space-y-0.5 max-h-[calc(100vh-180px)] custom-scrollbar pb-4">
               {sessions.map(s => (
                 <div 
                    key={s.id} 
                    onClick={() => { setActiveSessionId(s.id); setCurrentTab('chat'); if(window.innerWidth < 1024) setIsSidebarOpen(false); }} 
                    className={`group relative flex items-center px-3 py-2 rounded-lg cursor-pointer transition text-sm ${
                        activeSessionId === s.id ? 'bg-gray-200/60 text-gray-900 font-medium' : 'text-gray-600 hover:bg-gray-200/50'
                    }`}
                 >
                    {editingSessionId === s.id ? (
                        <input 
                            value={editTitle}
                            onChange={(e) => setEditTitle(e.target.value)}
                            onBlur={() => saveRename(s.id)}
                            onKeyDown={(e) => { if(e.key === 'Enter') saveRename(s.id); }}
                            autoFocus
                            onClick={(e) => e.stopPropagation()}
                            className="bg-white border border-blue-500 rounded px-2 py-1 w-full outline-none text-xs"
                        />
                    ) : (
                        <>
                            <span className="flex-1 truncate pr-2">{s.title}</span>
                            <div className={`absolute right-2 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity bg-inherit pl-2`}>
                                <button onClick={(e) => startRenaming(e, s)} className="hover:text-blue-600" title="Rename"><Edit2 size={12}/></button>
                                <button onClick={(e) => deleteSession(s.id, e)} className="hover:text-red-600" title="Delete"><Trash2 size={12}/></button>
                            </div>
                        </>
                    )}
                 </div>
               ))}
           </div>
        </div>

        <div className="mt-auto p-3 border-t border-gray-200 bg-[#f9f9f9]">
           <button onClick={() => setIsSettingsOpen(true)} className="flex items-center gap-3 w-full p-2 hover:bg-gray-200/50 rounded-lg transition group">
               <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold shadow-sm group-hover:shadow transition">
                    {user.username[0]}
               </div>
               <div className="flex-1 text-left min-w-0">
                    <div className="text-sm font-bold text-gray-700 truncate group-hover:text-gray-900">{user.username}</div>
                    <div className="text-[10px] text-gray-500 truncate font-medium">{user.tier} Plan</div>
               </div>
               <Settings size={16} className="text-gray-400 group-hover:text-gray-600"/>
           </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col relative min-w-0 h-full bg-white">
        
        {/* Header */}
        <header className="absolute top-0 left-0 right-0 h-14 flex items-center justify-between px-4 lg:px-8 z-30 pointer-events-none bg-white/80 backdrop-blur-sm border-b border-gray-50">
           <div className="pointer-events-auto flex items-center gap-4 h-full">
              <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 text-gray-500 hover:text-black transition lg:mr-2">
                 <PanelLeft size={20}/>
              </button>
              
               {/* NEW: VibhavGPT Home Button in Header (Always visible for easy access) */}
               <button 
                  onClick={() => createNewSession()}
                  className="flex items-center gap-2 font-bold text-gray-800 hover:opacity-80 transition mr-2"
                  title="New Chat"
               >
                    <div className="w-6 h-6 bg-gradient-to-r from-blue-600 to-red-600 rounded-md flex items-center justify-center text-white">
                        <Sparkles size={12}/>
                    </div>
                    <span className="hidden sm:inline">VibhavGPT</span>
               </button>

              {/* Model Selector Text */}
              <div className="relative">
                 <button 
                  onClick={() => setIsModelSelectorOpen(!isModelSelectorOpen)}
                  className="flex items-center gap-1 text-sm font-semibold text-gray-800 hover:text-blue-600 transition"
                 >
                    {selectedModel} <ChevronDown size={14} className="opacity-50"/>
                 </button>
                 
                 {isModelSelectorOpen && (
                   <>
                   <div className="fixed inset-0 z-[50]" onClick={() => setIsModelSelectorOpen(false)}></div>
                   <div className="absolute top-full left-0 mt-2 w-[340px] bg-white rounded-xl shadow-2xl border border-gray-200 p-2 z-[60] max-h-[70vh] overflow-y-auto animate-in fade-in zoom-in duration-200 ring-1 ring-black/5">
                      {MODEL_GROUPS.map((group) => {
                          if (group.models.length === 0) return null;
                          return (
                          <div key={group.brand} className="mb-3 first:mt-1">
                              <div className="px-3 py-1.5 text-[10px] font-bold text-gray-400 uppercase tracking-wider sticky top-0 bg-white z-10">{group.brand}</div>
                              {group.models.map((m: any) => (
                                <button 
                                    key={m} 
                                    onClick={() => { setSelectedModel(m as ModelType); setIsModelSelectorOpen(false); }} 
                                    className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition flex justify-between items-start gap-3 group ${selectedModel === m ? 'bg-blue-50/80' : 'hover:bg-gray-50'}`}
                                >
                                    <div className="flex flex-col gap-0.5 overflow-hidden">
                                        <span className={`font-medium truncate ${selectedModel === m ? 'text-blue-700' : 'text-gray-900 group-hover:text-gray-900'}`}>{m}</span>
                                        <span className={`text-[11px] leading-tight ${selectedModel === m ? 'text-blue-500' : 'text-gray-400 group-hover:text-gray-500'}`}>
                                            {MODEL_INFO[m] || "General purpose AI model."}
                                        </span>
                                    </div>
                                    {selectedModel === m && <Check size={16} className="mt-0.5 shrink-0 text-blue-600"/>}
                                </button>
                              ))}
                          </div>
                      )})}
                   </div>
                   </>
                 )}
              </div>
           </div>

           {/* Top Nav Links (Text Only) */}
           <div className="pointer-events-auto flex items-center gap-6 text-sm font-medium text-gray-500 hidden md:flex">
               <button onClick={() => setCurrentTab('video')} className="hover:text-red-600 transition">VidCraft</button>
               <button onClick={() => setCurrentTab('image')} className="hover:text-blue-600 transition">Image Engine</button>
               <button onClick={() => setCurrentTab('apps')} className="hover:text-purple-600 transition">Apps</button>
               <button onClick={() => setCurrentTab('tools')} className="hover:text-green-600 transition">Tools</button>
               <button onClick={() => setIsSettingsOpen(true)} className="hover:text-black transition">Settings</button>
           </div>
        </header>

        <main className="flex-1 overflow-hidden relative pt-14">
           {renderContent()}
        </main>
      </div>

      {/* Modals */}
      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
        user={user} 
        setUser={setUser} 
        onSaveKeys={updateUserKeys} 
        onLogout={logout}
        responseStyle={responseStyle}
        setResponseStyle={setResponseStyle}
        customInstruction={customInstruction}
        setCustomInstruction={setCustomInstruction}
      />
      <PaymentModal 
        isOpen={isPaymentOpen} 
        onClose={() => setIsPaymentOpen(false)} 
        onUpgrade={(tier) => {
          const updatedUser = { ...user, tier };
          setUser(updatedUser);
        }}
      />
      <YouTubeSearchModal 
        isOpen={youtubeModalOpen} 
        onClose={() => setYoutubeModalOpen(false)} 
        onSelect={(v) => {
           setAttachments(prev => [...prev, { id: Math.random().toString(), type: 'youtube', content: v.id.videoId, name: v.snippet.title, meta: v.snippet.description }]);
        }} 
      />
      <CustomProfileModal 
        isOpen={customProfileOpen}
        onClose={() => setCustomProfileOpen(false)}
        initialValue={customInstruction}
        onSave={(val) => {
            setCustomInstruction(val);
            setUser({...user, customProfile: val});
        }}
      />
      {isLiveOpen && <GeminiLive onClose={() => setIsLiveOpen(false)} />}
      {!user.hasCompletedOnboarding && <OnboardingTour onComplete={() => setUser({...user, hasCompletedOnboarding: true})} />}
    </div>
  );
};

export default App;
